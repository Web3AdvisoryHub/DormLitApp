# DormLit

A modern platform for creators to connect with their audience through interactive experiences, monetized communications, and digital collectibles.

## Features

- **Creator Profiles**: Customizable profiles with interactive elements and monetization options
- **Phone Line System**: Monetized call and text system with per-minute rates and platform fees
- **Subscription Tiers**: Multiple subscription levels with different benefits
- **Wallet Integration**: Secure wallet management for transactions and earnings
- **Revenue Tracking**: Detailed tracking of earnings and platform fees
- **Grandfathered Status**: Special status for early adopters with premium benefits
- **Interactive NFTs**: Unique digital collectibles with interactive features
- **Social Sharing**: Easy sharing of profiles, posts, and NFTs across platforms
- **Embed Support**: Customizable embed options for external websites

## Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS, Framer Motion
- **Backend**: Node.js, Express, TypeScript
- **Database**: Supabase
- **Authentication**: Supabase Auth
- **Storage**: Supabase Storage
- **Payments**: Stripe Integration
- **Deployment**: Vercel (Frontend), Railway (Backend)

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Supabase account
- Stripe account (for payments)

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/dormlit.git
cd dormlit
```

2. Install dependencies:
```bash
# Install root dependencies
npm install

# Install client dependencies
cd client
npm install

# Install server dependencies
cd ../server
npm install
```

3. Set up environment variables:
```bash
# Create .env files in both client and server directories
# See .env.example for required variables
```

4. Start the development servers:
```bash
# Start the client (from client directory)
npm run dev

# Start the server (from server directory)
npm run dev
```

## Project Structure

```
dormlit/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable React components
│   │   ├── pages/         # Page components
│   │   ├── services/      # API and service functions
│   │   └── utils/         # Utility functions
│   └── public/            # Static assets
├── server/                # Backend Express application
│   ├── src/
│   │   ├── routes/        # API routes
│   │   ├── services/      # Business logic
│   │   └── utils/         # Utility functions
│   └── public/            # Server static files
├── shared/                # Shared TypeScript types
└── scripts/              # Utility scripts
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [Supabase](https://supabase.io) for the amazing backend services
- [Stripe](https://stripe.com) for payment processing
- [Framer Motion](https://www.framer.com/motion/) for animations
- [Tailwind CSS](https://tailwindcss.com) for styling 