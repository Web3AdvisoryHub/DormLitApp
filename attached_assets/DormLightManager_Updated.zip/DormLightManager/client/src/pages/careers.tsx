import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import StarBackground from '@/components/ui/star-background';

const CareersPage = () => {
  return (
    <>
      <Helmet>
        <title>Careers | Dormlit</title>
        <meta name="description" content="Join the Dormlit team and help build the future of digital fan communities." />
      </Helmet>

      <StarBackground starCount={100} />
      <Header />
      
      <main className="relative z-10">
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h1 className="text-5xl md:text-6xl font-bold mb-6 aura-gradient-text">
                Careers at Dormlit
              </h1>
              <p className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto">
                Join our team and help build the future of digital fan communities.
              </p>
            </motion.div>
            
            <div className="mystical-card p-12 rounded-xl border border-primary/20 text-center max-w-4xl mx-auto">
              <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-4xl">✨</span>
              </div>
              <h2 className="text-3xl font-bold mb-4">Join Our Team</h2>
              <p className="text-lg text-foreground/80 mb-8">
                We're always looking for forward-thinkers and collaborators. Dormlit is still growing, but if you want to be part of the journey, reach out to us at <a href="mailto:contact@dormlit.app" className="text-primary hover:text-primary/80 underline">contact@dormlit.app</a>.
              </p>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
};

export default CareersPage;
