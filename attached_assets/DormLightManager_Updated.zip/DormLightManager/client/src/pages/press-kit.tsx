import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import StarBackground from '@/components/ui/star-background';

const PressKitPage = () => {
  return (
    <>
      <Helmet>
        <title>Press Kit | Dormlit</title>
        <meta name="description" content="Dormlit press resources, brand assets, and media information." />
      </Helmet>

      <StarBackground starCount={100} />
      <Header />
      
      <main className="relative z-10">
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h1 className="text-5xl md:text-6xl font-bold mb-6 aura-gradient-text">
                Press Kit
              </h1>
              <p className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto">
                Media resources and brand assets for Dormlit.
              </p>
            </motion.div>
            
            <div className="mystical-card p-12 rounded-xl border border-primary/20 text-center max-w-4xl mx-auto">
              <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-4xl">📰</span>
              </div>
              <h2 className="text-3xl font-bold mb-4">Press Resources</h2>
              <p className="text-lg text-foreground/80 mb-8">
                Press assets, logos, and brand materials will be available here soon.
              </p>
            </div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
};

export default PressKitPage;
