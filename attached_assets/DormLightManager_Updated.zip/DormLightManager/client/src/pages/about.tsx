import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import StarBackground from '@/components/ui/star-background';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About Dormlit | Our Mission</title>
        <meta name="description" content="Learn about Dormlit's mission to create a cosmic digital fan haven where creativity and community converge." />
      </Helmet>

      <StarBackground starCount={100} />
      <Header />
      
      <main className="relative z-10">
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h1 className="text-5xl md:text-6xl font-bold mb-6 aura-gradient-text">
                Our Mission
              </h1>
              <p className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto">
                Creating a cosmic digital fan haven where creativity and community converge.
              </p>
            </motion.div>
          </div>
        </section>
        
        <section className="py-16 md:py-24 bg-black/30 backdrop-blur-sm">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <div className="mystical-card p-12 rounded-xl border border-primary/20">
                <h2 className="text-3xl font-bold mb-8 text-center">The Dormlit Vision</h2>
                
                <div className="space-y-8 mb-12">
                  <p className="text-lg text-foreground/90 leading-relaxed">
                    Dormlit was born from a simple yet powerful idea: to create a digital space where fans and creators could connect in meaningful ways beyond the limitations of traditional social platforms. We envisioned a realm where creativity isn't just shared but celebrated, where community isn't just a feature but the foundation.
                  </p>
                  
                  <p className="text-lg text-foreground/90 leading-relaxed">
                    In the vast digital universe, we saw the need for a sanctuary that honors the mystical connection between creators and their audiences—a place where digital identity becomes an extension of creative expression, and where every interaction adds to a collective tapestry of shared experiences.
                  </p>
                  
                  <p className="text-lg text-foreground/90 leading-relaxed">
                    Our mission extends beyond building a platform; we're cultivating an ecosystem where creativity thrives, where digital assets have meaning and value, and where communities form around shared passions rather than algorithms.
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                  <div className="p-6 rounded-xl bg-primary/10 border border-primary/20">
                    <h3 className="text-xl font-semibold mb-3">Our Values</h3>
                    <ul className="space-y-2 text-foreground/80">
                      <li>• Creative Expression</li>
                      <li>• Authentic Connection</li>
                      <li>• Digital Ownership</li>
                      <li>• Community Empowerment</li>
                      <li>• Mystical Experience</li>
                    </ul>
                  </div>
                  
                  <div className="p-6 rounded-xl bg-primary/10 border border-primary/20">
                    <h3 className="text-xl font-semibold mb-3">Our Promise</h3>
                    <p className="text-foreground/80 leading-relaxed">
                      We're committed to building a platform that respects your creativity, protects your digital assets, and fosters genuine connections. Dormlit will always prioritize community over commerce, meaning over metrics, and the mystical experience of shared creative energy.
                    </p>
                  </div>
                </div>
                
                <div className="text-center space-y-6">
                  <h3 className="text-2xl font-semibold">Join Our Journey</h3>
                  <p className="text-foreground/80 max-w-2xl mx-auto">
                    Dormlit is more than a platform—it's a movement to reclaim the magic of digital connection. 
                    Whether you're a creator seeking your audience or a fan looking for authentic experiences, 
                    there's a place for you in our cosmic community.
                  </p>
                  <div className="flex flex-wrap justify-center gap-4 pt-4">
                    <Button asChild size="lg" className="rounded-full px-8 mystical-glow">
                      <Link href="/register">Join Dormlit</Link>
                    </Button>
                    <Button asChild variant="outline" size="lg" className="rounded-full px-8 border-primary/50 hover:bg-primary/20">
                      <Link href="/community">Explore Community</Link>
                    </Button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
};

export default AboutPage;
