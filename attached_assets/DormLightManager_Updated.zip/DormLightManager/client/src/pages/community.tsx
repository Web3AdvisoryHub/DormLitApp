import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import StarBackground from '@/components/ui/star-background';
import { Button } from '@/components/ui/button';

const CommunityPage = () => {
  return (
    <>
      <Helmet>
        <title>Community | Dormlit</title>
        <meta name="description" content="Join the Dormlit community - connect with creators and fans in our mystical digital realm." />
      </Helmet>

      <StarBackground starCount={100} />
      <Header />
      
      <main className="relative z-10">
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h1 className="text-5xl md:text-6xl font-bold mb-6 aura-gradient-text">
                Dormlit Community
              </h1>
              <p className="text-xl md:text-2xl text-foreground/80 max-w-3xl mx-auto">
                Connect with creators and fans in our mystical digital realm.
              </p>
            </motion.div>
          </div>
        </section>
        
        <section className="py-16 md:py-24 bg-black/30 backdrop-blur-sm">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-4xl mx-auto"
            >
              <div className="mystical-card p-12 rounded-xl border border-primary/20 text-center">
                <h2 className="text-3xl md:text-4xl font-bold mb-8">Coming Soon</h2>
                <div className="mb-8">
                  <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-primary/20 flex items-center justify-center">
                    <span className="text-4xl">🌟</span>
                  </div>
                  <p className="text-lg text-foreground/80 mb-8">
                    Our community space is being crafted with cosmic care. Soon, you'll be able to:
                  </p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-center mb-10">
                  <div className="p-6 rounded-xl bg-primary/10 border border-primary/20">
                    <h3 className="text-xl font-semibold mb-3">Connect</h3>
                    <p className="text-foreground/70">Find and follow creators and fans who share your interests.</p>
                  </div>
                  <div className="p-6 rounded-xl bg-primary/10 border border-primary/20">
                    <h3 className="text-xl font-semibold mb-3">Collaborate</h3>
                    <p className="text-foreground/70">Join creative projects and contribute to community initiatives.</p>
                  </div>
                  <div className="p-6 rounded-xl bg-primary/10 border border-primary/20">
                    <h3 className="text-xl font-semibold mb-3">Create</h3>
                    <p className="text-foreground/70">Share your own content and get feedback from the community.</p>
                  </div>
                  <div className="p-6 rounded-xl bg-primary/10 border border-primary/20">
                    <h3 className="text-xl font-semibold mb-3">Celebrate</h3>
                    <p className="text-foreground/70">Participate in events, challenges, and community celebrations.</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <p className="text-foreground/80">
                    Be the first to know when our community features launch.
                  </p>
                  <Button size="lg" className="rounded-full px-8 mystical-glow">
                    Join the Waitlist
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      
      <Footer />
    </>
  );
};

export default CommunityPage;
