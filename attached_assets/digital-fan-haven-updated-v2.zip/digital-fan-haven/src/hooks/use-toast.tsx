
import { createContext, useContext, useState } from "react"

import { type ToastProps } from "@/components/ui/toast"

type Toast = {
  id: string
  title?: React.ReactNode
  description?: React.ReactNode
  action?: React.ReactNode
  duration?: number
  /**
   * @default "foreground"
   */
  variant?: ToastProps["variant"]
}

type ToastContextType = {
  toasts: Toast[]
  toast: (toast: Omit<Toast, "id"> & { id?: string }) => void
  dismiss: (toastId: string) => void
}

const ToastContext = createContext<ToastContextType>({
  toasts: [],
  toast: () => {},
  dismiss: () => {},
})

export const useToast = () => {
  return useContext(ToastContext)
}

// Export a helper function for creating toasts
export const toast = (props: Omit<Toast, "id"> & { id?: string }) => {
  const toastWithId = {
    id: props.id || String(Math.random()),
    ...props
  }
  
  // Get the toast function from the context
  const context = useContext(ToastContext)
  // Call the toast function with the toast object
  context.toast(toastWithId)
  
  return toastWithId
}

export { ToastContext }

// This is a proper React component
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])
  
  const toast = (data: Omit<Toast, "id"> & { id?: string }) => {
    const id = data.id || String(Math.random())
    const newToast = { ...data, id }
    
    setToasts((prevToasts) => [...prevToasts, newToast])
    
    return newToast
  }
  
  const dismiss = (toastId: string) => {
    setToasts((prevToasts) => prevToasts.filter((toast) => toast.id !== toastId))
  }
  
  // Return the actual JSX component instead of an object
  return (
    <ToastContext.Provider value={{
      toasts,
      toast,
      dismiss
    }}>
      {children}
    </ToastContext.Provider>
  )
}
