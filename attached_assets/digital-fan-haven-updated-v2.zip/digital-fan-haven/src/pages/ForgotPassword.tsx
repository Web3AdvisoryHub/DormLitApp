import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from '@/hooks/use-toast';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast({
        id: String(Math.random()),
        title: "Error",
        description: "Please enter your email address.",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    // Simulate password reset process
    setTimeout(() => {
      setIsLoading(false);
      setIsSubmitted(true);
      
      // Success message
      toast({
        id: String(Math.random()),
        title: "Success",
        description: "Password reset instructions have been sent to your email.",
      });
    }, 1500);
  };

  return (
    <div className="min-h-screen shimmer-bg text-white flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <Link to="/" className="inline-block">
            <h1 className="text-3xl font-bold text-white">Dormlit</h1>
          </Link>
          <h2 className="mt-6 text-2xl font-bold text-white">Reset your password</h2>
          <p className="mt-2 text-sm text-white/70">
            Enter your email address and we'll send you instructions to reset your password.
          </p>
        </div>
        
        <Card className="backdrop-blur-sm bg-white/10 border-white/20">
          <CardHeader>
            <CardTitle className="text-white text-xl">Forgot Password</CardTitle>
            <CardDescription className="text-white/70">
              {!isSubmitted ? 
                "We'll send you a link to reset your password" : 
                "Check your email for reset instructions"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!isSubmitted ? (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-white">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="bg-white/20 border-white/20 text-white placeholder:text-white/50"
                  />
                </div>
                
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Sending..." : "Send Reset Link"}
                </Button>
              </form>
            ) : (
              <div className="text-center py-4">
                <p className="text-white mb-4">
                  We've sent password reset instructions to:
                </p>
                <p className="font-medium text-white mb-6">{email}</p>
                <p className="text-white/70 text-sm mb-4">
                  If you don't see the email, check your spam folder or try again.
                </p>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            <Link to="/login" className="text-sm font-medium text-primary hover:text-primary/90">
              Back to Login
            </Link>
            {isSubmitted && (
              <Button variant="outline" onClick={() => setIsSubmitted(false)} className="text-sm">
                Try Again
              </Button>
            )}
          </CardFooter>
        </Card>
        
        <div className="text-center text-sm text-white/70">
          Need help? <Link to="/contact" className="font-medium text-primary hover:text-primary/90">Contact Support</Link>
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
