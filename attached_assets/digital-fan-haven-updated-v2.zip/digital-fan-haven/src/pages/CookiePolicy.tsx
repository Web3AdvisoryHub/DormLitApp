
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

const CookiePolicy = () => {
  return (
    <div className="min-h-screen shimmer-bg">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-3xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-sm p-8">
          <Link to="/">
            <Button variant="ghost" className="mb-6">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z" clipRule="evenodd" />
              </svg>
              Back to Home
            </Button>
          </Link>
          
          <h1 className="text-3xl font-bold mb-6">Cookie Policy</h1>
          
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <p className="mb-4">Last Updated: April 10, 2025</p>
            
            <h2 className="text-xl font-semibold mt-8 mb-4">1. What Are Cookies</h2>
            <p>Cookies are small pieces of text sent by your web browser by a website you visit. A cookie file is stored in your web browser and allows the Service or a third-party to recognize you and make your next visit easier and the Service more useful to you.</p>
            
            <h2 className="text-xl font-semibold mt-8 mb-4">2. How Dormlit Uses Cookies</h2>
            <p>When you use and access the Service, we may place a number of cookie files in your web browser. We use cookies for the following purposes:</p>
            <ul className="list-disc pl-6 mb-4">
              <li>To enable certain functions of the Service</li>
              <li>To provide analytics</li>
              <li>To store your preferences</li>
              <li>To enable advertisements delivery, including behavioral advertising</li>
            </ul>
            <p>We use both session and persistent cookies on the Service and we use different types of cookies to run the Service:</p>
            <ul className="list-disc pl-6 mb-4">
              <li><strong>Essential cookies.</strong> We may use essential cookies to authenticate users and prevent fraudulent use of user accounts.</li>
              <li><strong>Preferences cookies.</strong> We may use preferences cookies to remember information that changes the way the Service behaves or looks, such as the "remember me" functionality of a registered user or a user's language preference.</li>
              <li><strong>Analytics cookies.</strong> We may use analytics cookies to track information about how the Service is used so that we can make improvements. We may also use analytics cookies to test new advertisements, pages, features or new functionality of the Service to see how our users react to them.</li>
              <li><strong>Targeting cookies.</strong> These type of cookies are used to deliver advertisements on and through the Service and track the performance of these advertisements. These cookies may also be used to enable third-party advertising networks to deliver targeted advertisements that they believe will be of most interest to you based on information about your visit to this and other websites.</li>
            </ul>
            
            <h2 className="text-xl font-semibold mt-8 mb-4">3. Third-Party Cookies</h2>
            <p>In addition to our own cookies, we may also use various third-party cookies to report usage statistics of the Service, deliver advertisements on and through the Service, and so on.</p>
            
            <h2 className="text-xl font-semibold mt-8 mb-4">4. What Are Your Choices Regarding Cookies</h2>
            <p>If you'd like to delete cookies or instruct your web browser to delete or refuse cookies, please visit the help pages of your web browser.</p>
            <p>Please note, however, that if you delete cookies or refuse to accept them, you might not be able to use all of the features we offer, you may not be able to store your preferences, and some of our pages might not display properly.</p>
            
            <h2 className="text-xl font-semibold mt-8 mb-4">5. Where Can You Find More Information About Cookies</h2>
            <p>You can learn more about cookies at the following third-party websites:</p>
            <ul className="list-disc pl-6 mb-4">
              <li>AllAboutCookies: <a href="http://www.allaboutcookies.org/" className="text-primary">http://www.allaboutcookies.org/</a></li>
              <li>Network Advertising Initiative: <a href="http://www.networkadvertising.org/" className="text-primary">http://www.networkadvertising.org/</a></li>
            </ul>
            
            <h2 className="text-xl font-semibold mt-8 mb-4">6. Changes to This Cookie Policy</h2>
            <p>We may update our Cookie Policy from time to time. We will notify you of any changes by posting the new Cookie Policy on this page.</p>
            <p>You are advised to review this Cookie Policy periodically for any changes. Changes to this Cookie Policy are effective when they are posted on this page.</p>
            
            <h2 className="text-xl font-semibold mt-8 mb-4">7. Contact Us</h2>
            <p>If you have any questions about our Cookie Policy, please contact us:</p>
            <p>Email: cookies@dormlet.com</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CookiePolicy;
