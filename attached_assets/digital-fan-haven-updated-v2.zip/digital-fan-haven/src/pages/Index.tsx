
import React, { useState, useCallback } from 'react';
import CreatorProfile, { SocialLinkData } from '@/components/CreatorProfile';
import CreatorLinks from '@/components/CreatorLinks';
import FanWall, { FanInteraction } from '@/components/FanWall';
import CreatorStore from '@/components/CreatorStore';
import AffiliateProgram from '@/components/AffiliateProgram';
import ContentScroller, { ContentItem } from '@/components/ContentScroller';
import EmailAlertSystem from '@/components/EmailAlertSystem';
import UpgradeBar from '@/components/UpgradeBar';
import { toast } from '@/hooks/use-toast';
import { PaymentSettings, CreatorProfile as CreatorProfileType, StoreItem, ShippingOption, MembershipTier, AffiliateInfo } from '@/types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, CreditCard, Shield, Star, GripVertical, ArrowUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import BackgroundSelector from '@/components/BackgroundSelector';

// Define content section types
type ContentSectionType = 'featured' | 'links' | 'store' | 'wall' | 'affiliate';

// Define content section data structure
interface ContentSection {
  id: ContentSectionType;
  title: string;
  visible: boolean;
  order: number;
}

const Index = () => {
  // Background state
  const [background, setBackground] = useState('/lovable-uploads/0ece1a92-de83-4bd9-87b2-249d4e6cb70f.png');
  
  // Initial creator profile state
  const [profile, setProfile] = useState<CreatorProfileType>({
    id: '1',
    avatar: {
      base: '/placeholder.svg',
      features: {
        skinTone: 'medium',
        hairStyle: 'short',
        hairColor: '#000000',
        eyeColor: '#6b5b95',
        facialFeatures: []
      },
      accessories: [],
      nfts: [],
      isRiggable: false
    },
    displayName: 'Pixel Panda',
    bio: 'Digital artist and content creator specializing in pixel art and NFTs. I love connecting with fans and sharing my creative process.\n\nCommissions are currently open for custom pixel art and NFT designs.',
    socialLinks: [
      { platform: 'instagram', url: 'https://instagram.com/pixelpanda', username: 'pixelpanda', icon: 'instagram' },
      { platform: 'twitter', url: 'https://twitter.com/pixelpanda', username: 'pixelpanda', icon: 'twitter' },
      { platform: 'youtube', url: 'https://youtube.com/PixelPandaArt', username: 'PixelPandaArt', icon: 'youtube' },
      { platform: 'website', url: 'https://pixelpanda.art', username: 'pixelpanda.art', icon: 'globe' },
    ],
    roomState: {
      theme: 'default',
      background: '/placeholder.svg',
      items: [],
      isPublic: true
    },
    communicationSettings: {
      callEnabled: true,
      textEnabled: true,
      callRatePerMinute: 4.99,
      textRatePerMessage: 0.99,
      availability: {
        startTime: '9:00 AM',
        endTime: '6:00 PM',
        timezone: 'EST'
      }
    },
    paymentSettings: {
      acceptedCurrencies: ['USD'],
      tipEnabled: true,
      subscriptionPlans: [
        {
          id: 'basic',
          name: 'Fan Pass',
          price: 4.99,
          features: [
            'Early access to new art',
            'Exclusive behind-the-scenes content',
            'Monthly livestream access'
          ],
          duration: 'monthly'
        },
        {
          id: 'premium',
          name: 'Collector Pass',
          price: 9.99,
          features: [
            'Everything in Fan Pass',
            'Monthly exclusive NFT drop',
            'Priority commission requests',
            'Direct message access'
          ],
          duration: 'monthly'
        }
      ],
      hasEarnings: true
    },
    walletInfo: {
      address: '',
      isConnected: false,
      provider: 'metamask',
      isTemporaryWallet: false
    },
    store: {
      isEnabled: true,
      acceptsCrypto: true,
      acceptsFiat: true,
      items: [
        {
          id: '1',
          name: 'Cosmic Panda NFT',
          description: 'A limited edition NFT featuring a panda floating in cosmic space. Only 100 will ever be minted.',
          image: '/placeholder.svg',
          price: 25.99,
          currency: 'USD',
          isNFT: true,
          hasPhysicalProduct: false,
          nftDetails: {
            blockchain: 'Ethereum',
            previewImage: '/placeholder.svg',
            attributes: [
              { name: 'Rarity', value: 'Legendary' },
              { name: 'Background', value: 'Cosmic' }
            ]
          },
          stock: 100,
          category: 'Art'
        },
        {
          id: '2',
          name: 'Bamboo Scented Candle + NFT',
          description: 'A bamboo scented candle that comes with a digital NFT certificate of authenticity.',
          image: '/placeholder.svg',
          price: 34.99,
          currency: 'USD',
          isNFT: true,
          hasPhysicalProduct: true,
          nftDetails: {
            blockchain: 'Polygon',
            previewImage: '/placeholder.svg',
          },
          physicalDetails: {
            weight: 12,
            dimensions: {
              length: 10,
              width: 10,
              height: 15
            },
            requiresShipping: true,
            shippingFrom: 'United States'
          },
          stock: 50,
          category: 'Home Goods'
        },
        {
          id: '3',
          name: 'Pixel Art Sticker Pack',
          description: 'A set of 5 high-quality vinyl stickers featuring my most popular pixel art designs.',
          image: '/placeholder.svg',
          price: 12.99,
          currency: 'USD',
          isNFT: false,
          hasPhysicalProduct: true,
          physicalDetails: {
            weight: 2,
            requiresShipping: true,
            shippingFrom: 'United States'
          },
          stock: 200,
          category: 'Merchandise'
        },
        {
          id: '4',
          name: 'Panda Valley Digital Background',
          description: 'A high-resolution digital background for your desktop or video calls.',
          image: '/placeholder.svg',
          price: 5.99,
          currency: 'USD',
          isNFT: true,
          hasPhysicalProduct: false,
          nftDetails: {
            blockchain: 'Polygon',
            previewImage: '/placeholder.svg',
          },
          stock: 999,
          category: 'Digital Goods'
        }
      ],
      shippingOptions: [
        {
          id: 'standard',
          name: 'Standard Shipping',
          price: 4.99,
          estimatedDelivery: '5-7 Business Days'
        },
        {
          id: 'express',
          name: 'Express Shipping',
          price: 12.99,
          estimatedDelivery: '2-3 Business Days'
        }
      ]
    },
    // New fields
    membershipTier: {
      level: 'free',
      features: {
        profileSubscriptions: false,
        storeEnabled: true,
        customAvatar: true,
        riggableAvatar: false,
        affiliateProgram: false
      }
    },
    affiliateInfo: {
      referralCode: 'PANDA10',
      referrals: [],
      commissionRate: 10,
      totalEarnings: 0,
      pendingPayouts: 0
    }
  });
  
  // Sample fan interactions
  const [fanInteractions, setFanInteractions] = useState<FanInteraction[]>([
    {
      id: '1',
      type: 'message',
      username: 'ArtLover42',
      userAvatar: '/placeholder.svg',
      content: 'Your pixel art is amazing! Love the colors you use.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2) // 2 hours ago
    },
    {
      id: '2',
      type: 'tip',
      username: 'CryptoFan',
      userAvatar: '/placeholder.svg',
      content: 'Keep up the great work!',
      amount: 20,
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24) // 1 day ago
    },
    {
      id: '3',
      type: 'sticker',
      username: 'PixelEnthusiast',
      userAvatar: '/placeholder.svg',
      content: 'This deserves a trophy!',
      imageUrl: '/placeholder.svg',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2) // 2 days ago
    },
    {
      id: '4',
      type: 'nft',
      username: 'NFTCollector',
      userAvatar: '/placeholder.svg',
      content: 'Gifted you this awesome NFT',
      imageUrl: '/placeholder.svg',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3) // 3 days ago
    }
  ]);
  
  // Sample featured content
  const [featuredContent, setFeaturedContent] = useState<ContentItem[]>([
    {
      id: '1',
      title: 'Latest Pixel Art Tutorial',
      imageUrl: '/placeholder.svg',
      link: 'https://youtube.com/pixelpanda',
      socialPlatform: 'youtube'
    },
    {
      id: '2',
      title: 'NFT Collection Reveal',
      imageUrl: '/placeholder.svg',
      link: 'https://twitter.com/pixelpanda',
      socialPlatform: 'twitter'
    },
    {
      id: '3',
      title: 'Behind the Scenes',
      imageUrl: '/placeholder.svg',
      link: 'https://instagram.com/pixelpanda',
      socialPlatform: 'instagram'
    },
    {
      id: '4',
      title: 'Bamboo Collection Launch',
      imageUrl: '/placeholder.svg',
      link: 'https://instagram.com/pixelpanda',
      socialPlatform: 'instagram'
    }
  ]);
  
  // User state - for demonstration
  const [isCurrentUser, setIsCurrentUser] = useState(false);
  const [isPlatformSubscriber, setIsPlatformSubscriber] = useState(true);
  const [showMembershipTabs, setShowMembershipTabs] = useState(false);
  const [hasEmailList, setHasEmailList] = useState(true);
  const [hasTextAlerts, setHasTextAlerts] = useState(true);
  const [subscribersCount, setSubscribersCount] = useState(155);

  // Content layout customization - removed 'showcase' section
  const [contentSections, setContentSections] = useState<ContentSection[]>([
    { id: 'featured', title: 'Featured Content', visible: true, order: 0 },
    { id: 'links', title: 'Creator Links', visible: true, order: 1 },
    { id: 'store', title: 'Creator Store', visible: true, order: 2 },
    { id: 'wall', title: 'Fan Wall', visible: true, order: 3 },
    { id: 'affiliate', title: 'Affiliate Program', visible: true, order: 4 }
  ]);

  // Social links
  const socialLinks: SocialLinkData[] = [
    { platform: 'instagram', username: 'pixelpanda', url: 'https://instagram.com/pixelpanda' },
    { platform: 'twitter', username: 'pixelpanda', url: 'https://twitter.com/pixelpanda' },
    { platform: 'youtube', username: 'Pixel Panda Art', url: 'https://youtube.com/PixelPandaArt' },
    { platform: 'website', username: 'pixelpanda.art', url: 'https://pixelpanda.art' },
  ];

  // Creator links
  const creatorLinks = [
    { id: '1', title: 'My NFT Collection', url: 'https://opensea.io/collection/pixelpanda' },
    { id: '2', title: 'Art Portfolio', url: 'https://behance.net/pixelpanda' },
    { id: '3', title: 'Tutorials on Gumroad', url: 'https://gumroad.com/pixelpanda' },
    { id: '4', title: 'Join My Discord', url: 'https://discord.gg/pixelpanda' },
  ];

  const handleSendMessage = async (message: string, isPublic: boolean) => {
    toast({
      id: String(Math.random()),
      title: "Message Sent",
      description: `Your message has been delivered for $${profile.communicationSettings.textRatePerMessage.toFixed(2)}`,
    });
    
    if (isPublic) {
      const newInteraction: FanInteraction = {
        id: Date.now().toString(),
        type: 'message',
        username: 'CurrentUser',
        userAvatar: '/placeholder.svg',
        content: message,
        timestamp: new Date()
      };
      
      setFanInteractions(prev => [newInteraction, ...prev]);
    }
    
    return Promise.resolve();
  };

  const handleScheduleCall = async (duration: number) => {
    const totalCost = profile.communicationSettings.callRatePerMinute * duration;
    
    toast({
      id: String(Math.random()),
      title: "Call Scheduled",
      description: `Your ${duration} minute call has been scheduled for $${totalCost.toFixed(2)}`,
    });
    
    return Promise.resolve();
  };

  const handleSendTip = async (amount: number, isPublic: boolean) => {
    toast({
      id: String(Math.random()),
      title: "Tip Sent",
      description: `Your $${amount.toFixed(2)} tip has been sent!`,
    });
    
    if (isPublic) {
      const newInteraction: FanInteraction = {
        id: Date.now().toString(),
        type: 'tip',
        username: 'CurrentUser',
        userAvatar: '/placeholder.svg',
        content: 'Thanks for the amazing content!',
        amount: amount,
        timestamp: new Date()
      };
      
      setFanInteractions(prev => [newInteraction, ...prev]);
    }
    
    return Promise.resolve();
  };

  const handleSendSticker = async (stickerId: string, isPublic: boolean) => {
    toast({
      id: String(Math.random()),
      title: "Sticker Sent",
      description: "Your sticker has been sent!",
    });
    
    if (isPublic) {
      const newInteraction: FanInteraction = {
        id: Date.now().toString(),
        type: 'sticker',
        username: 'CurrentUser',
        userAvatar: '/placeholder.svg',
        content: 'Sent you a sticker!',
        imageUrl: '/placeholder.svg',
        timestamp: new Date()
      };
      
      setFanInteractions(prev => [newInteraction, ...prev]);
    }
    
    return Promise.resolve();
  };
  
  const handleOpeningFeeMessage = async (recipient: string, amount: number, message: string) => {
    toast({
      id: String(Math.random()),
      title: "Message with Opening Fee Sent",
      description: `Your message has been sent with a $${amount.toFixed(2)} opening fee requirement for replies.`,
    });
    
    return Promise.resolve();
  };

  const handleSubscribeToPlatform = () => {
    toast({
      id: String(Math.random()),
      title: "Processing Platform Subscription",
      description: "Setting up your Dormlit.grow subscription...",
    });
    
    setTimeout(() => {
      setIsPlatformSubscriber(true);
      
      toast({
        id: String(Math.random()),
        title: "Platform Subscription Active",
        description: "Your Dormlit.grow subscription is now active! You can now message and call creators.",
      });
    }, 1500);
  };

  const handleSubscribe = async (planId: string) => {
    const plan = profile.paymentSettings.subscriptionPlans.find(p => p.id === planId);
    if (!plan) return Promise.reject(new Error("Plan not found"));
    
    toast({
      id: String(Math.random()),
      title: "Processing Subscription",
      description: `Setting up your ${plan.name} subscription...`,
    });
    
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    toast({
      id: String(Math.random()),
      title: "Subscription Active",
      description: `Your ${plan.name} subscription is now active!`,
    });
    
    return Promise.resolve();
  };

  const handleConnectWallet = () => {
    toast({
      id: String(Math.random()),
      title: "Connecting Wallet",
      description: "Please approve the connection request in your wallet...",
    });

    setTimeout(() => {
      setProfile({
        ...profile,
        walletInfo: {
          ...profile.walletInfo,
          address: '0x1a2b3c4d5e6f7g8h9i0j',
          isConnected: true,
        }
      });
      
      toast({
        id: String(Math.random()),
        title: "Wallet Connected!",
        description: "Your wallet has been connected successfully.",
      });
    }, 1500);
  };

  const handleRemoveInteraction = (id: string) => {
    setFanInteractions(prev => prev.filter(interaction => interaction.id !== id));
    
    toast({
      id: String(Math.random()),
      title: "Interaction Removed",
      description: "The interaction has been removed from your fan wall.",
    });
  };

  const toggleUserView = () => {
    setIsCurrentUser(!isCurrentUser);
    
    toast({
      id: String(Math.random()),
      title: isCurrentUser ? "Viewing as Fan" : "Viewing as Creator",
      description: isCurrentUser 
        ? "You are now viewing the profile as a fan" 
        : "You are now viewing your own profile as the creator",
    });
  };

  const handleAvatarChange = (newAvatarUrl: string, isRiggable: boolean) => {
    if (isRiggable && profile.membershipTier.level === 'free') {
      toast({
        id: String(Math.random()),
        title: "Upgrade Required",
        description: "Riggable avatars are only available in Premium and Platinum plans.",
      });
      return;
    }
    
    setProfile({
      ...profile,
      avatar: {
        ...profile.avatar,
        base: newAvatarUrl,
        isRiggable: isRiggable && (profile.membershipTier.level !== 'free')
      }
    });
    
    toast({
      id: String(Math.random()),
      title: "Avatar Updated",
      description: isRiggable ? "Your riggable avatar has been updated." : "Your avatar has been updated.",
    });
  };

  const handleEnableAffiliate = () => {
    if (profile.membershipTier.level !== 'pro') {
      toast({
        id: String(Math.random()),
        title: "Upgrade Required",
        description: "The affiliate program is only available in the Pro plan.",
      });
      return;
    }
    
    setProfile({
      ...profile,
      membershipTier: {
        ...profile.membershipTier,
        features: {
          ...profile.membershipTier.features,
          affiliateProgram: true
        }
      }
    });
    
    toast({
      id: String(Math.random()),
      title: "Affiliate Program Enabled",
      description: "You've successfully joined the affiliate program!",
    });
  };

  const handleUpgradeTier = (tier: 'free' | 'premium' | 'pro') => {
    if (tier === 'free') {
      toast({
        id: String(Math.random()),
        title: "Downgrade not allowed",
        description: "You cannot downgrade from a paid plan.",
      });
      return;
    }
    
    const tierFeatures = {
      free: {
        profileSubscriptions: false,
        storeEnabled: true,
        customAvatar: true,
        riggableAvatar: false,
        affiliateProgram: false
      },
      premium: {
        profileSubscriptions: true,
        storeEnabled: true,
        customAvatar: true,
        riggableAvatar: true,
        affiliateProgram: false
      },
      pro: {
        profileSubscriptions: true,
        storeEnabled: true,
        customAvatar: true,
        riggableAvatar: true,
        affiliateProgram: true
      }
    };
    
    setProfile({
      ...profile,
      membershipTier: {
        level: tier,
        features: tierFeatures[tier]
      }
    });
    
    toast({
      id: String(Math.random()),
      title: "Plan Upgraded",
      description: `You've successfully upgraded to the ${tier.charAt(0).toUpperCase() + tier.slice(1)} plan!`,
    });
  };
  
  const toggleMembershipTabs = () => {
    setShowMembershipTabs(!showMembershipTabs);
  };

  const onSendEmailAlert = () => {
    toast({
      id: String(Math.random()),
      title: "Email Alert Sent",
      description: `Your email alert has been sent to ${subscribersCount} subscribers.`,
    });
  };

  const onSendTextAlert = () => {
    toast({
      id: String(Math.random()),
      title: "Text Alert Sent",
      description: `Your text alert has been sent to ${subscribersCount} subscribers.`,
    });
  };

  const handleDragEnd = useCallback((result: any) => {
    if (!result.destination) return;
    
    const items = Array.from(contentSections);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    const updatedItems = items.map((item, index) => ({
      ...item,
      order: index
    }));
    
    setContentSections(updatedItems);
    
    toast({
      id: String(Math.random()),
      title: "Layout Updated",
      description: "Your content layout has been rearranged successfully.",
    });
  }, [contentSections]);

  const toggleSectionVisibility = (id: ContentSectionType) => {
    setContentSections(prev =>
      prev.map(section =>
        section.id === id
          ? { ...section, visible: !section.visible }
          : section
      )
    );
  };

  const visibleSections = contentSections
    .filter(section => section.visible)
    .sort((a, b) => a.order - b.order);

  const renderSection = (sectionId: ContentSectionType) => {
    switch (sectionId) {
      case 'featured':
        return <ContentScroller key={sectionId} items={featuredContent} />;
      case 'links':
        return <CreatorLinks key={sectionId} links={creatorLinks} />;
      case 'store':
        return (
          <CreatorStore
            key={sectionId}
            items={profile.store.items as StoreItem[]}
            shippingOptions={profile.store.shippingOptions as ShippingOption[]}
            acceptsCrypto={profile.store.acceptsCrypto}
            acceptsFiat={profile.store.acceptsFiat}
          />
        );
      case 'wall':
        return (
          <FanWall
            key={sectionId}
            interactions={fanInteractions}
            isCurrentUser={isCurrentUser}
            onRemoveInteraction={handleRemoveInteraction}
          />
        );
      case 'affiliate':
        return (
          <AffiliateProgram
            key={sectionId}
            affiliateInfo={profile.affiliateInfo as AffiliateInfo}
            isEnabled={profile.membershipTier.features.affiliateProgram}
            onEnable={handleEnableAffiliate}
            isCurrentUser={isCurrentUser}
          />
        );
      default:
        return null;
    }
  };

  // Handle background change
  const handleBackgroundChange = (newBackground: string) => {
    setBackground(newBackground);
    toast({
      id: String(Math.random()),
      title: "Background Updated",
      description: "Your profile background has been updated successfully.",
    });
  };

  return (
    <div 
      className="min-h-screen shimmer-bg"
      style={{
        backgroundImage: `url(${background})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Toggle buttons */}
        <div className="mb-4 flex justify-between items-center">
          <div>
            {isCurrentUser && (
              <BackgroundSelector 
                currentBackground={background}
                onSelectBackground={handleBackgroundChange}
              />
            )}
          </div>
          <button
            onClick={toggleUserView}
            className="px-3 py-1 bg-primary/20 text-white text-sm rounded hover:bg-primary/30 transition-colors"
          >
            {isCurrentUser ? "View as Fan" : "View as Creator"}
          </button>
        </div>
        
        {/* Creator Profile */}
        <CreatorProfile 
          name={profile.displayName}
          avatarSrc={profile.avatar.base}
          bio={profile.bio}
          socialLinks={socialLinks}
          messageRate={profile.communicationSettings.textRatePerMessage}
          callRate={profile.communicationSettings.callRatePerMinute}
          isCurrentUser={isCurrentUser}
          onConnectWallet={handleConnectWallet}
          walletConnected={profile.walletInfo.isConnected}
          onSendMessage={handleSendMessage}
          onScheduleCall={handleScheduleCall}
          onSendTip={handleSendTip}
          onSendSticker={handleSendSticker}
          onOpeningFeeMessage={handleOpeningFeeMessage}
          isRiggable={profile.avatar.isRiggable}
          onAvatarChange={isCurrentUser ? handleAvatarChange : undefined}
          contentItems={[]} // No content items here to avoid duplicate content scrollers
          hasEmailList={hasEmailList}
          hasTextAlerts={hasTextAlerts}
          onSendEmailAlert={onSendEmailAlert}
          onSendTextAlert={onSendTextAlert}
          subscribersCount={subscribersCount}
          hideButtons={true} // Hide the buttons
        />
        
        {/* Upgrade bar - only show when relevant */}
        {!isCurrentUser ? null : profile.membershipTier.level === 'pro' ? null : (
          <div className="mb-6">
            <UpgradeBar 
              currentPlan={profile.membershipTier.level} 
              onUpgrade={toggleMembershipTabs}
            />
          </div>
        )}
        
        {/* Membership Tiers - Only show for creator and only when expanded */}
        {isCurrentUser && showMembershipTabs && (
          <section className="mb-8">
            <Tabs defaultValue={profile.membershipTier.level} className="w-full">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-white">Your Membership</h2>
                <TabsList className="bg-secondary/40">
                  <TabsTrigger 
                    value="free" 
                    className="text-white data-[state=active]:bg-primary data-[state=active]:text-white"
                  >
                    Free
                  </TabsTrigger>
                  <TabsTrigger 
                    value="premium" 
                    className="text-white data-[state=active]:bg-primary data-[state=active]:text-white"
                  >
                    Premium
                  </TabsTrigger>
                  <TabsTrigger 
                    value="pro" 
                    className="text-white data-[state=active]:bg-primary data-[state=active]:text-white"
                  >
                    Pro
                  </TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="free">
                <Card className="bg-secondary/10 border-secondary/30">
                  <CardHeader>
                    <CardTitle className="text-white">Free Plan</CardTitle>
                    <CardDescription>
                      Basic features for creators just getting started
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Basic profile with avatar
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Up to 3 links in bio
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Receive fan mail (free)
                      </p>
                      <p className="text-white/50 flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" /> Profile subscriptions
                      </p>
                      <p className="text-white/50 flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" /> Storefront access
                      </p>
                      <p className="text-white/50 flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" /> Riggable avatars
                      </p>
                      <p className="text-white/50 flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" /> Affiliate program
                      </p>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <p className="text-white/70 text-sm">
                      You are currently on the Free plan
                    </p>
                  </CardFooter>
                </Card>
              </TabsContent>
              
              <TabsContent value="premium">
                <Card className="bg-secondary/10 border-secondary/30">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Star className="h-5 w-5 text-yellow-400" /> Premium Plan
                    </CardTitle>
                    <CardDescription>
                      Advanced features for growing creators
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <span className="text-2xl font-bold text-white">$5.00</span>
                      <span className="text-white/70">/month</span>
                    </div>
                    <div className="space-y-2 mb-4">
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Unlimited links
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Access to Connect modal (text/call/tip)
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Store with up to 5 items
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Multiple profile themes
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Import NFT avatar from wallet
                      </p>
                      <p className="text-white/50 flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" /> Affiliate program
                      </p>
                      <p className="text-white/50 flex items-center gap-2">
                        <AlertCircle className="h-4 w-4" /> Unlimited store items
                      </p>
                    </div>
                    {profile.membershipTier.level === 'free' ? (
                      <Button 
                        className="w-full bg-primary hover:bg-primary/80"
                        onClick={() => handleUpgradeTier('premium')}
                      >
                        <CreditCard className="h-4 w-4 mr-2" /> Upgrade to Premium
                      </Button>
                    ) : profile.membershipTier.level === 'premium' ? (
                      <p className="text-white/70 text-sm">
                        You are currently on the Premium plan
                      </p>
                    ) : (
                      <p className="text-white/70 text-sm">
                        You are on a higher tier plan
                      </p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="pro">
                <Card className="bg-secondary/10 border-secondary/30">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Star className="h-5 w-5 text-purple-400" /> Pro Plan
                    </CardTitle>
                    <CardDescription>
                      Everything you need for a thriving creator business
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <span className="text-2xl font-bold text-white">$10.00</span>
                      <span className="text-white/70">/month</span>
                    </div>
                    <div className="space-y-2 mb-4">
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Everything in Premium
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Unlimited store items
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Affiliate program
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Priority support
                      </p>
                      <p className="text-white flex items-center gap-2">
                        <Shield className="h-4 w-4 text-green-400" /> Advanced analytics
                      </p>
                    </div>
                    {profile.membershipTier.level !== 'pro' ? (
                      <Button
                        className="w-full bg-primary hover:bg-primary/80"
                        onClick={() => handleUpgradeTier('pro')}
                      >
                        <CreditCard className="h-4 w-4 mr-2" /> Upgrade to Pro
                      </Button>
                    ) : (
                      <p className="text-white/70 text-sm">
                        You are currently on the Pro plan
                      </p>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </section>
        )}
        
        {/* Visible content sections */}
        {visibleSections.map(section => (
          <div key={section.id} className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold text-white">{section.title}</h2>
              {isCurrentUser && (
                <button
                  onClick={() => toggleSectionVisibility(section.id)}
                  className="text-white/70 hover:text-white text-sm"
                >
                  Hide Section
                </button>
              )}
            </div>
            {renderSection(section.id)}
          </div>
        ))}
        
        {/* Content reordering - only visible to the creator */}
        {isCurrentUser && (
          <div className="mt-12 mb-8">
            <h2 className="text-xl font-semibold text-white mb-4">Content Layout</h2>
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="content-sections">
                {(provided) => (
                  <div
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className="space-y-2"
                  >
                    {contentSections.map((section, index) => (
                      <Draggable key={section.id} draggableId={section.id} index={index}>
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                            className={`p-3 bg-secondary/10 rounded-lg flex justify-between items-center ${
                              !section.visible ? 'opacity-50' : ''
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <GripVertical className="h-4 w-4 text-white/50" />
                              <span className="text-white">{section.title}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => toggleSectionVisibility(section.id)}
                                className="text-white/70 hover:text-white text-sm"
                              >
                                {section.visible ? 'Hide' : 'Show'}
                              </button>
                              <ArrowUpDown className="h-4 w-4 text-white/50" />
                            </div>
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {provided.placeholder}
                  </div>
                )}
              </Droppable>
            </DragDropContext>
          </div>
        )}
      </div>
    </div>
  );
};

export default Index;
