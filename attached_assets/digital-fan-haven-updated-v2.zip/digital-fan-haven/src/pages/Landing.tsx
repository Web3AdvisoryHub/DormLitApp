
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { useToast } from '@/hooks/use-toast';
import HeroAvatar from '@/components/landing/HeroAvatar';
import FeatureSection from '@/components/landing/FeatureSection';
import TestimonialSection from '@/components/landing/TestimonialSection';
import FooterSection from '@/components/landing/FooterSection';

const Landing = () => {
  const { toast } = useToast();

  const handleDemoClick = () => {
    toast({
      title: "Demo Mode",
      description: "Exploring Dormlit in demo mode. Create an account to access all features!",
    });
  };

  return (
    <div className="min-h-screen shimmer-bg text-white">
      {/* Hero Section */}
      <section className="pt-16 pb-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Create Your Digital <span className="text-fan-purple">Creator Profile</span>
              </h1>
              <p className="text-lg md:text-xl text-white/80 mb-8">
                Connect with fans, share content, and monetize your creativity on Dormlit.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Link to="/signup">
                  <Button size="lg" className="bg-fan-purple hover:bg-fan-purple/80 w-full sm:w-auto">
                    Create My Profile
                  </Button>
                </Link>
                <Link to="/explore" onClick={handleDemoClick}>
                  <Button variant="outline" size="lg" className="border-white/20 hover:bg-white/10 w-full sm:w-auto">
                    Explore Dormlit
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex-1 flex justify-center">
              <HeroAvatar />
            </div>
          </div>
        </div>
      </section>

      {/* Feature Sections */}
      <FeatureSection />

      {/* Testimonials */}
      <TestimonialSection />

      {/* Footer */}
      <FooterSection />
    </div>
  );
};

export default Landing;
