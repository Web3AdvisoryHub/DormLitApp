import React, { useState, useEffect } from "react";
import { Avatar, AvatarImage, AvatarFallback } from "../components/ui/avatar";
import { Button } from "../components/ui/button";
import { Card } from "../components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger } from "../components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "../components/ui/toggle-group";
import { useToast } from "../hooks/use-toast";
import { ExploreFilters } from "../types";
import { Filter, Users, Video, Settings } from "lucide-react";
import { systemProfiles } from "../data/systemProfiles";

const Explore = () => {
  const [filters, setFilters] = useState<ExploreFilters>({ privacy: "public", sort: "newest" });
  const { toast } = useToast();

  return (
    <div className="p-4">
      <h1 className="text-2xl font-semibold mb-4">Explore</h1>
      <div className="flex justify-between items-center mb-4">
        <div className="flex space-x-2">
          <Select
            value={filters.privacy}
            onValueChange={(value) => setFilters({ ...filters, privacy: value })}
          >
            <SelectTrigger>
              <Filter className="mr-2" />
              Privacy
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="public">Public</SelectItem>
              <SelectItem value="private">Private</SelectItem>
            </SelectContent>
          </Select>
          <Select
            value={filters.sort}
            onValueChange={(value) => setFilters({ ...filters, sort: value })}
          >
            <SelectTrigger>
              <Filter className="mr-2" />
              Sort
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="popular">Popular</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <ToggleGroup type="single" defaultValue="grid" className="space-x-2">
          <ToggleGroupItem value="grid">
            <Users className="w-4 h-4" />
          </ToggleGroupItem>
          <ToggleGroupItem value="list">
            <Video className="w-4 h-4" />
          </ToggleGroupItem>
          <ToggleGroupItem value="settings">
            <Settings className="w-4 h-4" />
          </ToggleGroupItem>
        </ToggleGroup>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {systemProfiles.map((profile) => (
          <Card key={profile.username} className="flex flex-col items-center p-4">
            <Avatar className="mb-2">
              <AvatarImage src={profile.avatar} alt={profile.username} />
              <AvatarFallback>{profile.username[0]}</AvatarFallback>
            </Avatar>
            <h2 className="text-lg font-semibold">{profile.username}</h2>
            <p className="text-sm text-gray-500">{profile.bio}</p>
            <Button className="mt-2">View Profile</Button>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default Explore;
