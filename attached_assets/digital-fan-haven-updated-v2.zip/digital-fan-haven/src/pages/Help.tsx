
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FAQSection from '@/components/help/FAQSection';
import CostResponsibilitySection from '@/components/help/CostResponsibilitySection';
import EarningsBreakdownChart from '@/components/earnings/EarningsBreakdownChart';
import PricingTable from '@/components/pricing/PricingTable';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

const Help = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const handleUpgrade = (tier: string) => {
    toast({
      title: "Upgrade Requested",
      description: `You're being redirected to upgrade to the ${tier} plan.`,
    });
    
    // Redirect to payment page (in a real app)
    // navigate('/upgrade');
    console.log(`Upgrade to ${tier} requested`);
  };
  
  return (
    <div className="min-h-screen shimmer-bg">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold text-white mb-2">Dormlit Help Center</h1>
        <p className="text-white/70 mb-8">Find answers to common questions and learn how Dormlit works</p>
        
        <Tabs defaultValue="faq" className="space-y-8">
          <TabsList className="bg-white/10 grid w-full md:w-auto grid-cols-4 md:inline-flex">
            <TabsTrigger 
              value="faq" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              FAQ
            </TabsTrigger>
            <TabsTrigger 
              value="costs" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              Platform Costs
            </TabsTrigger>
            <TabsTrigger 
              value="earnings" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              Earnings
            </TabsTrigger>
            <TabsTrigger 
              value="pricing" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              Pricing
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="faq" className="mt-6">
            <FAQSection />
          </TabsContent>
          
          <TabsContent value="costs" className="mt-6">
            <CostResponsibilitySection />
          </TabsContent>
          
          <TabsContent value="earnings" className="mt-6">
            <EarningsBreakdownChart />
          </TabsContent>
          
          <TabsContent value="pricing" className="mt-6">
            <PricingTable onUpgrade={handleUpgrade} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Help;
