
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from '@/hooks/use-toast';
import { createDefaultProfile } from '@/utils/defaultProfile';

const Signup = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    acceptTerms: false
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.username || !formData.email || !formData.password || !formData.confirmPassword) {
      toast({
        id: String(Math.random()),
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.password !== formData.confirmPassword) {
      toast({
        id: String(Math.random()),
        title: "Error",
        description: "Passwords do not match.",
        variant: "destructive",
      });
      return;
    }
    
    if (!formData.acceptTerms) {
      toast({
        id: String(Math.random()),
        title: "Error",
        description: "You must accept the Terms of Service and Privacy Policy.",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Generate a mock user ID for the new user
      const userId = `user_${Date.now()}`;
      
      // Create default profile for the new user
      const defaultProfile = createDefaultProfile(userId, formData.username);
      
      // In a real app, you would save this profile to a database
      // For now, we'll just store it in localStorage as an example
      localStorage.setItem('dormlet_user_profile', JSON.stringify(defaultProfile));
      localStorage.setItem('dormlet_user_id', userId);
      localStorage.setItem('dormlet_user_email', formData.email);
      localStorage.setItem('dormlet_is_authenticated', 'true');
      
      // Set flag for new signup to trigger welcome modal
      sessionStorage.setItem('new_signup', 'true');
      
      // Simulate a slight delay for the "setup" to complete
      setTimeout(() => {
        setIsLoading(false);
        
        // Successful signup
        toast({
          id: String(Math.random()),
          title: "Account Created",
          description: "Your creator profile is ready! Let's customize it.",
        });
        
        // Navigate to the profile page
        navigate('/profile');
      }, 1500);
    } catch (error) {
      setIsLoading(false);
      toast({
        id: String(Math.random()),
        title: "Error",
        description: "There was an error creating your account. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Handle contact support click
  const handleContactSupport = () => {
    navigate('/contact');
  };

  return (
    <div 
      className="min-h-screen shimmer-bg"
    >
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <Link to="/" className="inline-block">
            <h1 className="text-3xl font-bold text-white">Dormlit</h1>
          </Link>
          <h2 className="mt-6 text-2xl font-bold text-white">Create your creator profile</h2>
          <p className="mt-2 text-sm text-white/70">
            Already have an account?{' '}
            <Link to="/login" className="font-medium text-primary hover:text-primary/90">
              Sign in
            </Link>
          </p>
        </div>
        
        <Card className="backdrop-blur-sm bg-white/5 border-white/20">
          <CardHeader>
            <CardTitle className="text-white text-xl">Sign Up</CardTitle>
            <CardDescription className="text-white/70">
              Your Dormlit profile will be ready to customize instantly
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSignup} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-white">Creator Name</Label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  placeholder="YourCreatorName"
                  value={formData.username}
                  onChange={handleChange}
                  required
                  className="bg-white/20 border-white/20 text-white placeholder:text-white/50"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email" className="text-white">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder="your.email@example.com"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="bg-white/20 border-white/20 text-white placeholder:text-white/50"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password" className="text-white">Password</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="••••••••"
                  value={formData.password}
                  onChange={handleChange}
                  required
                  className="bg-white/20 border-white/20 text-white placeholder:text-white/50"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirmPassword" className="text-white">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  name="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                  className="bg-white/20 border-white/20 text-white placeholder:text-white/50"
                />
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="acceptTerms" 
                  name="acceptTerms"
                  checked={formData.acceptTerms}
                  onCheckedChange={(checked) => {
                    setFormData(prev => ({
                      ...prev,
                      acceptTerms: checked as boolean
                    }));
                  }}
                />
                <label
                  htmlFor="acceptTerms"
                  className="text-sm font-medium leading-none text-white peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  I accept the{' '}
                  <Link to="/terms" className="text-primary hover:text-primary/90">
                    Terms of Service
                  </Link>{' '}
                  and{' '}
                  <Link to="/privacy" className="text-primary hover:text-primary/90">
                    Privacy Policy
                  </Link>
                </label>
              </div>
              
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Creating your profile..." : "Create my creator profile"}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex justify-center">
            <div className="text-sm text-white/70">
              Need help? <Button variant="link" className="p-0 h-auto font-medium text-primary hover:text-primary/90" onClick={handleContactSupport}>Contact Support</Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default Signup;
