import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card } from "@/components/ui/card";
import { useToast } from '@/hooks/use-toast';
import ProfileSection from '@/components/fanview/ProfileSection';
import ContentSection from '@/components/fanview/ContentSection';
import { ContentSectionType, EarningsBreakdown, EarningSource } from '@/types';
import FanWall from '@/components/FanWall';
import SimulationRoomSystem from '@/components/simulation/SimulationRoomSystem';
import HorizontalContentScroller from '@/components/HorizontalContentScroller';

// Mock earnings data
const mockEarningsData: EarningsBreakdown = {
  totalEarnings: 2845.75,
  pendingEarnings: 125.50,
  availableForPayout: 720.25,
  tipEarnings: 980.50,
  messageEarnings: 645.25,
  callEarnings: 820.00,
  storeEarnings: 275.00,
  nftEarnings: 125.00,
  affiliateEarnings: 0,
  byPeriod: [
    { period: 'Jan', amount: 320.50 },
    { period: 'Feb', amount: 425.75 },
    { period: 'Mar', amount: 510.25 },
    { period: 'Apr', amount: 480.00 },
    { period: 'May', amount: 560.75 },
    { period: 'Jun', amount: 548.50 },
  ],
};

// Mock transactions data
const mockTransactions: EarningSource[] = [
  {
    id: 'tx1',
    name: 'Fan Tip from ArtLover42',
    amount: 25.00,
    date: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
    type: 'tip',
    status: 'completed',
  },
  {
    id: 'tx2',
    name: 'Message from CryptoFan',
    amount: 0.99,
    date: new Date(Date.now() - 1000 * 60 * 60 * 5), // 5 hours ago
    type: 'message',
    status: 'completed',
  },
  {
    id: 'tx3',
    name: 'Video Call (15 min)',
    amount: 74.85,
    date: new Date(Date.now() - 1000 * 60 * 60 * 12), // 12 hours ago
    type: 'call',
    status: 'completed',
  },
  {
    id: 'tx4',
    name: 'NFT Sticker Purchase',
    amount: 25.00,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    type: 'nft',
    status: 'completed',
  },
  {
    id: 'tx5',
    name: 'Cosmic Panda NFT Sale',
    amount: 75.00,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
    type: 'store',
    status: 'completed',
  },
  {
    id: 'tx6',
    name: 'Fan Tip from PixelArtFan',
    amount: 50.00,
    date: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3), // 3 days ago
    type: 'tip',
    status: 'pending',
  },
];

const fetchCreatorProfile = async (username: string) => {
  // This would be an API call in a real implementation
  return {
    id: '1',
    displayName: 'Pixel Panda',
    bio: 'Digital artist and content creator specializing in pixel art and NFTs. I love connecting with fans and sharing my creative process.',
    avatarSrc: '/placeholder.svg',
    socialLinks: [
      { platform: 'instagram', username: 'pixelpanda', url: 'https://instagram.com/pixelpanda', icon: '' },
      { platform: 'twitter', username: 'pixelpanda', url: 'https://twitter.com/pixelpanda', icon: '' },
      { platform: 'youtube', username: 'Pixel Panda Art', url: 'https://youtube.com/PixelPandaArt', icon: '' },
    ],
    messageRate: 0.99,
    callRate: 4.99,
    // Determine if this is the user's own profile
    isOwnProfile: localStorage.getItem('dormlet_username') === username,
    // Wallet connection status
    walletConnected: localStorage.getItem('dormlet_wallet_connected') === 'true',
    // Add earnings data
    earnings: mockEarningsData,
    recentTransactions: mockTransactions,
    minimumPayout: 25, // Minimum amount for payout in USD
    // Only visible content sections
    contentSections: [
      { id: 'featured', title: 'Featured Content', visible: true, order: 0 },
      { id: 'room', title: 'Creator Room', visible: true, order: 1 },
      { id: 'links', title: 'Creator Links', visible: true, order: 2 },
      { id: 'store', title: 'Creator Store', visible: true, order: 3 },
      { id: 'wall', title: 'Mutual Respect Wall', visible: true, order: 4 },
      { id: 'affiliate', title: 'Join Dormlit.Grow', visible: true, order: 5 },
      { id: 'earnings', title: 'Earnings & Analytics', visible: true, order: 6 },
    ],
    featuredContent: [
      {
        id: '1',
        title: 'Latest Pixel Art Tutorial',
        imageUrl: '/placeholder.svg',
        link: 'https://youtube.com/pixelpanda',
        socialPlatform: 'youtube'
      },
      {
        id: '2',
        title: 'NFT Collection Reveal',
        imageUrl: '/placeholder.svg',
        link: 'https://twitter.com/pixelpanda',
        socialPlatform: 'twitter'
      },
    ],
    creatorLinks: [
      { id: '1', title: 'My NFT Collection', url: 'https://opensea.io/collection/pixelpanda' },
      { id: '2', title: 'Art Portfolio', url: 'https://behance.net/pixelpanda' },
    ],
    fanInteractions: [
      {
        id: '1',
        type: 'message',
        username: 'ArtLover42',
        userAvatar: '/placeholder.svg',
        content: 'Your pixel art is amazing! Love the colors you use.',
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2) // 2 hours ago
      },
      {
        id: '2',
        type: 'tip',
        username: 'CryptoFan',
        userAvatar: '/placeholder.svg',
        content: 'Keep up the great work!',
        amount: 20,
        timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24) // 1 day ago
      },
    ],
    storeItems: [
      {
        id: '1',
        name: 'Cosmic Panda NFT',
        description: 'A limited edition NFT featuring a panda floating in cosmic space. Only 100 will ever be minted.',
        image: '/placeholder.svg',
        price: 25.99,
        currency: 'USD',
        isNFT: true,
        hasPhysicalProduct: false,
        stock: 100,
        category: 'Art'
      },
      {
        id: '2',
        name: 'Bamboo Scented Candle + NFT',
        description: 'A bamboo scented candle that comes with a digital NFT certificate of authenticity.',
        image: '/placeholder.svg',
        price: 34.99,
        currency: 'USD',
        isNFT: true,
        hasPhysicalProduct: true,
        stock: 50,
        category: 'Home Goods'
      },
    ],
    shippingOptions: [
      {
        id: 'standard',
        name: 'Standard Shipping',
        price: 4.99,
        estimatedDelivery: '5-7 Business Days'
      }
    ],
    acceptsCrypto: true,
    acceptsFiat: true,
    roomState: {
      theme: 'default',
      background: '/placeholder.svg',
      items: [
        {
          id: '1',
          type: 'nft',
          position: { x: 25, y: 25, z: 0 },
          rotation: { x: 0, y: 0, z: 0 },
          scale: { x: 1, y: 1, z: 1 },
          imageUrl: '/placeholder.svg',
          isMintable: true
        },
        {
          id: '2',
          type: 'decoration',
          position: { x: 75, y: 75, z: 0 },
          rotation: { x: 0, y: 0, z: 0 },
          scale: { x: 1, y: 1, z: 1 },
          imageUrl: '/placeholder.svg',
          isMintable: false
        }
      ],
      isPublic: true
    }
  };
};

const FanView = () => {
  const { username } = useParams<{ username: string }>();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [creatorData, setCreatorData] = useState<any>(null);
  const [background, setBackground] = useState('/placeholder.svg');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  useEffect(() => {
    // Check if user is authenticated
    const auth = localStorage.getItem('dormlet_is_authenticated') === 'true';
    setIsAuthenticated(auth);
  }, []);

  useEffect(() => {
    const loadCreatorData = async () => {
      try {
        setIsLoading(true);
        const data = await fetchCreatorProfile(username || '');
        setCreatorData(data);
        setIsLoading(false);
      } catch (error) {
        console.error('Error loading creator data:', error);
        toast({
          title: 'Error',
          description: 'Failed to load creator profile. Please try again later.',
          variant: 'destructive'
        });
        setIsLoading(false);
      }
    };

    if (username) {
      loadCreatorData();
    }
  }, [username, toast]);

  const handleSendMessage = async (message: string, isPublic: boolean) => {
    if (!isAuthenticated) {
      promptSignup();
      return Promise.reject("Authentication required");
    }
    
    toast({
      title: "Message Sent",
      description: `Your message has been delivered for $${creatorData.messageRate.toFixed(2)}`,
    });
    
    // Add notification and handle public messages
    const newNotification = {
      id: Date.now().toString(),
      type: 'message',
      content: message,
      isPublic,
      timestamp: new Date()
    };
    setNotifications(prev => [...prev, newNotification]);
    
    if (isPublic && creatorData) {
      const newInteraction = {
        id: Date.now().toString(),
        type: 'message',
        username: 'CurrentUser', // In a real app, this would be the current user's username
        userAvatar: '/placeholder.svg', // In a real app, this would be the current user's avatar
        content: message,
        timestamp: new Date()
      };
      
      creatorData.fanInteractions = [newInteraction, ...creatorData.fanInteractions];
      setCreatorData({...creatorData});
    }
    
    return Promise.resolve();
  };

  const handleScheduleCall = async (duration: number) => {
    if (!isAuthenticated) {
      promptSignup();
      return Promise.reject("Authentication required");
    }
    
    const totalCost = creatorData.callRate * duration;
    
    toast({
      title: "Call Scheduled",
      description: `Your ${duration} minute call has been scheduled for $${totalCost.toFixed(2)}`,
    });
    
    // Add notification
    const newNotification = {
      id: Date.now().toString(),
      type: 'call',
      duration,
      totalCost,
      timestamp: new Date()
    };
    setNotifications(prev => [...prev, newNotification]);
    
    return Promise.resolve();
  };

  const handleSendTip = async (amount: number, isPublic: boolean) => {
    if (!isAuthenticated) {
      promptSignup();
      return Promise.reject("Authentication required");
    }
    
    toast({
      title: "Tip Sent",
      description: `Your $${amount.toFixed(2)} tip has been sent!`,
    });
    
    // Add notification
    const newNotification = {
      id: Date.now().toString(),
      type: 'tip',
      amount,
      isPublic,
      timestamp: new Date()
    };
    setNotifications(prev => [...prev, newNotification]);
    
    if (isPublic && creatorData) {
      const newInteraction = {
        id: Date.now().toString(),
        type: 'tip',
        username: 'CurrentUser',
        userAvatar: '/placeholder.svg',
        content: 'Thanks for the awesome content!',
        amount: amount,
        timestamp: new Date()
      };
      
      creatorData.fanInteractions = [newInteraction, ...creatorData.fanInteractions];
      setCreatorData({...creatorData});
    }
    
    return Promise.resolve();
  };

  const handleSendSticker = async (stickerId: string, isPublic: boolean) => {
    if (!isAuthenticated) {
      promptSignup();
      return Promise.reject("Authentication required");
    }
    
    toast({
      title: "Sticker Sent",
      description: "Your sticker has been sent!",
    });
    
    // Add notification
    const newNotification = {
      id: Date.now().toString(),
      type: 'sticker',
      stickerId,
      isPublic,
      timestamp: new Date()
    };
    setNotifications(prev => [...prev, newNotification]);
    
    if (isPublic && creatorData) {
      const newInteraction = {
        id: Date.now().toString(),
        type: 'sticker',
        username: 'CurrentUser',
        userAvatar: '/placeholder.svg',
        content: '',
        imageUrl: '/placeholder.svg', // This would be the sticker image
        timestamp: new Date()
      };
      
      creatorData.fanInteractions = [newInteraction, ...creatorData.fanInteractions];
      setCreatorData({...creatorData});
    }
    
    return Promise.resolve();
  };
  
  const promptSignup = () => {
    toast({
      title: "Authentication Required",
      description: "Please sign up or log in to interact with creators.",
      action: (
        <Link to="/signup">
          <button className="bg-primary text-white px-4 py-2 rounded text-xs">
            Sign Up
          </button>
        </Link>
      ),
    });
  };
  
  const handleJoinAffiliate = () => {
    // Direct to signup with referral tracking
    window.location.href = `/signup?ref=${creatorData.displayName.replace(/\s+/g, '').toLowerCase()}`;
  };
  
  const handleEnterRoom = (roomId: string) => {
    // Check if the user has an avatar
    const hasAvatar = localStorage.getItem('dormlet_user_has_avatar') === 'true';
    
    if (!hasAvatar) {
      toast({
        title: "Avatar Required",
        description: "You need to create an avatar before entering simulation rooms. Go to your profile to create one.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Enter Room",
      description: "Entering creator simulation room...",
    });
    
    // This would navigate to the room in a real implementation
    console.log("Entering creator room:", roomId);
  };

  // Updated handler for creating rooms
  const handleCreateRoom = (neighborhoodId: string, themeId: string) => {
    // Check if the user has an avatar
    const hasAvatar = localStorage.getItem('dormlet_user_has_avatar') === 'true';
    
    if (!hasAvatar) {
      toast({
        title: "Avatar Required",
        description: "You need to create an avatar before creating simulation rooms. Go to your profile to create one.",
        variant: "destructive"
      });
      return;
    }
    
    toast({
      title: "Creating Room",
      description: "Setting up your new simulation room...",
    });
    
    // This would create a new room in a real implementation
    console.log("Creating room with neighborhood:", neighborhoodId, "and theme:", themeId);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen shimmer-bg">
        <p>Loading creator profile...</p>
      </div>
    );
  }

  if (!creatorData) {
    return (
      <div className="min-h-screen shimmer-bg">
        <Card className="bg-secondary/10 border-secondary/30 p-6">
          <h1 className="text-2xl font-bold">Creator Not Found</h1>
          <p className="mt-2">The creator you're looking for could not be found.</p>
        </Card>
      </div>
    );
  }

  // Get the visible sections in the correct order
  const visibleSections = creatorData.contentSections
    .filter((section: any) => section.visible)
    .sort((a: any, b: any) => a.order - b.order);

  // Filter out earnings section if not creator's own profile
  const filteredSections = visibleSections.filter((section: any) => {
    if (section.id === 'earnings' && !creatorData.isOwnProfile) {
      return false;
    }
    return true;
  });

  // Render the appropriate section component based on section type
  const renderSectionContent = (sectionId: ContentSectionType) => {
    switch(sectionId) {
      case 'wall':
        return (
          <FanWall 
            interactions={creatorData.fanInteractions} 
          />
        );
      case 'room':
        return (
          <SimulationRoomSystem
            creatorId={creatorData.id}
            isUserLoggedIn={isAuthenticated}
            isUserPremium={false}
            hasAvatar={localStorage.getItem('dormlet_user_has_avatar') === 'true'}
            onRequestLogin={promptSignup}
            onEnterRoom={handleEnterRoom}
            onCreateRoom={handleCreateRoom}
          />
        );
      case 'featured':
        return (
          <HorizontalContentScroller 
            items={creatorData.featuredContent.map((item: any) => ({
              id: item.id,
              title: item.title,
              imageUrl: item.imageUrl,
              link: item.link,
              socialPlatform: item.socialPlatform
            }))} 
          />
        );
      default:
        return (
          <ContentSection 
            sectionId={sectionId}
            creatorData={creatorData}
            handleJoinAffiliate={handleJoinAffiliate}
            handleEnterRoom={() => handleEnterRoom('1')}
          />
        );
    }
  };

  return (
    <div 
      className="min-h-screen shimmer-bg"
      style={{
        backgroundImage: `url(${background})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Creator Profile with Connect Options */}
        <ProfileSection 
          creatorData={creatorData}
          isAuthenticated={isAuthenticated}
          onSendMessage={handleSendMessage}
          onScheduleCall={handleScheduleCall}
          onSendTip={handleSendTip}
          onSendSticker={handleSendSticker}
          promptSignup={promptSignup}
        />
        
        {/* Content Sections */}
        {filteredSections.map((section: any) => (
          <div key={section.id} className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-white">{section.title}</h2>
            {renderSectionContent(section.id as ContentSectionType)}
          </div>
        ))}
      </div>
    </div>
  );
};

export default FanView;
