
import React, { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import PricingTable from '@/components/pricing/PricingTable';
import WhyUpgradePromo from '@/components/upgrade/WhyUpgradePromo';
import EarningsCalculator from '@/components/earnings/EarningsCalculator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft, CreditCard, Wallet } from 'lucide-react';
import { Link } from 'react-router-dom';

const Upgrade = () => {
  const { toast } = useToast();
  const [currentTier] = useState<'free' | 'premium' | 'pro'>('free');
  const [paymentTab, setPaymentTab] = useState('card');
  
  const handleUpgrade = (tier: string) => {
    toast({
      title: "Processing Upgrade",
      description: `Preparing your upgrade to ${tier}...`,
    });
    
    // In a real app, this would process the payment
    console.log(`Upgrading to ${tier} using ${paymentTab} payment method`);
    
    // Simulate successful upgrade
    setTimeout(() => {
      toast({
        title: "Upgrade Complete!",
        description: `You're now a ${tier} member. Enjoy your new features!`,
      });
    }, 2000);
  };
  
  return (
    <div className="min-h-screen shimmer-bg">
      <div className="max-w-6xl mx-auto px-4 py-12">
        <Link to="/profile" className="inline-flex items-center text-white/70 hover:text-white mb-8">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Profile
        </Link>
        
        <h1 className="text-3xl font-bold text-white mb-2">Upgrade Your Dormlit Experience</h1>
        <p className="text-white/70 mb-8">Choose the plan that fits your creative journey</p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <PricingTable 
              currentTier={currentTier} 
              onUpgrade={(tier) => {
                document.getElementById('payment-section')?.scrollIntoView({ behavior: 'smooth' });
                handleUpgrade(tier);
              }} 
            />
          </div>
          
          <div>
            <WhyUpgradePromo 
              currentTier={currentTier} 
              onUpgrade={() => {
                document.getElementById('payment-section')?.scrollIntoView({ behavior: 'smooth' });
                handleUpgrade('premium');
              }} 
            />
          </div>
        </div>
        
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Potential Earnings Calculator</h2>
          <EarningsCalculator />
        </div>
        
        <div id="payment-section" className="pt-4">
          <h2 className="text-2xl font-bold text-white mb-6">Payment Method</h2>
          
          <Card className="bg-white/5 backdrop-blur-md border-white/10">
            <CardContent className="p-6">
              <Tabs value={paymentTab} onValueChange={setPaymentTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-8">
                  <TabsTrigger 
                    value="card" 
                    className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Credit Card
                  </TabsTrigger>
                  <TabsTrigger 
                    value="crypto" 
                    className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
                  >
                    <Wallet className="h-4 w-4 mr-2" />
                    Crypto
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="card">
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-white text-sm">Card Number</label>
                        <input 
                          type="text" 
                          placeholder="1234 5678 9012 3456" 
                          className="w-full p-2 bg-white/10 border border-white/20 rounded-md text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-white text-sm">Name on Card</label>
                        <input 
                          type="text" 
                          placeholder="John Smith" 
                          className="w-full p-2 bg-white/10 border border-white/20 rounded-md text-white"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-white text-sm">Expiration Date</label>
                        <input 
                          type="text" 
                          placeholder="MM/YY" 
                          className="w-full p-2 bg-white/10 border border-white/20 rounded-md text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-white text-sm">CVC</label>
                        <input 
                          type="text" 
                          placeholder="123" 
                          className="w-full p-2 bg-white/10 border border-white/20 rounded-md text-white"
                        />
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="crypto">
                  <div className="space-y-6">
                    <div className="bg-fan-purple/10 p-4 rounded-md border border-fan-purple/20">
                      <p className="text-white">Connect your wallet to make payment in crypto</p>
                      <p className="text-white/70 text-sm mt-1">
                        We accept ETH, USDC, and other major cryptocurrencies
                      </p>
                    </div>
                    <div className="text-center">
                      <Button 
                        variant="outline" 
                        className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                      >
                        <Wallet className="h-4 w-4 mr-2" />
                        Connect Wallet
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
              
              <div className="mt-8 pt-6 border-t border-white/10">
                <Button 
                  onClick={() => handleUpgrade('premium')} 
                  className="w-full bg-fan-purple hover:bg-fan-purple/80 text-lg py-6"
                >
                  Upgrade to Premium
                </Button>
                <p className="text-white/50 text-sm text-center mt-4">
                  You'll be charged $9.99 monthly. Cancel anytime.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Upgrade;
