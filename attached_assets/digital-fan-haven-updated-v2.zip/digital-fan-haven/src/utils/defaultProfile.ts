
import { CreatorProfile } from "@/types";

export const createDefaultProfile = (userId: string, displayName: string = "New Creator"): CreatorProfile => {
  return {
    id: userId,
    avatar: {
      base: '/placeholder.svg',
      features: {
        skinTone: 'medium',
        hairStyle: 'short',
        hairColor: '#000000',
        eyeColor: '#6b5b95',
        facialFeatures: []
      },
      accessories: [],
      nfts: [],
      isRiggable: false
    },
    displayName: displayName,
    bio: "Welcome to my Dormlit! I'm excited to connect with my fans and share my content here. Tell everyone about yourself and your creative journey!",
    socialLinks: [
      { platform: 'instagram', url: '', username: '', icon: 'instagram' },
      { platform: 'tiktok', url: '', username: '', icon: 'tiktok' },
      { platform: 'youtube', url: '', username: '', icon: 'youtube' },
      { platform: 'twitter', url: '', username: '', icon: 'twitter' }
    ],
    roomState: {
      theme: 'default',
      background: '/placeholder.svg',
      items: [],
      isPublic: true
    },
    communicationSettings: {
      callEnabled: true,
      textEnabled: true,
      callRatePerMinute: 4.99,
      textRatePerMessage: 0.99,
      availability: {
        startTime: '9:00 AM',
        endTime: '6:00 PM',
        timezone: 'EST'
      }
    },
    paymentSettings: {
      acceptedCurrencies: ['USD'],
      tipEnabled: true,
      subscriptionPlans: [
        {
          id: 'basic',
          name: 'Fan Pass',
          price: 4.99,
          features: [
            'Early access to new content',
            'Exclusive behind-the-scenes',
            'Monthly livestream access'
          ],
          duration: 'monthly'
        }
      ],
      hasEarnings: false
    },
    walletInfo: {
      address: '',
      isConnected: false,
      provider: 'metamask',
      isTemporaryWallet: false
    },
    store: {
      isEnabled: true,
      acceptsCrypto: true,
      acceptsFiat: true,
      items: [],
      shippingOptions: [
        {
          id: 'standard',
          name: 'Standard Shipping',
          price: 4.99,
          estimatedDelivery: '5-7 Business Days'
        }
      ]
    },
    membershipTier: {
      level: 'free',
      features: {
        profileSubscriptions: false,
        storeEnabled: true,
        customAvatar: true,
        riggableAvatar: false,
        affiliateProgram: false
      }
    },
    affiliateInfo: {
      referralCode: '',
      referrals: [],
      commissionRate: 10,
      totalEarnings: 0,
      pendingPayouts: 0
    }
  };
};

// Sample featured content items to show by default
export const defaultFeaturedContent = [
  {
    id: '1',
    title: 'Add Your First Video',
    imageUrl: '/placeholder.svg',
    link: '#',
    socialPlatform: 'youtube' 
  },
  {
    id: '2',
    title: 'Share Your Latest Post',
    imageUrl: '/placeholder.svg',
    link: '#',
    socialPlatform: 'instagram'
  },
  {
    id: '3',
    title: 'Highlight Your Content',
    imageUrl: '/placeholder.svg',
    link: '#',
    socialPlatform: 'twitter'
  }
];

// Default creator links to help users get started
export const defaultCreatorLinks = [
  { id: '1', title: 'My Portfolio', url: '#', icon: '' },
  { id: '2', title: 'My Store', url: '#', icon: '' },
  { id: '3', title: 'Contact Me', url: '#', icon: '' }
];
