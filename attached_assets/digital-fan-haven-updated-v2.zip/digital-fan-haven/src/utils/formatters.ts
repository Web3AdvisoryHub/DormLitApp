
/**
 * Format a number as a currency value
 * @param amount - The amount to format
 * @param currency - The currency code (default: 'USD')
 * @returns Formatted currency string
 */
export const formatCurrency = (amount: number, currency = 'USD'): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
};

/**
 * Format a date to a localized string
 * @param date - The date to format
 * @param options - Intl.DateTimeFormatOptions
 * @returns Formatted date string
 */
export const formatDate = (date: Date, options?: Intl.DateTimeFormatOptions): string => {
  const defaultOptions: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  };
  
  return new Intl.DateTimeFormat('en-US', options || defaultOptions).format(date);
};

/**
 * Format a number with appropriate suffix (K, M, B)
 * @param num - The number to format
 * @returns Formatted number string with suffix (e.g., "1.2K")
 */
export const formatCompactNumber = (num: number): string => {
  if (num < 1000) {
    return num.toString();
  } else if (num < 1_000_000) {
    return (num / 1000).toFixed(1) + 'K';
  } else if (num < 1_000_000_000) {
    return (num / 1_000_000).toFixed(1) + 'M';
  } else {
    return (num / 1_000_000_000).toFixed(1) + 'B';
  }
};

/**
 * Calculate the percentage change between two values
 * @param current - Current value
 * @param previous - Previous value
 * @returns Percentage change as a string with sign (e.g., "+5.2%")
 */
export const calculatePercentageChange = (current: number, previous: number): string => {
  if (previous === 0) return '0%';
  
  const change = ((current - previous) / previous) * 100;
  const sign = change >= 0 ? '+' : '';
  return `${sign}${change.toFixed(1)}%`;
};
