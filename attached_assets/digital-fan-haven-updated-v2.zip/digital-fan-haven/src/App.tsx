
import React, { useState, useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BrowserRouter, Routes, Route, useLocation, useNavigate, Navigate } from "react-router-dom";
import { ToastProvider } from "@/hooks/use-toast";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ForgotPassword from "./pages/ForgotPassword";
import TermsOfService from "./pages/TermsOfService";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import CookiePolicy from "./pages/CookiePolicy";
import Contact from "./pages/Contact";
import Explore from "./pages/Explore";
import FanView from "./pages/FanView";
import Help from "./pages/Help";
import Upgrade from "./pages/Upgrade";
import AdminGuide from "./components/AdminGuide";
import Navigation from "./components/Navigation";
import WelcomeModal from "./components/WelcomeModal";

// Wrapper component to handle route-specific logic
const RouteHandler = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const [username, setUsername] = useState('');

  useEffect(() => {
    // Check if user just signed up (coming from signup page to profile)
    const isAuthenticated = localStorage.getItem('dormlet_is_authenticated') === 'true';
    const isNewSignup = sessionStorage.getItem('new_signup') === 'true';
    
    if (location.pathname === '/profile' && isAuthenticated && isNewSignup) {
      // Get the username
      const userProfile = localStorage.getItem('dormlet_user_profile');
      if (userProfile) {
        const profile = JSON.parse(userProfile);
        setUsername(profile.displayName || 'Creator');
      }
      
      // Show the welcome modal
      setShowWelcomeModal(true);
      
      // Clear the new signup flag
      sessionStorage.removeItem('new_signup');
    }
  }, [location.pathname]);

  // Check if user is authenticated for protected routes
  useEffect(() => {
    const protectedRoutes = ['/profile', '/create', '/messages', '/settings', '/calls', '/profile/edit', '/profile/avatar', '/upgrade'];
    const isAuthenticated = localStorage.getItem('dormlet_is_authenticated') === 'true';
    
    if (protectedRoutes.includes(location.pathname) && !isAuthenticated) {
      navigate('/login');
    }
  }, [location.pathname, navigate]);

  // Check for affiliate tracking on signup page
  useEffect(() => {
    if (location.pathname === '/signup') {
      // Extract referral code from URL if present
      const urlParams = new URLSearchParams(window.location.search);
      const referralCode = urlParams.get('ref');
      
      if (referralCode) {
        // Store the referral code in sessionStorage for use after signup
        sessionStorage.setItem('referral_code', referralCode);
      }
    }
  }, [location.pathname]);

  // Show navigation on these routes
  const routesWithNav = [
    '/profile', '/explore', '/create', '/messages', 
    '/settings', '/calls', '/profile/edit', '/profile/avatar',
    '/help', '/upgrade'
  ];

  return (
    <>
      {/* Protected routes with Navigation */}
      {routesWithNav.includes(location.pathname) && (
        <Navigation isAuthenticated={true} />
      )}
      
      {/* Welcome Modal */}
      <WelcomeModal 
        isOpen={showWelcomeModal}
        onClose={() => setShowWelcomeModal(false)}
        username={username}
      />
      
      {/* Routes */}
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/profile" element={<Index />} />
        <Route path="/explore" element={<Explore />} />
        <Route path="/home" element={<Navigate to="/" replace />} />
        <Route path="/create" element={<Index />} />
        <Route path="/messages" element={<Index />} />
        <Route path="/calls" element={<Index />} />
        <Route path="/profile/edit" element={<Index />} />
        <Route path="/profile/avatar" element={<Index />} />
        <Route path="/settings" element={<Index />} />
        <Route path="/terms" element={<TermsOfService />} />
        <Route path="/privacy" element={<PrivacyPolicy />} />
        <Route path="/cookies" element={<CookiePolicy />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/help" element={<Help />} />
        <Route path="/upgrade" element={<Upgrade />} />
        <Route path="/admin-guide" element={<AdminGuide />} />
        <Route path="/profile/:username" element={<FanView />} />
        <Route path="/:username" element={<FanView />} />
        {/* Catch-all route */}
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <TooltipProvider>
        <ToastProvider>
          <Toaster />
          <Sonner />
          <RouteHandler />
        </ToastProvider>
      </TooltipProvider>
    </BrowserRouter>
  );
};

export default App;
