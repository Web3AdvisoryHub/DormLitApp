export const systemProfiles = [
  {
    username: "Helios",
    avatar: "/avatars/helios.png",
    role: "admin",
    bio: "I oversee the threads that bind Dormlit together.",
  },
  {
    username: "Echo",
    avatar: "/avatars/echo.png",
    role: "guide",
    bio: "You found me... or maybe I found you.",
  },
];