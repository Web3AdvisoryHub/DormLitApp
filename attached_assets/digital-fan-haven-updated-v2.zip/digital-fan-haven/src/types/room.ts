
export interface Vector3 {
  x: number;
  y: number;
  z: number;
}

export interface RoomItem {
  id: string;
  type: 'nft' | 'decoration' | 'furniture';
  position: Vector3;
  rotation: Vector3;
  scale: Vector3;
  imageUrl: string;
  image?: string;
  isMintable: boolean;
}

export interface RoomState {
  theme: string;
  background: string;
  items: RoomItem[];
  isPublic: boolean;
}

// Simulation room types
export interface RoomTheme {
  id: string;
  name: string;
  description: string;
  previewImage: string;
  backgroundImage: string;
  isPremium: boolean;
}

export interface Neighborhood {
  id: string;
  name: string;
  description: string;
  previewImage: string;
  residentCount: number;
  isPremium: boolean;
}

export interface RoomAccessLevel {
  type: 'public' | 'private' | 'invite-only';
  allowedUserIds?: string[];
}

export interface SimulationRoom {
  id: string;
  name: string;
  ownerId: string;
  themeId: string;
  neighborhoodId: string;
  previewImage: string;
  items: RoomItem[];
  accessLevel: RoomAccessLevel;
  hasYard: boolean;
  isPremium: boolean;
  createdAt: Date;
  lastVisited: Date;
  visitorCount: number;
  currentVisitors: number;
}
