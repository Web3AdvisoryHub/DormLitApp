
export interface SocialLink {
  platform: string;
  url: string;
  username: string;
  icon?: string;
}

// Add any additional types related to social features here
