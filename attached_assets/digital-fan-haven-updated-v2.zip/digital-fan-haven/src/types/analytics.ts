
// Earnings and analytics types
export interface EarningSource {
  id: string;
  name: string;
  amount: number;
  date: Date;
  type: 'tip' | 'message' | 'call' | 'store' | 'nft' | 'affiliate';
  status: 'pending' | 'completed';
}

export interface EarningsBreakdown {
  totalEarnings: number;
  pendingEarnings: number;
  availableForPayout: number;
  tipEarnings: number;
  messageEarnings: number;
  callEarnings: number;
  storeEarnings: number;
  nftEarnings: number;
  affiliateEarnings: number;
  byPeriod: {
    period: string;
    amount: number;
  }[];
}

export interface AnalyticsData {
  profileViews: {
    count: number;
    trend: number;
    byDay: {
      date: string;
      count: number;
    }[];
  };
  engagement: {
    tipCount: number;
    messageCount: number;
    callCount: number;
    purchaseCount: number;
    trend: number;
  };
  followers: {
    count: number;
    newFollowers: number;
    trend: number;
    byDay: {
      date: string;
      count: number;
    }[];
  };
  conversionRate: {
    viewToTip: number;
    viewToMessage: number;
    viewToCall: number;
    viewToPurchase: number;
  };
}
