
import { NFT } from './nft';

export interface AvatarFeatures {
  hair?: string;
  face?: string;
  body?: string;
  skinTone?: string;
  hairStyle?: string;
  hairColor?: string;
  eyeColor?: string;
  facialFeatures?: string[];
}

export interface AvatarAccessory {
  id: string;
  type: string;
  imageUrl?: string;
  image?: string;
  position?: {x: number; y: number};
  isNFT?: boolean;
}

export interface Avatar {
  id?: string;
  imageUrl?: string;
  base?: string;
  isRiggable?: boolean;
  features?: AvatarFeatures;
  accessories?: AvatarAccessory[];
  nfts?: NFT[];
}
