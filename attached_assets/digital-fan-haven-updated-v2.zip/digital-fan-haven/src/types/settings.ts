
export interface CommunicationSettings {
  emailAlerts?: boolean;
  textAlerts?: boolean;
  emailList?: string[];
  phoneList?: string[];
  callEnabled?: boolean;
  textEnabled?: boolean;
  callRatePerMinute?: number;
  textRatePerMessage?: number;
  tipEnabled?: boolean;
  ratePerMessage?: number;
  ratePerMinuteCall?: number;
  availability?: {
    startTime: string;
    endTime: string;
    timezone: string;
  };
}

export interface PrivacySettings {
  isProfilePublic: boolean;
  showContentWall: boolean;
  allowDirectMessages: boolean;
}
