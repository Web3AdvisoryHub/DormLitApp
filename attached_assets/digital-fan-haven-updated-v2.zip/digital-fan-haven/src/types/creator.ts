
import { Avatar } from './avatar';
import { SocialLink } from './social';
import { CommunicationSettings } from './settings';
import { PaymentSettings } from './payments';
import { RoomState } from './room';
import { StoreItem, ShippingOption } from './store';
import { AffiliateInfo } from './affiliate';

export interface CreatorProfile {
  id: string;
  displayName: string;
  username?: string;
  bio: string;
  avatarSrc?: string;
  avatar?: Avatar;
  socialLinks: SocialLink[];
  messageRate?: number;
  callRate?: number;
  communicationSettings?: CommunicationSettings;
  paymentSettings?: PaymentSettings;
  walletInfo?: {
    address: string;
    isConnected: boolean;
    provider?: string;
    isTemporaryWallet?: boolean;
  };
  roomState?: RoomState;
  store?: {
    isEnabled: boolean;
    acceptsCrypto: boolean;
    acceptsFiat: boolean;
    items: StoreItem[];
    shippingOptions: ShippingOption[];
  };
  membershipTier?: {
    level: 'free' | 'premium' | 'pro';
    features: {
      profileSubscriptions: boolean;
      storeEnabled: boolean;
      customAvatar: boolean;
      riggableAvatar: boolean;
      affiliateProgram: boolean;
    };
  };
  affiliateInfo?: AffiliateInfo;
}

