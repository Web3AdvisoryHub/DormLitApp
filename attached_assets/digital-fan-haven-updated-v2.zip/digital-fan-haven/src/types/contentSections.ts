
// Content section types
export type ContentSectionType = 'featured' | 'links' | 'store' | 'wall' | 'affiliate' | 'room' | 'post' | 'earnings';

export interface ContentItem {
  id: string;
  title: string;
  imageUrl: string;
  link?: string;
  socialPlatform?: string;
}

export interface ContentSection {
  id: ContentSectionType;
  title: string;
  visible: boolean;
  order: number;
}
