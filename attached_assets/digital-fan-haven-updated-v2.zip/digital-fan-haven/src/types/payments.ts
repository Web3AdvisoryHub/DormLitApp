
export interface PaymentSettings {
  messageRate?: number;
  callRate?: number;
  acceptsCrypto?: boolean;
  acceptsFiat?: boolean;
  stripeConnected?: boolean;
  walletConnected?: boolean;
  acceptedCurrencies?: string[];
  tipEnabled?: boolean;
  subscriptionPlans?: MembershipTier[];
  hasEarnings?: boolean;
  withdrawalMethod?: string;
  payoutSchedule?: string;
  autoWithdrawEnabled?: boolean;
}

export interface PaymentPlan {
  id: string;
  name: string;
  price: number;
  features: string[];
  isPopular?: boolean;
}

export interface MembershipTier {
  id: string;
  name: string;
  price: number;
  benefits?: string[];
  features: string[]; // Make features required to match PaymentPlan
  duration?: string;
}

export interface EarningsEstimate {
  messages: number;
  messageRate: number;
  calls: number;
  callRate: number;
  tips: number;
  averageTip: number;
  nftGifts: number;
  averageNftValue: number;
  storeSales: number;
  averageStoreValue: number;
  referrals: number;
  referralValue: number;
}

export interface CostResponsibility {
  service: string;
  cost: string;
  payer: string;
  description: string;
}

// Create a new interface for the EarningsBreakdownChart component
export interface PaymentBreakdown {
  method: string;
  userPays: string;
  creatorKeeps: string;
  notes: string;
}

// Use this type for compatibility with EarningsSection
export type { EarningsBreakdown } from './analytics';
