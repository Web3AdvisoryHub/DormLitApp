
export interface ExploreFilters {
  tags?: string[]; // Changed from required to optional
  onlyLive: boolean;
  onlyPublic: boolean;
  sortBy?: string;
  category?: string;
  categoryFilter?: string[]; // Keeping this as well for backward compatibility
  searchTerm?: string;
  priceRange?: number[]; // For slider filter functionality
}
