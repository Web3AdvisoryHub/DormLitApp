
// NFT Interface
export interface NFT {
  id?: string;
  name: string;
  description?: string;
  imageUrl?: string;
  image?: string;
  ownerAddress?: string;
  creatorAddress?: string;
  contractAddress: string;
  tokenId: string;
  blockchain?: string;
  mintedAt?: Date;
  isWearable?: boolean;
  isDisplayable?: boolean;
}
