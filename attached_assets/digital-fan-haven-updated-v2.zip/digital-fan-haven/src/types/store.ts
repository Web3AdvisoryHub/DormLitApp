
export interface StoreItem {
  id: string;
  name: string;
  description: string;
  image: string;
  price: number;
  currency: string;
  isNFT?: boolean;
  hasPhysicalProduct?: boolean;
  stock?: number;
  category?: string;
  nftDetails?: {
    blockchain: string;
    previewImage: string;
    attributes?: Array<{name: string; value: string}>;
  };
  physicalDetails?: {
    weight?: string | number;
    dimensions?: string | {
      length: number;
      width: number;
      height: number;
    };
    shippingNotes?: string;
    requiresShipping?: boolean;
    shippingFrom?: string;
  };
}

export interface ShippingOption {
  id: string;
  name: string;
  price: number;
  estimatedDelivery: string;
}
