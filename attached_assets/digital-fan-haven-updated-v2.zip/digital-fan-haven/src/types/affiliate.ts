
export interface AffiliateInfo {
  referralCode?: string;
  code?: string;
  earnings?: number;
  referralCount?: number;
  referrals?: Referral[];
  commissionRate?: number;
  totalEarnings?: number;
  pendingPayouts?: number;
  referralLink?: string;
  earningsBreakdown?: object;
}

export interface Referral {
  id: string;
  username: string;
  date: Date;
  status: string;
}

export interface AffiliateProgramProps {
  affiliateInfo: AffiliateInfo;
  referrals?: Referral[];
  isEnabled?: boolean;
  creatorId?: string;
  creatorName?: string;
  onEnable?: () => void;
  onEnableAffiliate?: () => void;
  isCurrentUser?: boolean;
  referralLink?: string;
  earningsBreakdown?: object;
}
