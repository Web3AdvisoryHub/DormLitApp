
import React from 'react';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Paintbrush } from "lucide-react";

export type ColorTheme = 'default' | 'purple' | 'blue' | 'green' | 'pink' | 'orange';

interface ColorThemeSelectorProps {
  currentTheme: ColorTheme;
  onSelectTheme: (theme: ColorTheme) => void;
}

const ColorThemeSelector: React.FC<ColorThemeSelectorProps> = ({
  currentTheme = 'default',
  onSelectTheme,
}) => {
  const themes: { id: ColorTheme; name: string; color: string }[] = [
    { id: 'default', name: 'Purple', color: 'bg-[#9b87f5]' },
    { id: 'blue', name: 'Blue', color: 'bg-[#0EA5E9]' },
    { id: 'green', name: 'Green', color: 'bg-[#10B981]' },
    { id: 'pink', name: 'Pink', color: 'bg-[#D946EF]' },
    { id: 'orange', name: 'Orange', color: 'bg-[#F97316]' },
  ];

  return (
    <Card className="bg-white/5 backdrop-blur-md border-white/10">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
          <Paintbrush className="h-5 w-5 text-fan-purple" />
          Profile Theme
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex justify-center">
            <Tabs value={currentTheme} onValueChange={(value) => onSelectTheme(value as ColorTheme)}>
              <TabsList className="grid grid-cols-5 w-full">
                {themes.map((theme) => (
                  <TabsTrigger
                    key={theme.id}
                    value={theme.id}
                    className="flex flex-col items-center p-2 gap-2 data-[state=active]:ring-2 data-[state=active]:ring-white"
                  >
                    <div className={`w-6 h-6 rounded-full ${theme.color}`} />
                    <span className="text-xs">{theme.name}</span>
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
          
          <div className="grid grid-cols-5 gap-2 mt-4">
            {themes.map((theme) => (
              <button
                key={`color-${theme.id}`}
                onClick={() => onSelectTheme(theme.id)}
                className={`w-full h-12 rounded-lg ${theme.color} hover:opacity-90 transition-opacity ${
                  currentTheme === theme.id ? 'ring-2 ring-white' : ''
                }`}
                aria-label={`Select ${theme.name} theme`}
              />
            ))}
          </div>
          
          <p className="text-sm text-white/60 text-center mt-2">
            Select a theme color for your profile
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ColorThemeSelector;
