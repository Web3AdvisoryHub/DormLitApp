
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export type ShowcaseItem = {
  id: string;
  title: string;
  description: string;
  imageSrc: string;
  rarity?: 'common' | 'uncommon' | 'rare' | 'legendary';
};

type ItemShowcaseProps = {
  items: ShowcaseItem[];
};

const ItemShowcase = ({ items }: ItemShowcaseProps) => {
  const getRarityClass = (rarity?: string) => {
    switch (rarity) {
      case 'legendary': return 'from-amber-500 to-amber-300';
      case 'rare': return 'from-violet-600 to-purple-400';
      case 'uncommon': return 'from-emerald-500 to-green-400';
      default: return 'from-blue-500 to-sky-400';
    }
  };

  return (
    <Card className="glass-card border-0">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-white">Digital Collectibles</CardTitle>
        <CardDescription>Showcase of digital items and NFTs</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {items.map(item => (
            <div key={item.id} className="animate-fade-in">
              <div className={cn(
                "gradient-border bg-gradient-to-r",
                getRarityClass(item.rarity)
              )}>
                <div className="gradient-border-content p-0 aspect-square overflow-hidden">
                  <img 
                    src={item.imageSrc || "/placeholder.svg"} 
                    alt={item.title}
                    className="w-full h-full object-cover" 
                  />
                </div>
              </div>
              <div className="mt-2">
                <h4 className="text-sm font-medium text-white truncate">{item.title}</h4>
                <p className="text-xs text-white/60 truncate">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ItemShowcase;
