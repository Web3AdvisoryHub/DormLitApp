
import React, { useState } from 'react';
import { Avatar, AvatarFeatures, AvatarAccessory, NFT } from '../types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Shirt, PaintBucket, Brush, Eye, ShoppingBag, WalletCards } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

interface AvatarCustomizerProps {
  avatar: Avatar;
  onAvatarChange: (newAvatar: Avatar) => void;
  onNFTCheck?: (contractAddress: string, tokenId: string) => Promise<boolean>;
  walletConnected?: boolean;
  onConnectWallet?: () => void;
}

// Default accessories that come with the avatar
const defaultAccessories: AvatarAccessory[] = [
  {
    id: '1',
    type: 'clothing',
    image: '/placeholder.svg',
    position: { x: 0, y: 0 },
    isNFT: false
  },
  {
    id: '2',
    type: 'accessory',
    image: '/placeholder.svg',
    position: { x: 0, y: 0 },
    isNFT: false
  },
  {
    id: '3',
    type: 'background',
    image: '/placeholder.svg',
    position: { x: 0, y: 0 },
    isNFT: false
  }
];

const AvatarCustomizer2: React.FC<AvatarCustomizerProps> = ({
  avatar,
  onAvatarChange,
  onNFTCheck,
  walletConnected = false,
  onConnectWallet
}) => {
  const [contractAddress, setContractAddress] = useState('');
  const [tokenId, setTokenId] = useState('');
  const [isImporting, setIsImporting] = useState(false);

  const handleFeatureChange = (feature: keyof AvatarFeatures, value: string) => {
    onAvatarChange({
      ...avatar,
      features: {
        ...avatar.features,
        [feature]: value
      }
    });
  };

  const handleAccessoryAdd = (accessory: AvatarAccessory) => {
    onAvatarChange({
      ...avatar,
      accessories: [...avatar.accessories, accessory]
    });
  };

  const handleNFTImport = async () => {
    if (!contractAddress || !tokenId) {
      toast({
        title: "Missing Information",
        description: "Please provide both contract address and token ID.",
        variant: "destructive"
      });
      return;
    }

    setIsImporting(true);
    try {
      // If onNFTCheck is provided, use it to validate the NFT
      if (onNFTCheck) {
        const isValid = await onNFTCheck(contractAddress, tokenId);
        if (isValid) {
          // In a real app, you would fetch the NFT metadata here
          const newNFT: NFT = {
            contractAddress,
            tokenId,
            name: `NFT #${tokenId}`,
            image: '/placeholder.svg', // In a real app, this would be the NFT image URL
            isWearable: true,
            isDisplayable: true
          };

          onAvatarChange({
            ...avatar,
            nfts: [...avatar.nfts, newNFT]
          });

          toast({
            title: "NFT Imported",
            description: "Your NFT has been successfully imported."
          });

          // Clear form
          setContractAddress('');
          setTokenId('');
        } else {
          toast({
            title: "Invalid NFT",
            description: "Could not verify this NFT or it doesn't belong to your wallet.",
            variant: "destructive"
          });
        }
      } else {
        // Demo mode - just add a placeholder NFT
        const newNFT: NFT = {
          contractAddress,
          tokenId,
          name: `NFT #${tokenId}`,
          image: '/placeholder.svg',
          isWearable: true,
          isDisplayable: true
        };

        onAvatarChange({
          ...avatar,
          nfts: [...avatar.nfts, newNFT]
        });

        toast({
          title: "NFT Imported (Demo)",
          description: "This is a demo NFT import. In production, NFT ownership would be verified."
        });

        // Clear form
        setContractAddress('');
        setTokenId('');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while importing the NFT.",
        variant: "destructive"
      });
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="bg-fan-purple/10 border-fan-purple/30 hover:bg-fan-purple/20 text-white">
          Customize Avatar
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[800px] bg-fan-background border-fan-purple/30">
        <DialogHeader>
          <DialogTitle className="text-white">Customize Your Avatar</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-4">
          {/* Avatar Preview */}
          <div className="flex flex-col items-center justify-center p-4 bg-secondary/40 rounded-lg">
            <div className="w-48 h-48 bg-secondary/80 rounded-full overflow-hidden mb-4 border-2 border-fan-purple/30">
              <img 
                src={avatar.base || "/placeholder.svg"} 
                alt="Avatar Preview" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="text-sm text-white/70 mb-4 text-center">
              <p>Preview updates as you make changes</p>
            </div>
          </div>
          
          {/* Customization Options */}
          <Tabs defaultValue="features" className="w-full">
            <TabsList className="grid grid-cols-3 bg-secondary/40">
              <TabsTrigger 
                value="features"
                className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white flex items-center gap-2"
              >
                <Brush className="h-4 w-4" /> Features
              </TabsTrigger>
              <TabsTrigger 
                value="accessories"
                className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white flex items-center gap-2"
              >
                <Shirt className="h-4 w-4" /> Accessories
              </TabsTrigger>
              <TabsTrigger 
                value="nfts"
                className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white flex items-center gap-2"
              >
                <WalletCards className="h-4 w-4" /> NFTs
              </TabsTrigger>
            </TabsList>
            
            {/* Features Tab */}
            <TabsContent value="features" className="mt-4">
              <Card className="bg-secondary/20 border-fan-purple/20">
                <CardContent className="pt-6 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="skinTone" className="text-white">Skin Tone</Label>
                      <Select 
                        value={avatar.features.skinTone} 
                        onValueChange={(value) => handleFeatureChange('skinTone', value)}
                      >
                        <SelectTrigger className="bg-secondary/80 border-fan-purple/20 text-white">
                          <SelectValue placeholder="Select skin tone" />
                        </SelectTrigger>
                        <SelectContent className="bg-fan-background border-fan-purple/20">
                          <SelectItem value="light">Light</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="dark">Dark</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="hairStyle" className="text-white">Hair Style</Label>
                      <Select 
                        value={avatar.features.hairStyle} 
                        onValueChange={(value) => handleFeatureChange('hairStyle', value)}
                      >
                        <SelectTrigger className="bg-secondary/80 border-fan-purple/20 text-white">
                          <SelectValue placeholder="Select hair style" />
                        </SelectTrigger>
                        <SelectContent className="bg-fan-background border-fan-purple/20">
                          <SelectItem value="short">Short</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="long">Long</SelectItem>
                          <SelectItem value="curly">Curly</SelectItem>
                          <SelectItem value="bald">Bald</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="hairColor" className="text-white">Hair Color</Label>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-10 h-10 rounded border border-white/20"
                          style={{ backgroundColor: avatar.features.hairColor }}
                        />
                        <Input 
                          type="color" 
                          id="hairColor"
                          value={avatar.features.hairColor}
                          onChange={(e) => handleFeatureChange('hairColor', e.target.value)}
                          className="w-full h-10 bg-secondary/80 border-fan-purple/20 text-white"
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="eyeColor" className="text-white">Eye Color</Label>
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-10 h-10 rounded border border-white/20"
                          style={{ backgroundColor: avatar.features.eyeColor }}
                        />
                        <Input 
                          type="color" 
                          id="eyeColor"
                          value={avatar.features.eyeColor}
                          onChange={(e) => handleFeatureChange('eyeColor', e.target.value)}
                          className="w-full h-10 bg-secondary/80 border-fan-purple/20 text-white"
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-white">Facial Features</Label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {['none', 'beard', 'mustache', 'glasses', 'freckles'].map(feature => (
                        <Button 
                          key={feature}
                          variant="outline" 
                          size="sm"
                          className={`
                            bg-secondary/40 border-fan-purple/20 hover:bg-fan-purple/20 
                            ${avatar.features.facialFeatures.includes(feature) 
                              ? 'bg-fan-purple/30 border-fan-purple' 
                              : ''}
                          `}
                          onClick={() => {
                            const updatedFeatures = avatar.features.facialFeatures.includes(feature)
                              ? avatar.features.facialFeatures.filter(f => f !== feature)
                              : [...avatar.features.facialFeatures, feature];
                            
                            onAvatarChange({
                              ...avatar,
                              features: {
                                ...avatar.features,
                                facialFeatures: updatedFeatures
                              }
                            });
                          }}
                        >
                          {feature.charAt(0).toUpperCase() + feature.slice(1)}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Accessories Tab */}
            <TabsContent value="accessories" className="mt-4">
              <Card className="bg-secondary/20 border-fan-purple/20">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {defaultAccessories.map((accessory) => (
                        <div 
                          key={accessory.id}
                          className="bg-secondary/40 p-3 rounded-lg border border-fan-purple/20 hover:border-fan-purple/50 cursor-pointer transition-all"
                          onClick={() => handleAccessoryAdd(accessory)}
                        >
                          <div className="aspect-square bg-secondary/80 rounded overflow-hidden mb-2">
                            <img 
                              src={accessory.image} 
                              alt={accessory.type} 
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div className="text-sm text-white font-medium text-center">
                            {accessory.type.charAt(0).toUpperCase() + accessory.type.slice(1)}
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="mt-4">
                      <h3 className="text-white text-sm font-medium mb-2">Current Accessories</h3>
                      {avatar.accessories.length === 0 ? (
                        <div className="text-white/60 text-sm">No accessories added yet</div>
                      ) : (
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                          {avatar.accessories.map((acc, index) => (
                            <div key={index} className="bg-secondary/40 p-2 rounded border border-fan-purple/20 relative">
                              <img 
                                src={acc.image} 
                                alt={acc.type} 
                                className="w-full aspect-square object-cover rounded"
                              />
                              <Button
                                variant="outline"
                                size="icon"
                                className="absolute -top-2 -right-2 h-6 w-6 bg-fan-purple hover:bg-fan-dark-purple"
                                onClick={() => {
                                  const updatedAccessories = [...avatar.accessories];
                                  updatedAccessories.splice(index, 1);
                                  onAvatarChange({
                                    ...avatar,
                                    accessories: updatedAccessories
                                  });
                                }}
                              >
                                ×
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* NFTs Tab */}
            <TabsContent value="nfts" className="mt-4">
              <Card className="bg-secondary/20 border-fan-purple/20">
                <CardContent className="pt-6 space-y-4">
                  {!walletConnected ? (
                    <div className="p-4 text-center">
                      <WalletCards className="h-12 w-12 mx-auto mb-2 text-fan-purple/70" />
                      <h3 className="text-white font-medium mb-2">Connect Wallet to Use NFTs</h3>
                      <p className="text-white/60 text-sm mb-4">
                        Import NFTs from your wallet to use them as avatar accessories
                      </p>
                      <Button 
                        className="bg-fan-purple hover:bg-fan-dark-purple"
                        onClick={onConnectWallet}
                      >
                        Connect Wallet
                      </Button>
                    </div>
                  ) : (
                    <>
                      <div className="bg-secondary/40 p-4 rounded-lg space-y-4">
                        <h3 className="text-white font-medium">Import NFT</h3>
                        <div className="grid grid-cols-1 gap-2">
                          <div className="space-y-2">
                            <Label htmlFor="contractAddress" className="text-white text-sm">Contract Address</Label>
                            <Input 
                              id="contractAddress"
                              value={contractAddress}
                              onChange={(e) => setContractAddress(e.target.value)}
                              className="bg-secondary/80 border-fan-purple/20 text-white"
                              placeholder="0x..."
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="tokenId" className="text-white text-sm">Token ID</Label>
                            <Input 
                              id="tokenId"
                              value={tokenId}
                              onChange={(e) => setTokenId(e.target.value)}
                              className="bg-secondary/80 border-fan-purple/20 text-white"
                              placeholder="1234"
                            />
                          </div>
                        </div>
                        <Button 
                          className="w-full bg-fan-purple hover:bg-fan-dark-purple"
                          onClick={handleNFTImport}
                          disabled={isImporting}
                        >
                          {isImporting ? "Importing..." : "Import NFT"}
                        </Button>
                      </div>
                      
                      <div>
                        <h3 className="text-white font-medium mb-2">Your NFTs</h3>
                        {avatar.nfts.length === 0 ? (
                          <div className="text-center py-6">
                            <ShoppingBag className="h-10 w-10 mx-auto mb-2 text-white/40" />
                            <p className="text-white/60">No NFTs imported yet</p>
                          </div>
                        ) : (
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                            {avatar.nfts.map((nft, index) => (
                              <div key={index} className="bg-secondary/40 p-3 rounded-lg border border-fan-purple/20">
                                <div className="aspect-square bg-secondary/80 rounded overflow-hidden mb-2">
                                  <img 
                                    src={nft.image} 
                                    alt={nft.name} 
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                <div className="space-y-1">
                                  <h4 className="text-white text-sm font-medium truncate">{nft.name}</h4>
                                  <p className="text-white/60 text-xs">
                                    Token ID: {nft.tokenId.length > 8 ? `${nft.tokenId.slice(0, 6)}...` : nft.tokenId}
                                  </p>
                                  <div className="flex justify-between items-center mt-2">
                                    <span className={`text-xs px-2 py-1 rounded-full ${nft.isWearable ? 'bg-fan-purple/20 text-fan-purple' : 'bg-white/10 text-white/60'}`}>
                                      {nft.isWearable ? 'Wearable' : 'Display Only'}
                                    </span>
                                    <Button
                                      variant="outline"
                                      size="sm"
                                      className="h-7 text-xs bg-secondary/40 border-fan-purple/20 hover:bg-fan-purple/20"
                                      onClick={() => {
                                        const updatedNFTs = [...avatar.nfts];
                                        updatedNFTs.splice(index, 1);
                                        onAvatarChange({
                                          ...avatar,
                                          nfts: updatedNFTs
                                        });
                                      }}
                                    >
                                      Remove
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
        
        <div className="flex justify-end mt-4">
          <Button 
            className="bg-fan-purple hover:bg-fan-dark-purple"
            onClick={() => {
              toast({
                title: "Avatar Updated",
                description: "Your avatar has been successfully updated.",
              });
            }}
          >
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AvatarCustomizer2;
