
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { InfoIcon, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

interface FAQItem {
  question: string;
  answer: React.ReactNode | string;
  category: string;
}

interface FAQSectionProps {
  className?: string;
}

const FAQSection = ({ className }: FAQSectionProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  
  const faqItems: FAQItem[] = [
    {
      question: "What is Dormlit?",
      answer: "Dormlit is a scroll-core social platform where your profile becomes a digital room. You can decorate, connect, earn, and evolve your identity—visually and interactively.",
      category: "basics"
    },
    {
      question: "Is Dormlit free to use?",
      answer: "Yes! You can set up your profile, basic room, and social links for free. Premium and Pro tiers unlock more features and earning tools.",
      category: "basics"
    },
    {
      question: "What's the difference between Free, Premium, and Pro?",
      answer: "Free gives you one room and basic visibility. Premium unlocks more rooms, store access, and NFT features. Pro adds yards, riggable avatars, full analytics, and discovery boosts.",
      category: "pricing"
    },
    {
      question: "Do I keep what I earn?",
      answer: "Absolutely. You keep 90–100% of what you earn from tips, sales, and messages. Dormlit only takes small platform fees where needed.",
      category: "earnings"
    },
    {
      question: "Can people message or call me?",
      answer: "Yes, but only if you enable it—and you set your pricing.",
      category: "features"
    },
    {
      question: "What is the Mutual Respect Wall?",
      answer: "It's your digital love wall. Fans and friends can leave messages, stickers, or tips to show support. It's public, visual, and a vibe.",
      category: "features"
    },
    {
      question: "Can I move my room to a different neighborhood?",
      answer: "Yes! You can move anytime. Premium and Pro users get access to more neighborhoods and themes.",
      category: "rooms"
    },
    {
      question: "What happens if I leave Dormlit?",
      answer: "You take your data with you—mutuals, creations, earnings history. We believe in freedom, not lock-ins.",
      category: "account"
    },
    {
      question: "Do I need a wallet to use Dormlit?",
      answer: "Nope. You can use Dormlit without one. But if you want to mint NFTs or withdraw crypto rewards, we'll help you connect a wallet when you're ready.",
      category: "wallet"
    },
    {
      question: "Who pays for platform services and API costs?",
      answer: (
        <div className="space-y-4">
          <p>Here's how costs are handled on Dormlit:</p>
          <ul className="list-disc pl-5 space-y-2">
            <li><strong>AI Helper Chat:</strong> Users fund this directly by buying AI credits or upgrading to Pro. You don't pay out of pocket.</li>
            <li><strong>NFT Minting:</strong> The creator pays when minting, OR the viewer pays when gifting. Costs are baked into the transaction.</li>
            <li><strong>Payment Processing:</strong> Usually ~2.9% + $0.30 per transaction, auto-deducted from each sale.</li>
            <li><strong>Avatar Rigging Tools:</strong> Only Pro Tier creators who use this feature pay for this.</li>
          </ul>
        </div>
      ),
      category: "earnings"
    }
  ];
  
  // Filter FAQ items based on search query and selected category
  const filteredFAQs = faqItems.filter(item => {
    const matchesSearch = item.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (typeof item.answer === 'string' && item.answer.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesCategory = selectedCategory ? item.category === selectedCategory : true;
    
    return matchesSearch && matchesCategory;
  });
  
  // Get unique categories
  const categories = Array.from(new Set(faqItems.map(item => item.category)));
  
  return (
    <TooltipProvider>
      <Card className={`bg-white/5 backdrop-blur-md border-white/10 ${className}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white">Frequently Asked Questions</CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <InfoIcon className="h-5 w-5 text-white/70 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <p>Got Questions?</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Find answers about earnings, avatars, NFTs, and neighborhoods here.
                  Updated weekly with new features.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription className="text-white/70">
            Everything you need to know about Dormlit
          </CardDescription>
          
          <div className="mt-4 relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-white/50" />
            <Input
              placeholder="Search questions..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white/10 border-white/20 text-white"
            />
          </div>
          
          <div className="flex flex-wrap gap-2 mt-4">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3 py-1 text-xs rounded-full transition-colors ${
                selectedCategory === null 
                  ? 'bg-fan-purple text-white' 
                  : 'bg-white/10 text-white/70 hover:bg-white/20'
              }`}
            >
              All
            </button>
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1 text-xs rounded-full capitalize transition-colors ${
                  selectedCategory === category 
                    ? 'bg-fan-purple text-white' 
                    : 'bg-white/10 text-white/70 hover:bg-white/20'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </CardHeader>
        <CardContent>
          {filteredFAQs.length > 0 ? (
            <Accordion type="single" collapsible className="text-white">
              {filteredFAQs.map((faq, index) => (
                <AccordionItem key={index} value={`item-${index}`}>
                  <AccordionTrigger className="text-white hover:text-white/80">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-white/80">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          ) : (
            <div className="text-center py-8 text-white/50">
              <p>No FAQs found matching your search criteria.</p>
              <p className="text-sm mt-2">Try adjusting your search or category filters.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default FAQSection;
