
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import UserViewerFlow from './UserViewerFlow';
import OnboardingMessages from '../onboarding/OnboardingMessages';
import FeatureTooltips from './FeatureTooltips';
import DormlitHelper from '../onboarding/DormlitHelper';

const UserViewerGuide = () => {
  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <CardTitle>Dormlit User vs. Viewer Flow Guide</CardTitle>
          <CardDescription>
            Understanding how your profile works from both creator and visitor perspectives
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="flow">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="flow">Flow Chart</TabsTrigger>
              <TabsTrigger value="messages">Onboarding</TabsTrigger>
              <TabsTrigger value="tooltips">Tooltips</TabsTrigger>
              <TabsTrigger value="helper">Helper</TabsTrigger>
            </TabsList>
            
            <TabsContent value="flow" className="mt-6 space-y-6">
              <UserViewerFlow />
            </TabsContent>
            
            <TabsContent value="messages" className="mt-6 space-y-6">
              <OnboardingMessages />
            </TabsContent>
            
            <TabsContent value="tooltips" className="mt-6 space-y-6">
              <FeatureTooltips />
            </TabsContent>
            
            <TabsContent value="helper" className="mt-6 space-y-6">
              <div className="p-12 border border-dashed border-fan-purple/30 rounded-lg relative bg-gradient-to-b from-black/0 to-fan-purple/5 min-h-[300px]">
                <div className="text-center mb-8">
                  <h3 className="text-lg font-medium mb-2">Dormlit Helper Preview</h3>
                  <p className="text-white/70">This floating assistant helps users navigate Dormlit's features</p>
                </div>
                <DormlitHelper position="bottom-right" />
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default UserViewerGuide;
