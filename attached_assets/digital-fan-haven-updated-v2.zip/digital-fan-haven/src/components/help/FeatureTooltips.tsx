
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  User, 
  FileText, 
  Link as LinkIcon, 
  Palette, 
  Box, 
  Package, 
  DollarSign, 
  BarChart, 
  Wallet,
  Info
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface TooltipItem {
  id: string;
  title: string;
  icon: React.ReactNode;
  content: string;
}

const FeatureTooltips = () => {
  const tooltipItems: Record<string, TooltipItem[]> = {
    profile: [
      {
        id: 'avatar',
        title: 'Avatar Section',
        icon: <User className="h-5 w-5" />,
        content: 'This is how the world sees you. Want to upgrade to a custom or riggable avatar? Unlock more styles with Premium or Pro.'
      },
      {
        id: 'bio',
        title: 'Bio Input Field',
        icon: <FileText className="h-5 w-5" />,
        content: 'Tell your story. You\'ve got up to 8,000 characters—this space is all you.'
      },
      {
        id: 'social',
        title: 'Social Links & Creator Links',
        icon: <LinkIcon className="h-5 w-5" />,
        content: 'Add links to your socials, website, portfolio, or anywhere else you want fans to find you.'
      }
    ],
    room: [
      {
        id: 'theme',
        title: 'Room Theme Picker',
        icon: <Palette className="h-5 w-5" />,
        content: 'Set the vibe of your space. Premium and Pro tiers unlock exclusive themes and layouts.'
      },
      {
        id: 'simulation',
        title: 'Simulation Room Settings',
        icon: <Box className="h-5 w-5" />,
        content: 'Customize your room\'s interactivity—public, invite-only, or password-protected. (Advanced room settings unlock with Pro.)'
      }
    ],
    monetization: [
      {
        id: 'store',
        title: 'Store Manager',
        icon: <Package className="h-5 w-5" />,
        content: 'Upload digital or physical items to sell. Free tier doesn\'t include a store—upgrade to unlock this feature.'
      },
      {
        id: 'pricing',
        title: 'Pricing & Monetization',
        icon: <DollarSign className="h-5 w-5" />,
        content: 'Set your rates for messages, calls, and sticker packs. This is your hustle zone.'
      },
      {
        id: 'analytics',
        title: 'Analytics Tab',
        icon: <BarChart className="h-5 w-5" />,
        content: 'See who\'s visiting, tipping, or connecting. Advanced stats available in Pro tier.'
      },
      {
        id: 'wallet',
        title: 'Dormlit Coins & Wallet',
        icon: <Wallet className="h-5 w-5" />,
        content: 'Earn Dormlit Coins through tips, interactions, and quests. Use them to unlock features, buy land, or claim rewards.'
      }
    ]
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Info className="h-5 w-5 text-fan-purple" />
          Dormlit Feature Tooltips
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="profile">
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="room">Room</TabsTrigger>
            <TabsTrigger value="monetization">Monetization</TabsTrigger>
          </TabsList>
          
          {Object.keys(tooltipItems).map((section) => (
            <TabsContent key={section} value={section} className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {tooltipItems[section].map((item) => (
                  <TooltipProvider key={item.id}>
                    <div className="border border-fan-purple/20 rounded-lg p-4 bg-black/20 flex items-start gap-3">
                      <div className="bg-fan-purple/20 p-2 rounded-full h-10 w-10 flex items-center justify-center flex-shrink-0">
                        {item.icon}
                      </div>
                      <div>
                        <h3 className="font-medium mb-1 flex items-center gap-2">
                          {item.title}
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Info className="h-4 w-4 text-fan-purple/70 cursor-help" />
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs">
                              <p>{item.content}</p>
                            </TooltipContent>
                          </Tooltip>
                        </h3>
                        <p className="text-sm text-white/70 line-clamp-1">
                          {item.content}
                        </p>
                      </div>
                    </div>
                  </TooltipProvider>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default FeatureTooltips;
