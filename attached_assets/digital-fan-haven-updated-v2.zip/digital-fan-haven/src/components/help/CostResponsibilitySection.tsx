
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { InfoIcon, Bot, Sparkles, CreditCard, User } from "lucide-react";
import { CostResponsibility } from '@/types';

interface CostResponsibilitySectionProps {
  className?: string;
}

const CostResponsibilitySection = ({ className }: CostResponsibilitySectionProps) => {
  
  const costResponsibilities: CostResponsibility[] = [
    {
      service: "AI Helper Chat",
      cost: "Per interaction (based on AI provider like OpenAI or Perplexity)",
      payer: "User",
      description: "The user funds this directly by buying AI credits or upgrading to Pro. Users can purchase message bundles or access as part of a tier. Dormlit forwards a portion of their payment to cover the API cost. You don't pay out of pocket."
    },
    {
      service: "NFT Minting",
      cost: "Varies per mint (gas or storage fees)",
      payer: "Creator/Viewer",
      description: "The creator pays when minting, OR the viewer pays when gifting. You can bake mint cost into the transaction and pass it through at checkout."
    },
    {
      service: "Payment Processing",
      cost: "Usually ~2.9% + $0.30 per transaction",
      payer: "Auto-deducted",
      description: "This is auto-deducted from each sale (DM, tip, store, etc.). Creator gets payout minus processing fee. No extra setup needed."
    },
    {
      service: "Avatar Rigging Tools",
      cost: "If you integrate paid services like avatar animation uploads",
      payer: "Pro Tier Creators",
      description: "Only Pro Tier creators who use this feature. You can lock rigged avatar uploads behind a one-time upgrade fee or subscription."
    }
  ];
  
  // Helper function to get icon for each service
  const getServiceIcon = (service: string) => {
    switch (true) {
      case service.includes("AI"):
        return <Bot className="h-5 w-5" />;
      case service.includes("NFT"):
        return <Sparkles className="h-5 w-5" />;
      case service.includes("Payment"):
        return <CreditCard className="h-5 w-5" />;
      case service.includes("Avatar"):
        return <User className="h-5 w-5" />;
      default:
        return <InfoIcon className="h-5 w-5" />;
    }
  };
  
  return (
    <TooltipProvider>
      <Card className={`bg-white/5 backdrop-blur-md border-white/10 ${className}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white">Cost Responsibility Breakdown</CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <InfoIcon className="h-5 w-5 text-white/70 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <p>Who pays for what?</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Most features are user-funded.
                  Dormlit Coins handle internal rewards.
                  You're never charged unless you opt in.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription className="text-white/70">
            Understanding who bears the cost for different platform services
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {costResponsibilities.map((item, index) => (
              <div 
                key={index} 
                className="bg-white/10 rounded-lg p-5 border border-white/20"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-fan-purple/20 p-2 rounded-full shrink-0 mt-1">
                    {getServiceIcon(item.service)}
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-white">{item.service}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2 mt-2">
                      <div>
                        <p className="text-white/50 text-sm">Cost</p>
                        <p className="text-white">{item.cost}</p>
                      </div>
                      <div>
                        <p className="text-white/50 text-sm">Who Pays</p>
                        <p className="text-white font-medium">{item.payer}</p>
                      </div>
                    </div>
                    <p className="mt-3 text-white/80">{item.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 p-4 bg-fan-purple/10 rounded-md border border-fan-purple/20">
            <h3 className="font-semibold text-white mb-2">Key Takeaway</h3>
            <p className="text-white/80">
              Dormlit's platform is designed to ensure costs are transparent and fairly allocated. Most features are either included in subscription tiers or paid for by the end user receiving the benefit. There are no hidden fees or unexpected charges.
            </p>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default CostResponsibilitySection;
