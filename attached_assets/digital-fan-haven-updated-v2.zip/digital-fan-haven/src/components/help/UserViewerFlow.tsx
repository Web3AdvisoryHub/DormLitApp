
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Eye, User, Users, Edit, Lock, MessagesSquare, DollarSign, Store, Image, Share, BarChart, MapPin } from "lucide-react";

interface FlowItem {
  feature: string;
  ownerView: string;
  visitorView: string;
  icon: React.ReactNode;
}

const UserViewerFlow = () => {
  const flowItems: FlowItem[] = [
    {
      feature: "Avatar & Bio",
      ownerView: "Edit display name, bio, image, social links",
      visitorView: "View only",
      icon: <User className="h-5 w-5" />
    },
    {
      feature: "Room Access",
      ownerView: "Enter/edit own room(s); manage settings (public, invite-only)",
      visitorView: "Enter public/invited rooms only",
      icon: <Lock className="h-5 w-5" />
    },
    {
      feature: "Mutual Respect Wall",
      ownerView: "View all posts + manage moderation",
      visitorView: "View, tip, leave stickers/messages",
      icon: <Users className="h-5 w-5" />
    },
    {
      feature: "DM / Call Button",
      ownerView: "Set price per text/call; see received messages",
      visitorView: "Initiate (if enabled); pay per action",
      icon: <MessagesSquare className="h-5 w-5" />
    },
    {
      feature: "Tip Button",
      ownerView: "Set custom shoutout tiers, receive direct tips",
      visitorView: "Tip creator (optional message or public post)",
      icon: <DollarSign className="h-5 w-5" />
    },
    {
      feature: "Storefront",
      ownerView: "Upload items, manage pricing, fulfill orders",
      visitorView: "Browse and purchase items",
      icon: <Store className="h-5 w-5" />
    },
    {
      feature: "NFT Display / Gallery",
      ownerView: "Curate NFT wall, mint new ones, link to personal collection",
      visitorView: "View available NFTs, purchase if enabled",
      icon: <Image className="h-5 w-5" />
    },
    {
      feature: "Affiliate Program",
      ownerView: "See referral stats, generate links, track earnings",
      visitorView: "Join creator's affiliate team",
      icon: <Share className="h-5 w-5" />
    },
    {
      feature: "Analytics Dashboard",
      ownerView: "See profile visits, earnings, engagement by feature",
      visitorView: "Not available",
      icon: <BarChart className="h-5 w-5" />
    },
    {
      feature: "Neighborhood Info",
      ownerView: "Choose neighborhood, view neighborhood stats/settings",
      visitorView: "View public location theme (if room is public)",
      icon: <MapPin className="h-5 w-5" />
    },
  ];

  return (
    <Card className="border-fan-purple/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Eye className="h-5 w-5 text-fan-purple" />
          Dormlit Profile Interaction Flow
        </CardTitle>
        <CardDescription>
          Understanding what profile owners see versus what viewers experience
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="table" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="table">Table View</TabsTrigger>
            <TabsTrigger value="side-by-side">Side by Side</TabsTrigger>
          </TabsList>
          
          <TabsContent value="table" className="mt-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[180px]">Feature / Section</TableHead>
                  <TableHead>Profile Owner (User)</TableHead>
                  <TableHead>Viewer (Guest/Visitor)</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {flowItems.map((item) => (
                  <TableRow key={item.feature}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {item.icon}
                        {item.feature}
                      </div>
                    </TableCell>
                    <TableCell>{item.ownerView}</TableCell>
                    <TableCell>{item.visitorView}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
          
          <TabsContent value="side-by-side" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Edit className="h-4 w-4 text-fan-purple" /> 
                    Profile Owner View
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    {flowItems.map((item) => (
                      <li key={`owner-${item.feature}`} className="flex gap-3">
                        <div className="bg-fan-purple/10 p-2 rounded-full h-8 w-8 flex items-center justify-center flex-shrink-0">
                          {item.icon}
                        </div>
                        <div>
                          <p className="font-medium text-sm">{item.feature}</p>
                          <p className="text-sm text-muted-foreground">{item.ownerView}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Eye className="h-4 w-4 text-fan-purple" />
                    Visitor View
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-4">
                    {flowItems.map((item) => (
                      <li key={`visitor-${item.feature}`} className="flex gap-3">
                        <div className="bg-fan-purple/10 p-2 rounded-full h-8 w-8 flex items-center justify-center flex-shrink-0">
                          {item.icon}
                        </div>
                        <div>
                          <p className="font-medium text-sm">{item.feature}</p>
                          <p className="text-sm text-muted-foreground">{item.visitorView}</p>
                        </div>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default UserViewerFlow;
