
import React from 'react';
import { RoomState, RoomItem } from '../types';
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Info, Eye, EyeOff, Lock } from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";

interface RoomDisplayProps {
  roomState: RoomState;
  onRoomStateChange: (newState: RoomState) => void;
  walletConnected?: boolean;
  onConnectWallet?: () => void;
  hasRiggableAvatar?: boolean;
}

const RoomDisplay: React.FC<RoomDisplayProps> = ({ 
  roomState, 
  onRoomStateChange,
  walletConnected = false,
  onConnectWallet,
  hasRiggableAvatar = false
}) => {
  const handleTogglePublic = () => {
    onRoomStateChange({
      ...roomState,
      isPublic: !roomState.isPublic
    });
  };

  const handleItemClick = (item: RoomItem) => {
    if (item.isMintable && hasRiggableAvatar) {
      // Handle minting logic here
      console.log('Minting item:', item.id);
    }
  };

  return (
    <Card className="glass-card border-0 p-6 w-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-semibold text-white">Creator Room</h3>
          <Tooltip>
            <TooltipTrigger asChild>
              <Info className="h-4 w-4 text-white/60 cursor-help" />
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs w-60">Your personal space where fans can see your vibe and NFTs. You control what's visible.</p>
            </TooltipContent>
          </Tooltip>
        </div>
        <div className="flex items-center">
          <span className="text-sm mr-2 text-white/80 flex items-center">
            {roomState.isPublic ? (
              <>
                <Eye className="h-4 w-4 mr-1 text-fan-purple" /> Public
              </>
            ) : (
              <>
                <EyeOff className="h-4 w-4 mr-1 text-white/60" /> Private
              </>
            )}
          </span>
          <Switch 
            checked={roomState.isPublic} 
            onCheckedChange={handleTogglePublic}
            className="data-[state=checked]:bg-fan-purple"
          />
        </div>
      </div>
      
      <div 
        className="rounded-xl overflow-hidden relative h-56 transition-all duration-500"
        style={{ 
          backgroundImage: `url(${roomState.background})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      >
        {!hasRiggableAvatar && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center z-10">
            <Lock className="h-12 w-12 text-fan-purple mb-4" />
            <p className="text-white text-center max-w-xs mb-4">
              You need a riggable avatar to access the Creator Room
            </p>
            <Button 
              variant="outline" 
              className="bg-fan-purple/20 border-fan-purple text-white hover:bg-fan-purple/40"
            >
              Upload Riggable Avatar
            </Button>
          </div>
        )}
        
        {roomState.items.map((item) => (
          <div
            key={item.id}
            className={`absolute cursor-pointer transition-transform hover:scale-110 duration-300 ${
              item.isMintable ? 'animate-pulse' : ''
            } ${!hasRiggableAvatar ? 'opacity-50 pointer-events-none' : ''}`}
            style={{
              left: `${item.position.x}%`,
              top: `${item.position.y}%`,
              transform: 'translate(-50%, -50%)'
            }}
            onClick={() => handleItemClick(item)}
          >
            <img 
              src={item.imageUrl} 
              alt={item.type} 
              className="h-16 w-16 object-contain"
            />
            {item.isMintable && (
              <div className="absolute -top-2 -right-2 bg-fan-purple text-white text-xs px-2 py-0.5 rounded-full">
                Mint
              </div>
            )}
          </div>
        ))}
      </div>
    </Card>
  );
};

export default RoomDisplay;
