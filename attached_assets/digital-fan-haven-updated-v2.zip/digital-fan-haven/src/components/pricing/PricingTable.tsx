
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Check, X, InfoIcon } from "lucide-react";
import { MembershipTier } from '@/types';

interface PricingTableProps {
  currentTier?: 'free' | 'premium' | 'pro';
  onUpgrade?: (tier: string) => void;
  className?: string;
}

const PricingTable = ({ 
  currentTier = 'free',
  onUpgrade,
  className 
}: PricingTableProps) => {
  
  // Define the features and tiers
  const tiers: MembershipTier[] = [
    {
      id: 'free',
      name: 'Free',
      price: 0,
      features: [
        'One basic room',
        'Basic avatar customization',
        'Mutual Respect Wall',
        'Social links',
        'Send/receive messages & calls',
        'Public profile'
      ]
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 9.99,
      features: [
        'Everything in Free',
        'Multiple rooms (up to 3)',
        'Store access',
        'NFT minting capability',
        'Custom room themes',
        'Priority discovery',
        'Basic analytics',
        'Custom profile layouts'
      ]
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 19.99,
      features: [
        'Everything in Premium',
        'Unlimited rooms',
        'Yard expansions',
        'Riggable avatars',
        'Premium neighborhood placement',
        'Full analytics dashboard',
        'Affiliate program access',
        'Unlimited store items',
        'API & integrations access'
      ]
    }
  ];
  
  // All possible features across all tiers for comparison
  const allFeatures = [
    'Basic profile & avatar',
    'One basic room',
    'Mutual Respect Wall',
    'Social links',
    'Send/receive messages & calls',
    'Store access',
    'Multiple rooms',
    'NFT minting capability',
    'Custom room themes',
    'Priority discovery',
    'Analytics dashboard',
    'Custom profile layouts',
    'Yard expansions',
    'Riggable avatars',
    'Premium neighborhood placement',
    'Affiliate program access',
    'Unlimited store items',
    'API & integrations access'
  ];
  
  // Helper to check if a tier has a specific feature
  const hasFeature = (tier: MembershipTier, feature: string) => {
    return tier.features.some(f => f.includes(feature) || 
                                 feature.includes(f) ||
                                 f.toLowerCase() === feature.toLowerCase());
  };
  
  const handleUpgrade = (tierId: string) => {
    if (onUpgrade) {
      onUpgrade(tierId);
    }
  };
  
  return (
    <TooltipProvider>
      <Card className={`bg-white/5 backdrop-blur-md border-white/10 ${className}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white">Dormlit Membership Tiers</CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <InfoIcon className="h-5 w-5 text-white/70 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <p>Which tier is right for you?</p>
                <p className="text-xs text-muted-foreground mt-1">
                  View what each level unlocks—rooms, earnings, avatars, and more.
                  Most creators start with Premium.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription className="text-white/70">
            Choose the plan that fits your creative needs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="p-4 text-left text-white font-medium">Features</th>
                  {tiers.map(tier => (
                    <th key={tier.id} className="p-4 text-center text-white font-medium">
                      <div className="mb-2">{tier.name}</div>
                      <div className="text-2xl font-bold mb-1">
                        {tier.price === 0 ? 'Free' : `$${tier.price}`}
                      </div>
                      <div className="text-sm text-white/70">
                        {tier.price === 0 ? 'Forever' : 'per month'}
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allFeatures.map((feature, index) => (
                  <tr key={index} className="border-b border-white/10">
                    <td className="p-4 text-white">{feature}</td>
                    {tiers.map(tier => (
                      <td key={`${tier.id}-${index}`} className="p-4 text-center">
                        {hasFeature(tier, feature) ? (
                          <Check className="h-5 w-5 text-green-400 mx-auto" />
                        ) : (
                          <X className="h-5 w-5 text-white/30 mx-auto" />
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
            {tiers.map(tier => (
              <div key={tier.id} className="flex flex-col items-center">
                {tier.id === currentTier ? (
                  <Button 
                    disabled
                    className="w-full bg-white/10 text-white/50 cursor-not-allowed"
                  >
                    Current Plan
                  </Button>
                ) : (
                  <Button 
                    onClick={() => handleUpgrade(tier.id)} 
                    className={`w-full ${
                      tier.id === 'premium' ? 'bg-fan-purple hover:bg-fan-purple/80' : 
                      tier.id === 'pro' ? 'bg-gradient-to-r from-fan-purple to-purple-600 hover:opacity-90' : 
                      'bg-white/20 hover:bg-white/30'
                    }`}
                  >
                    {tier.price === 0 ? 'Sign Up' : `Upgrade to ${tier.name}`}
                  </Button>
                )}
              </div>
            ))}
          </div>
          
          <div className="mt-6 text-center text-white/50 text-sm">
            All plans include unlimited profile access and basic features.
            <br />
            Upgrade or downgrade at any time.
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default PricingTable;
