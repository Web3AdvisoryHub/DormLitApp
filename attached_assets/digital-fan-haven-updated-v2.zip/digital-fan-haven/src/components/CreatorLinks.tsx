
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink, Link as LinkIcon } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface LinkItem {
  id: string;
  title: string;
  url: string;
  icon?: string;
}

interface CreatorLinksProps {
  links: LinkItem[];
}

const CreatorLinks: React.FC<CreatorLinksProps> = ({ links }) => {
  const isMobile = useIsMobile();

  return (
    <Card className={`bg-white/5 backdrop-blur-md border-white/10 ${isMobile ? 'max-w-md mx-auto w-full' : 'w-full'}`}>
      <CardContent className="p-4">
        <div className="space-y-3">
          {links.map((link) => (
            <a
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block p-4 bg-white/10 hover:bg-white/15 rounded-xl transition-colors text-white font-medium flex items-center justify-between backdrop-blur-sm border border-white/5 shadow-lg shadow-black/5"
            >
              <div className="flex items-center">
                {link.icon ? (
                  <img src={link.icon} alt="" className="w-5 h-5 mr-3" />
                ) : (
                  <LinkIcon className="w-5 h-5 mr-3 text-fan-purple" />
                )}
                <span>{link.title}</span>
              </div>
              <ExternalLink className="w-4 h-4 text-white/50" />
            </a>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CreatorLinks;
