
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Mail, Send, AlertCircle } from "lucide-react";

interface EmailAlertSystemProps {
  subscriberCount?: number;
  isCreator?: boolean;
}

const EmailAlertSystem: React.FC<EmailAlertSystemProps> = ({ 
  subscriberCount = 0,
  isCreator = false
}) => {
  const { toast } = useToast();
  const [message, setMessage] = useState('');
  const [subject, setSubject] = useState('');
  const [includeOpeningFee, setIncludeOpeningFee] = useState(false);
  const [openingFee, setOpeningFee] = useState(0.99);
  const [isSending, setIsSending] = useState(false);
  
  const handleSendAlert = async () => {
    if (!subject.trim()) {
      toast({
        title: "Subject required",
        description: "Please enter a subject for your alert",
        variant: "destructive",
      });
      return;
    }
    
    if (!message.trim()) {
      toast({
        title: "Message required",
        description: "Please enter a message for your alert",
        variant: "destructive",
      });
      return;
    }
    
    setIsSending(true);
    
    // Simulate sending process
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast({
      title: "Alert sent!",
      description: `Your message has been sent to ${subscriberCount} subscribers`,
    });
    
    setIsSending(false);
    setMessage('');
    setSubject('');
  };

  if (!isCreator) return null;

  return (
    <Card className="border-0 glass-card shadow-lg">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Mail className="mr-2 h-5 w-5 text-fan-purple" />
          Alert Your Subscribers
        </CardTitle>
        <CardDescription>
          Send a message to all your subscribers ({subscriberCount})
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="subject">Subject</Label>
          <Input 
            id="subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Enter alert subject..."
            className="bg-secondary/20 border-fan-purple/20"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="message">Message</Label>
          <Textarea 
            id="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Write your message here..."
            className="bg-secondary/20 border-fan-purple/20 min-h-[120px]"
          />
        </div>
        
        <div className="flex items-start space-x-2">
          <div>
            <Switch
              id="opening-fee"
              checked={includeOpeningFee}
              onCheckedChange={setIncludeOpeningFee}
              className="data-[state=checked]:bg-fan-purple"
            />
          </div>
          <div className="space-y-1 flex-1">
            <Label 
              htmlFor="opening-fee" 
              className="font-medium cursor-pointer"
            >
              Include opening fee for replies
            </Label>
            <p className="text-sm text-white/70">
              Subscribers can view your message for free, but will pay a fee to reply
            </p>
            
            {includeOpeningFee && (
              <div className="mt-2 flex items-center">
                <span className="text-sm mr-2">Fee amount: $</span>
                <Input
                  type="number"
                  value={openingFee}
                  onChange={(e) => setOpeningFee(Number(e.target.value))}
                  className="w-24 bg-secondary/20 border-fan-purple/20"
                  step="0.01"
                  min="0.01"
                />
              </div>
            )}
          </div>
        </div>
        
        <div className="pt-2">
          <Button 
            onClick={handleSendAlert}
            className="w-full bg-fan-purple hover:bg-fan-purple/80"
            disabled={isSending}
          >
            {isSending ? (
              "Sending..."
            ) : (
              <>
                Send to {subscriberCount} Subscribers <Send className="ml-2 h-4 w-4" />
              </>
            )}
          </Button>
          
          <div className="mt-3 flex items-start text-xs text-white/70">
            <AlertCircle className="h-4 w-4 mr-1 flex-shrink-0 mt-0.5" />
            <p>
              Your alerts will be delivered to subscribers who have opted in to receive updates from you.
              {includeOpeningFee ? ` Replies will incur a $${openingFee.toFixed(2)} opening fee.` : ''}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EmailAlertSystem;
