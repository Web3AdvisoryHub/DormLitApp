
import React from 'react';
import { Button } from "@/components/ui/button";
import { 
  Instagram, 
  Twitter, 
  Youtube, 
  Twitch, 
  Facebook, 
  Globe, 
  Link as LinkIcon
} from "lucide-react";

export type SocialPlatform = 'instagram' | 'twitter' | 'youtube' | 'twitch' | 'facebook' | 'website' | 'other';

type SocialLinkProps = {
  platform: SocialPlatform;
  username: string;
  url: string;
};

const SocialLink = ({ platform, username, url }: SocialLinkProps) => {
  const getPlatformIcon = () => {
    switch (platform) {
      case 'instagram': return <Instagram className="mr-2 h-4 w-4" />;
      case 'twitter': return <Twitter className="mr-2 h-4 w-4" />;
      case 'youtube': return <Youtube className="mr-2 h-4 w-4" />;
      case 'twitch': return <Twitch className="mr-2 h-4 w-4" />;
      case 'facebook': return <Facebook className="mr-2 h-4 w-4" />;
      case 'website': return <Globe className="mr-2 h-4 w-4" />;
      default: return <LinkIcon className="mr-2 h-4 w-4" />;
    }
  };

  const getPlatformLabel = () => {
    switch (platform) {
      case 'instagram': return '@' + username;
      case 'twitter': return '@' + username;
      case 'youtube': return username;
      case 'twitch': return username;
      case 'facebook': return username;
      case 'website': return 'Website';
      default: return username;
    }
  };

  return (
    <a href={url} target="_blank" rel="noopener noreferrer" className="block w-full mb-2">
      <Button 
        variant="outline" 
        className="w-full justify-start bg-secondary/30 hover:bg-fan-purple/20 border-fan-purple/40"
      >
        {getPlatformIcon()}
        <span>{getPlatformLabel()}</span>
      </Button>
    </a>
  );
};

export default SocialLink;
