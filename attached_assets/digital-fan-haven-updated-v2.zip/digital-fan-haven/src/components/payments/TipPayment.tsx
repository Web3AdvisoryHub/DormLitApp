
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { DollarSign } from "lucide-react";

interface TipPaymentProps {
  onSendTip: (amount: number, isPublic: boolean) => Promise<void>;
  isProcessing?: boolean;
}

const TipPayment: React.FC<TipPaymentProps> = ({
  onSendTip,
  isProcessing = false
}) => {
  const [tipAmount, setTipAmount] = useState(5);
  const [isPublic, setIsPublic] = useState(false);
  
  const tipOptions = [
    { amount: 1, icon: '👍', label: 'Nice!' },
    { amount: 5, icon: '🔥', label: 'Fire!' },
    { amount: 10, icon: '⭐', label: 'Star!' },
    { amount: 20, icon: '🏆', label: 'Champion!' },
    { amount: 50, icon: '👑', label: 'Royal!' },
  ];
  
  return (
    <div className="bg-secondary/40 p-4 rounded-lg">
      <div className="grid grid-cols-3 gap-2 mb-4">
        {tipOptions.map((option) => (
          <Button
            key={option.amount}
            variant="outline"
            className={`flex flex-col items-center py-3 border-fan-purple/30 ${
              tipAmount === option.amount ? 'bg-fan-purple text-white' : 'bg-secondary/40'
            }`}
            onClick={() => setTipAmount(option.amount)}
          >
            <span className="text-xl mb-1">{option.icon}</span>
            <span className="text-xs">{option.label}</span>
            <span className="font-bold mt-1">${option.amount}</span>
          </Button>
        ))}
      </div>
      
      <div className="flex items-center justify-between mb-4">
        <span className="text-sm text-white/80">Custom Amount ($)</span>
        <div className="flex items-center">
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 w-7 p-0 border-fan-purple/30"
            onClick={() => setTipAmount(Math.max(1, tipAmount - 1))}
          >
            -
          </Button>
          <Input
            type="number"
            value={tipAmount}
            onChange={(e) => setTipAmount(Number(e.target.value))}
            className="mx-2 w-20 bg-secondary/70 border-fan-purple/20 text-white text-center"
            min={1}
          />
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 w-7 p-0 border-fan-purple/30"
            onClick={() => setTipAmount(tipAmount + 1)}
          >
            +
          </Button>
        </div>
      </div>
      
      <div className="flex items-center justify-end space-x-2 mb-4">
        <Switch 
          id="public-tip" 
          checked={isPublic}
          onCheckedChange={setIsPublic}
          className="data-[state=checked]:bg-fan-purple"
        />
        <Label htmlFor="public-tip" className="text-sm text-white/70">Show on creator wall</Label>
      </div>
      
      <Button 
        onClick={() => onSendTip(tipAmount, isPublic)}
        className="w-full bg-fan-purple hover:bg-fan-dark-purple"
        disabled={isProcessing}
      >
        {isProcessing ? (
          "Processing Tip..."
        ) : (
          <>
            Send ${tipAmount} Tip <DollarSign className="ml-2 h-4 w-4" />
          </>
        )}
      </Button>
    </div>
  );
};

export default TipPayment;
