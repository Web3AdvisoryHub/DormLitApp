
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Gift, Wallet, Image } from "lucide-react";

interface StickerPaymentProps {
  onSendSticker: (stickerId: string, isPublic: boolean) => Promise<void>;
  walletConnected?: boolean;
  onConnectWallet?: () => void;
  isProcessing?: boolean;
}

const StickerPayment: React.FC<StickerPaymentProps> = ({
  onSendSticker,
  walletConnected = false,
  onConnectWallet,
  isProcessing = false
}) => {
  const [selectedSticker, setSelectedSticker] = useState('');
  const [isPublic, setIsPublic] = useState(false);
  
  const predefinedStickers = [
    { id: 'sticker1', name: 'Heart', image: '/placeholder.svg' },
    { id: 'sticker2', name: 'Star', image: '/placeholder.svg' },
    { id: 'sticker3', name: 'Flame', image: '/placeholder.svg' },
    { id: 'sticker4', name: 'Trophy', image: '/placeholder.svg' },
  ];
  
  const handleSendSticker = () => {
    if (selectedSticker) {
      onSendSticker(selectedSticker, isPublic);
    }
  };
  
  return (
    <div className="bg-secondary/40 p-4 rounded-lg">
      <h4 className="text-sm font-medium text-white/90 mb-3">Send a Sticker or NFT</h4>
      
      {!walletConnected && (
        <div className="mb-4 p-3 border border-fan-purple/30 rounded-md">
          <p className="text-sm text-white/80 mb-2">
            Connect your wallet to send NFT stickers to this creator
          </p>
          <Button
            className="w-full bg-fan-purple hover:bg-fan-dark-purple"
            onClick={onConnectWallet}
            size="sm"
          >
            <Wallet className="mr-2 h-4 w-4" /> Connect Wallet for NFTs
          </Button>
        </div>
      )}
      
      <div className="grid grid-cols-2 gap-3 mb-4">
        {predefinedStickers.map((sticker) => (
          <Button
            key={sticker.id}
            variant="outline"
            className={`h-20 flex flex-col items-center justify-center border-fan-purple/30 ${
              selectedSticker === sticker.id ? 'bg-fan-purple/50 border-fan-purple' : 'bg-secondary/40'
            }`}
            onClick={() => setSelectedSticker(sticker.id)}
          >
            <div className="w-10 h-10 bg-white/10 rounded-md mb-1 flex items-center justify-center">
              <img src={sticker.image} alt={sticker.name} className="w-8 h-8" />
            </div>
            <span className="text-xs">{sticker.name}</span>
          </Button>
        ))}
      </div>
      
      {walletConnected && (
        <div className="mb-4">
          <Button
            variant="outline"
            className="w-full text-sm border-fan-purple/30 bg-secondary/20 hover:bg-secondary/40"
            size="sm"
          >
            <Image className="mr-2 h-4 w-4" /> Browse Your NFTs
          </Button>
        </div>
      )}
      
      <div className="flex items-center justify-end space-x-2 mb-4">
        <Switch 
          id="public-sticker" 
          checked={isPublic}
          onCheckedChange={setIsPublic}
          className="data-[state=checked]:bg-fan-purple"
        />
        <Label htmlFor="public-sticker" className="text-sm text-white/70">Show on creator wall</Label>
      </div>
      
      <Button 
        onClick={handleSendSticker}
        className="w-full bg-fan-purple hover:bg-fan-dark-purple"
        disabled={isProcessing || !selectedSticker}
      >
        {isProcessing ? (
          "Sending Sticker..."
        ) : (
          <>
            Send Sticker <Gift className="ml-2 h-4 w-4" />
          </>
        )}
      </Button>
    </div>
  );
};

export default StickerPayment;
