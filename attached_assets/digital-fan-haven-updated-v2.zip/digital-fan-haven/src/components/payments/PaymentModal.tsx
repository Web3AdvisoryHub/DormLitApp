
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger
} from "@/components/ui/tabs";
import { MessageSquare, Phone, DollarSign, Image } from "lucide-react";
import TextMessagePayment from './TextMessagePayment';
import CallSchedulePayment from './CallSchedulePayment';
import TipPayment from './TipPayment';
import StickerPayment from './StickerPayment';

interface PaymentModalProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  creatorName: string;
  activeOption: 'text' | 'call' | 'tip' | 'sticker' | null;
  onSelectOption: (option: 'text' | 'call' | 'tip' | 'sticker' | null) => void;
  messageRate: number;
  callRate: number;
  walletConnected?: boolean;
  onConnectWallet?: () => void;
  onSendMessage: (message: string, isPublic: boolean) => Promise<void>;
  onScheduleCall: (duration: number) => Promise<void>;
  onSendTip: (amount: number, isPublic: boolean) => Promise<void>;
  onSendSticker: (stickerId: string, isPublic: boolean) => Promise<void>;
  isProcessing?: boolean;
}

const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onOpenChange,
  creatorName,
  activeOption,
  onSelectOption,
  messageRate,
  callRate,
  walletConnected = false,
  onConnectWallet,
  onSendMessage,
  onScheduleCall,
  onSendTip,
  onSendSticker,
  isProcessing = false
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md bg-fan-background border-fan-purple/30">
        <DialogHeader>
          <DialogTitle className="text-white">Connect with {creatorName}</DialogTitle>
          <DialogDescription>
            Choose how you'd like to interact with this creator.
          </DialogDescription>
        </DialogHeader>

        <Tabs 
          defaultValue={activeOption || "text"} 
          value={activeOption || "text"} 
          onValueChange={(value) => onSelectOption(value as any)}
          className="w-full mt-2"
        >
          <TabsList className="grid grid-cols-4 bg-secondary/40">
            <TabsTrigger 
              value="text" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              <MessageSquare className="h-4 w-4 mr-2" /> Text
            </TabsTrigger>
            <TabsTrigger 
              value="call" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              <Phone className="h-4 w-4 mr-2" /> Call
            </TabsTrigger>
            <TabsTrigger 
              value="tip" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              <DollarSign className="h-4 w-4 mr-2" /> Tip
            </TabsTrigger>
            <TabsTrigger 
              value="sticker" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              <Image className="h-4 w-4 mr-2" /> Sticker
            </TabsTrigger>
          </TabsList>

          <TabsContent value="text" className="space-y-4 py-4">
            <TextMessagePayment 
              messageRate={messageRate}
              onSendMessage={onSendMessage}
              isProcessing={isProcessing}
            />
          </TabsContent>

          <TabsContent value="call" className="space-y-4 py-4">
            <CallSchedulePayment 
              callRate={callRate}
              onScheduleCall={onScheduleCall}
              isProcessing={isProcessing}
            />
          </TabsContent>

          <TabsContent value="tip" className="space-y-4 py-4">
            <TipPayment 
              onSendTip={onSendTip}
              isProcessing={isProcessing}
            />
          </TabsContent>

          <TabsContent value="sticker" className="space-y-4 py-4">
            <StickerPayment 
              onSendSticker={onSendSticker}
              walletConnected={walletConnected}
              onConnectWallet={onConnectWallet}
              isProcessing={isProcessing}
            />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};

export default PaymentModal;
