
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

interface CallSchedulePaymentProps {
  callRate: number;
  onScheduleCall: (duration: number) => Promise<void>;
  isProcessing?: boolean;
}

const CallSchedulePayment: React.FC<CallSchedulePaymentProps> = ({
  callRate,
  onScheduleCall,
  isProcessing = false
}) => {
  const [callDuration, setCallDuration] = useState(15);
  
  return (
    <div className="bg-secondary/40 p-4 rounded-lg">
      <div className="flex items-center justify-between mb-3">
        <span className="text-sm text-white/80">Call Duration (minutes)</span>
        <div className="flex items-center">
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 w-7 p-0 border-fan-purple/30"
            onClick={() => setCallDuration(Math.max(1, callDuration - 1))}
          >
            -
          </Button>
          <span className="mx-3 text-white">{callDuration}</span>
          <Button 
            variant="outline" 
            size="sm" 
            className="h-7 w-7 p-0 border-fan-purple/30"
            onClick={() => setCallDuration(callDuration + 1)}
          >
            +
          </Button>
        </div>
      </div>
      <div className="text-sm text-white/70 mb-4">
        <span className="font-medium text-white">${callRate.toFixed(2)}</span> per minute
        <span className="block mt-1">
          Total: <span className="font-medium text-white">${(callRate * callDuration).toFixed(2)}</span>
        </span>
      </div>
      <Button 
        onClick={() => onScheduleCall(callDuration)}
        className="w-full bg-fan-purple hover:bg-fan-dark-purple"
        disabled={isProcessing}
      >
        {isProcessing ? (
          "Processing Request..."
        ) : (
          <>
            Schedule Call <Phone className="ml-2 h-4 w-4" />
          </>
        )}
      </Button>
    </div>
  );
};

export default CallSchedulePayment;
