
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Send, DollarSign } from "lucide-react";

interface TextMessagePaymentProps {
  messageRate: number;
  onSendMessage: (message: string, isPublic: boolean) => Promise<void>;
  isProcessing?: boolean;
}

const TextMessagePayment: React.FC<TextMessagePaymentProps> = ({
  messageRate,
  onSendMessage,
  isProcessing = false
}) => {
  const [message, setMessage] = useState('');
  const [isPublic, setIsPublic] = useState(false);
  
  const handleSend = () => {
    if (message.trim()) {
      onSendMessage(message, isPublic);
    }
  };
  
  return (
    <div className="space-y-4">
      <Input
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your message here..."
        className="bg-secondary/80 border-fan-purple/20 text-white placeholder:text-white/50"
      />
      
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm text-white/70">
          <DollarSign className="h-4 w-4 text-fan-purple" />
          <span>
            You'll pay <span className="font-medium text-white">${messageRate.toFixed(2)}</span> to send this message
          </span>
        </div>
        
        <div className="flex items-center space-x-2">
          <Switch 
            id="public-message" 
            checked={isPublic}
            onCheckedChange={setIsPublic}
            className="data-[state=checked]:bg-fan-purple"
          />
          <Label htmlFor="public-message" className="text-sm text-white/70">Post publicly</Label>
        </div>
      </div>
      
      <Button 
        onClick={handleSend}
        className="w-full bg-fan-purple hover:bg-fan-dark-purple"
        disabled={!message.trim() || isProcessing}
      >
        {isProcessing ? (
          "Processing Payment..."
        ) : (
          <>
            Send Message <Send className="ml-2 h-4 w-4" />
          </>
        )}
      </Button>
    </div>
  );
};

export default TextMessagePayment;
