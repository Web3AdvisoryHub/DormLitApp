
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DollarSign, MessageCircle, Image, User } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

// Different types of fan interactions
export type FanInteractionType = 'message' | 'tip' | 'sticker' | 'nft';

export interface FanInteraction {
  id: string;
  type: FanInteractionType;
  username: string;
  userAvatar?: string;
  content: string;
  amount?: number;
  imageUrl?: string;
  timestamp: Date;
}

interface FanWallProps {
  interactions: FanInteraction[];
  isCreator?: boolean;
  isCurrentUser?: boolean;
  onRemoveInteraction?: (id: string) => void;
}

const FanWall: React.FC<FanWallProps> = ({ 
  interactions,
  isCreator = false,
  isCurrentUser = false,
  onRemoveInteraction
}) => {
  const isMobile = useIsMobile();
  
  const formatRelativeTime = (date: Date) => {
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return 'just now';
    
    const diffInMinutes = Math.floor(diffInSeconds / 60);
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 30) return `${diffInDays}d ago`;
    
    const diffInMonths = Math.floor(diffInDays / 30);
    if (diffInMonths < 12) return `${diffInMonths}mo ago`;
    
    return `${Math.floor(diffInMonths / 12)}y ago`;
  };

  const getInteractionIcon = (type: FanInteractionType) => {
    switch (type) {
      case 'message':
        return <MessageCircle className="h-4 w-4 text-fan-purple" />;
      case 'tip':
        return <DollarSign className="h-4 w-4 text-green-500" />;
      case 'sticker':
      case 'nft':
        return <Image className="h-4 w-4 text-blue-500" />;
    }
  };

  return (
    <Card className={`bg-white/5 backdrop-blur-md border-white/10 ${isMobile ? 'max-w-md mx-auto w-full' : 'w-full'}`}>
      <CardHeader className={isMobile ? "pb-2" : ""}>
        <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-fan-purple" />
          Mutual Respect Wall
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {interactions.length === 0 ? (
          <div className="text-center py-6 text-white/60">
            <p>No interactions yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {interactions.map((interaction) => (
              <div 
                key={interaction.id} 
                className="bg-white/5 rounded-lg p-3 relative"
              >
                {/* Interaction Header */}
                <div className="flex items-center mb-2">
                  <Avatar className="h-8 w-8 mr-2">
                    <AvatarImage src={interaction.userAvatar} />
                    <AvatarFallback>
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium text-white">{interaction.username}</p>
                    <div className="flex items-center text-xs text-white/60">
                      {getInteractionIcon(interaction.type)}
                      <span className="ml-1">
                        {interaction.type === 'tip' 
                          ? `Tipped $${interaction.amount?.toFixed(2)}` 
                          : interaction.type.charAt(0).toUpperCase() + interaction.type.slice(1)}
                      </span>
                      <span className="mx-1">•</span>
                      <span>{formatRelativeTime(interaction.timestamp)}</span>
                    </div>
                  </div>
                  
                  {/* Remove button for creator */}
                  {isCurrentUser && onRemoveInteraction && (
                    <button 
                      className="ml-auto text-white/50 hover:text-white/80 text-xs"
                      onClick={() => onRemoveInteraction(interaction.id)}
                    >
                      Remove
                    </button>
                  )}
                </div>
                
                {/* Interaction Content */}
                {interaction.content && (
                  <p className="text-sm text-white/90 mb-2">{interaction.content}</p>
                )}
                
                {/* Image/NFT Content */}
                {interaction.imageUrl && (
                  <div className="rounded overflow-hidden mt-2">
                    <img 
                      src={interaction.imageUrl} 
                      alt={`${interaction.type} from ${interaction.username}`}
                      className="w-full h-auto max-h-40 object-contain"
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FanWall;
