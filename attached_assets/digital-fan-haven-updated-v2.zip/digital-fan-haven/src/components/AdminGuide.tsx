
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Clipboard, Code, Database, Server, Globe } from 'lucide-react';

const AdminGuide = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6 text-white">Dormlit Admin Guide</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Code className="h-5 w-5 text-fan-purple" />
              <CardTitle className="text-white">Code Management</CardTitle>
            </div>
            <CardDescription>How to edit your codebase after handoff</CardDescription>
          </CardHeader>
          <CardContent className="text-white/70 space-y-3">
            <p>The Dormlit codebase is hosted in a GitHub repository. To make changes:</p>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Clone the repository to your local machine</li>
              <li>Use a code editor like VS Code to make your changes</li>
              <li>Commit and push your changes to GitHub</li>
              <li>The CI/CD pipeline will automatically deploy your changes</li>
            </ol>
            <p className="text-sm mt-4 bg-black/30 p-3 rounded">
              <span className="font-bold text-fan-purple">Repository URL:</span><br/>
              https://github.com/yourusername/dormlet-platform
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Database className="h-5 w-5 text-fan-purple" />
              <CardTitle className="text-white">Content Management</CardTitle>
            </div>
            <CardDescription>Updating content without coding</CardDescription>
          </CardHeader>
          <CardContent className="text-white/70 space-y-3">
            <p>For non-technical updates, you can use the Admin Dashboard:</p>
            <ul className="list-disc pl-5 space-y-2">
              <li>Accessible at: <span className="text-fan-purple">yourdomain.com/admin</span></li>
              <li>Login with your admin credentials</li>
              <li>Navigate to the appropriate section (Users, Content, Store)</li>
              <li>Make your changes and save</li>
            </ul>
            <p className="text-sm mt-4 bg-black/30 p-3 rounded">
              <span className="font-bold text-fan-purple">Admin Credentials:</span><br/>
              These will be provided securely during handoff
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Server className="h-5 w-5 text-fan-purple" />
              <CardTitle className="text-white">Deployment</CardTitle>
            </div>
            <CardDescription>Managing your hosting</CardDescription>
          </CardHeader>
          <CardContent className="text-white/70 space-y-3">
            <p>Dormlit is deployed using Vercel for seamless updates:</p>
            <ul className="list-disc pl-5 space-y-2">
              <li>Your Vercel dashboard: <span className="text-fan-purple">vercel.com/dormlet</span></li>
              <li>Automatic deployments are configured from the main branch</li>
              <li>You can roll back to previous deployments if needed</li>
              <li>Environment variables can be configured in the Vercel dashboard</li>
            </ul>
            <p className="text-sm mt-4 bg-black/30 p-3 rounded">
              <span className="font-bold text-fan-purple">Production URL:</span><br/>
              https://dormlet.grow 
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-fan-purple" />
              <CardTitle className="text-white">Domain Management</CardTitle>
            </div>
            <CardDescription>Managing your domain settings</CardDescription>
          </CardHeader>
          <CardContent className="text-white/70 space-y-3">
            <p>Your domain is managed through your domain registrar:</p>
            <ul className="list-disc pl-5 space-y-2">
              <li>Registrar: <span className="text-fan-purple">Namecheap</span></li>
              <li>Domain: <span className="text-fan-purple">dormlet.grow</span></li>
              <li>DNS records are pointed to Vercel's nameservers</li>
              <li>SSL certificate is automatically managed by Vercel</li>
            </ul>
            <p className="text-sm mt-4 bg-black/30 p-3 rounded">
              <span className="font-bold text-fan-purple">Domain Renewal:</span><br/>
              Set to auto-renew annually on October 15
            </p>
          </CardContent>
        </Card>
      </div>
      
      <Card className="bg-white/5 border-white/10 mb-8">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Clipboard className="h-5 w-5 text-fan-purple" />
            <CardTitle className="text-white">Quick File Editing Guide</CardTitle>
          </div>
          <CardDescription>Most common files you might want to edit</CardDescription>
        </CardHeader>
        <CardContent className="text-white/70">
          <div className="space-y-4">
            <div>
              <h3 className="font-medium text-white mb-2">Content & Text</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li><code className="bg-black/30 px-2 py-1 rounded">src/pages/Landing.tsx</code> - Landing page content</li>
                <li><code className="bg-black/30 px-2 py-1 rounded">src/components/landing/FeatureSection.tsx</code> - Main features list</li>
                <li><code className="bg-black/30 px-2 py-1 rounded">src/components/landing/TestimonialSection.tsx</code> - Testimonials</li>
                <li><code className="bg-black/30 px-2 py-1 rounded">src/pages/TermsOfService.tsx</code> - Terms of Service content</li>
                <li><code className="bg-black/30 px-2 py-1 rounded">src/pages/PrivacyPolicy.tsx</code> - Privacy Policy content</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-white mb-2">Pricing & Plans</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li><code className="bg-black/30 px-2 py-1 rounded">src/pages/Upgrade.tsx</code> - Upgrade page and pricing tiers</li>
                <li><code className="bg-black/30 px-2 py-1 rounded">src/utils/defaultProfile.ts</code> - Default user profile settings</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-medium text-white mb-2">Styling & Theme</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li><code className="bg-black/30 px-2 py-1 rounded">tailwind.config.js</code> - Main colors and theme settings</li>
                <li><code className="bg-black/30 px-2 py-1 rounded">src/styles/globals.css</code> - Global CSS variables</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminGuide;
