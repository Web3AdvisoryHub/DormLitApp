
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

const CookieConsent = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Check if user has already accepted cookies
    const hasAccepted = localStorage.getItem('cookieConsent') === 'true';
    if (!hasAccepted) {
      // Show cookie consent after a short delay
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1000);
      
      return () => clearTimeout(timer);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem('cookieConsent', 'true');
    setIsVisible(false);
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 md:right-auto md:w-96 bg-background/95 backdrop-blur-sm p-4 rounded-lg shadow-lg border border-border z-50 animate-in fade-in slide-in-from-bottom-4">
      <div className="flex justify-between items-start mb-2">
        <h3 className="font-semibold text-lg">Cookie Consent</h3>
        <Button variant="ghost" size="icon" onClick={handleClose} className="h-8 w-8">
          <X className="h-4 w-4" />
        </Button>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        We use cookies to enhance your experience on our site, analyze site usage, and assist in our marketing efforts.
      </p>
      <div className="flex gap-2">
        <Button onClick={handleAccept} className="w-full">
          Accept
        </Button>
        <Button variant="outline" onClick={handleClose} className="w-full">
          Decline
        </Button>
      </div>
    </div>
  );
};

export default CookieConsent;
