import React, { useState } from 'react';
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, DollarSign, MessageSquare, Wallet, Gift, Phone, Image, MessageCircle } from "lucide-react";
import Avatar from './Avatar';
import SocialLink, { SocialPlatform } from './SocialLink';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AvatarCustomizer, { AvatarConfig } from './AvatarCustomizer';
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export type SocialLinkData = {
  platform: SocialPlatform;
  username: string;
  url: string;
};

type ProfileBioProps = {
  name: string;
  avatarSrc: string;
  bio: string;
  socialLinks: SocialLinkData[];
  messageRate?: number; // Price per message
  callRate?: number; // Price per minute for calls
  onAvatarUpdate?: (config: AvatarConfig) => void;
  isCurrentUser?: boolean; // Whether the profile belongs to the current user
  onConnectWallet?: () => void; // For wallet connection
  walletConnected?: boolean; // Show if wallet is connected
};

const ProfileBio = ({ 
  name, 
  avatarSrc, 
  bio, 
  socialLinks, 
  messageRate = 0.50,
  callRate = 4.99,
  onAvatarUpdate,
  isCurrentUser = false,
  onConnectWallet,
  walletConnected = false
}: ProfileBioProps) => {
  const [message, setMessage] = useState('');
  const [tipAmount, setTipAmount] = useState(5);
  const [callDuration, setCallDuration] = useState(5);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isConnectDialogOpen, setIsConnectDialogOpen] = useState(false);
  const [isPublicInteraction, setIsPublicInteraction] = useState(false);
  const [stickerSelected, setStickerSelected] = useState('');

  const predefinedStickers = [
    { id: 'sticker1', name: 'Heart', image: '/placeholder.svg' },
    { id: 'sticker2', name: 'Star', image: '/placeholder.svg' },
    { id: 'sticker3', name: 'Flame', image: '/placeholder.svg' },
    { id: 'sticker4', name: 'Trophy', image: '/placeholder.svg' },
  ];
  
  const tipOptions = [
    { amount: 1, icon: '👍', label: 'Nice!' },
    { amount: 5, icon: '🔥', label: 'Fire!' },
    { amount: 10, icon: '⭐', label: 'Star!' },
    { amount: 20, icon: '🏆', label: 'Champion!' },
    { amount: 50, icon: '👑', label: 'Royal!' },
  ];

  const handleSendMessage = async () => {
    if (message.trim() === '') return;
    
    try {
      setIsProcessing(true);
      
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      console.log('Sending message:', message);
      console.log('Rate:', messageRate);
      console.log('Public:', isPublicInteraction);
      
      toast({
        title: "Message Sent!",
        description: `Your message was delivered for $${messageRate.toFixed(2)}${isPublicInteraction ? ' and posted to the creator wall' : ''}`,
      });
      
      setMessage('');
      setIsConnectDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error processing your payment. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSendTip = async () => {
    try {
      setIsProcessing(true);
      
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      toast({
        title: "Tip Sent!",
        description: `Your $${tipAmount.toFixed(2)} tip was sent successfully!${isPublicInteraction ? ' and posted to the creator wall' : ''}`,
      });
      
      setIsConnectDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error processing your tip. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleInitiateCall = async () => {
    try {
      setIsProcessing(true);
      
      // Simulate call setup
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const totalCost = callRate * callDuration;
      
      toast({
        title: "Call Initiated!",
        description: `Starting a ${callDuration} minute call for $${totalCost.toFixed(2)}`,
      });
      
      setIsConnectDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error setting up your call. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSendSticker = async () => {
    if (!stickerSelected) {
      toast({
        title: "Select a Sticker",
        description: "Please select a sticker to send",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsProcessing(true);
      
      // If wallet is not connected but needed for NFT stickers
      if (!walletConnected) {
        onConnectWallet && onConnectWallet();
        setIsProcessing(false);
        return;
      }
      
      // Simulate sticker sending
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const sticker = predefinedStickers.find(s => s.id === stickerSelected);
      
      toast({
        title: "Sticker Sent!",
        description: `Your ${sticker?.name || 'sticker'} was sent successfully!${isPublicInteraction ? ' and posted to the creator wall' : ''}`,
      });
      
      setStickerSelected('');
      setIsConnectDialogOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was an error sending your sticker. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleAvatarSave = (config: AvatarConfig) => {
    if (onAvatarUpdate) {
      onAvatarUpdate(config);
      toast({
        title: "Avatar Updated",
        description: "Your avatar has been successfully updated.",
      });
    }
  };

  return (
    <Card className="border-0 bg-white/5 backdrop-blur-md border-white/10">
      <CardHeader className="flex flex-col items-center text-center">
        <div className="relative mb-3">
          <Avatar src={avatarSrc} size="lg" showGlow />
          {isCurrentUser && (
            <div className="absolute -bottom-2 -right-2">
              <AvatarCustomizer onSave={handleAvatarSave} />
            </div>
          )}
        </div>
        <div>
          <h1 className="text-2xl font-bold text-white mb-1">{name}</h1>
          <p className="text-sm text-white/70">Digital Creator</p>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="mb-6">
          <p className="text-sm text-white/90 text-center whitespace-pre-line">{bio}</p>
        </div>
        
        {/* Connect Button - Main CTA */}
        {!isCurrentUser && (
          <Dialog open={isConnectDialogOpen} onOpenChange={setIsConnectDialogOpen}>
            <DialogTrigger asChild>
              <Button 
                className="w-full bg-fan-purple hover:bg-fan-dark-purple mb-6"
                size="lg"
              >
                Connect with {name.split(' ')[0]}
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md bg-fan-background border-fan-purple/30">
              <DialogHeader>
                <DialogTitle className="text-white">Connect with {name}</DialogTitle>
                <DialogDescription>
                  Choose how you'd like to interact with this creator.
                </DialogDescription>
              </DialogHeader>

              <Tabs defaultValue="message" className="w-full mt-2">
                <TabsList className="grid grid-cols-4 bg-secondary/40">
                  <TabsTrigger 
                    value="message" 
                    className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
                  >
                    <MessageSquare className="h-4 w-4 mr-2" /> Text
                  </TabsTrigger>
                  <TabsTrigger 
                    value="call" 
                    className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
                  >
                    <Phone className="h-4 w-4 mr-2" /> Call
                  </TabsTrigger>
                  <TabsTrigger 
                    value="tip" 
                    className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
                  >
                    <DollarSign className="h-4 w-4 mr-2" /> Tip
                  </TabsTrigger>
                  <TabsTrigger 
                    value="sticker" 
                    className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
                  >
                    <Image className="h-4 w-4 mr-2" /> Sticker
                  </TabsTrigger>
                </TabsList>

                {/* Message Tab */}
                <TabsContent value="message" className="space-y-4 py-4">
                  <Input
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your message here..."
                    className="flex-1 bg-secondary/80 border-fan-purple/20 text-white placeholder:text-white/50"
                  />
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm text-white/70">
                      <DollarSign className="h-4 w-4 text-fan-purple" />
                      <span>
                        You'll pay <span className="font-medium text-white">${messageRate.toFixed(2)}</span> to send this message
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Switch 
                        id="public-message" 
                        checked={isPublicInteraction}
                        onCheckedChange={setIsPublicInteraction}
                        className="data-[state=checked]:bg-fan-purple"
                      />
                      <Label htmlFor="public-message" className="text-sm text-white/70">Post publicly</Label>
                    </div>
                  </div>
                  
                  <Button 
                    onClick={handleSendMessage}
                    className="w-full bg-fan-purple hover:bg-fan-dark-purple"
                    disabled={!message.trim() || isProcessing}
                  >
                    {isProcessing ? (
                      "Processing Payment..."
                    ) : (
                      <>
                        Send Message <Send className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </TabsContent>

                {/* Call Tab */}
                <TabsContent value="call" className="space-y-4 py-4">
                  <div className="bg-secondary/40 p-4 rounded-lg">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-sm text-white/80">Call Duration (minutes)</span>
                      <div className="flex items-center">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-7 w-7 p-0 border-fan-purple/30"
                          onClick={() => setCallDuration(Math.max(1, callDuration - 1))}
                        >
                          -
                        </Button>
                        <span className="mx-3 text-white">{callDuration}</span>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-7 w-7 p-0 border-fan-purple/30"
                          onClick={() => setCallDuration(callDuration + 1)}
                        >
                          +
                        </Button>
                      </div>
                    </div>
                    <div className="text-sm text-white/70 mb-4">
                      <span className="font-medium text-white">${callRate.toFixed(2)}</span> per minute
                      <span className="block mt-1">
                        Total: <span className="font-medium text-white">${(callRate * callDuration).toFixed(2)}</span>
                      </span>
                    </div>
                    <Button 
                      onClick={handleInitiateCall}
                      className="w-full bg-fan-purple hover:bg-fan-dark-purple"
                      disabled={isProcessing}
                    >
                      {isProcessing ? (
                        "Processing Request..."
                      ) : (
                        <>
                          Schedule Call <Phone className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>

                {/* Tip Tab */}
                <TabsContent value="tip" className="space-y-4 py-4">
                  <div className="bg-secondary/40 p-4 rounded-lg">
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      {tipOptions.map((option) => (
                        <Button
                          key={option.amount}
                          variant="outline"
                          className={`flex flex-col items-center py-3 border-fan-purple/30 ${
                            tipAmount === option.amount ? 'bg-fan-purple text-white' : 'bg-secondary/40'
                          }`}
                          onClick={() => setTipAmount(option.amount)}
                        >
                          <span className="text-xl mb-1">{option.icon}</span>
                          <span className="text-xs">{option.label}</span>
                          <span className="font-bold mt-1">${option.amount}</span>
                        </Button>
                      ))}
                    </div>
                    
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-sm text-white/80">Custom Amount ($)</span>
                      <div className="flex items-center">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-7 w-7 p-0 border-fan-purple/30"
                          onClick={() => setTipAmount(Math.max(1, tipAmount - 1))}
                        >
                          -
                        </Button>
                        <Input
                          type="number"
                          value={tipAmount}
                          onChange={(e) => setTipAmount(Number(e.target.value))}
                          className="mx-2 w-20 bg-secondary/70 border-fan-purple/20 text-white text-center"
                          min={1}
                        />
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="h-7 w-7 p-0 border-fan-purple/30"
                          onClick={() => setTipAmount(tipAmount + 1)}
                        >
                          +
                        </Button>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-end space-x-2 mb-4">
                      <Switch 
                        id="public-tip" 
                        checked={isPublicInteraction}
                        onCheckedChange={setIsPublicInteraction}
                        className="data-[state=checked]:bg-fan-purple"
                      />
                      <Label htmlFor="public-tip" className="text-sm text-white/70">Show on creator wall</Label>
                    </div>
                    
                    <Button 
                      onClick={handleSendTip}
                      className="w-full bg-fan-purple hover:bg-fan-dark-purple"
                      disabled={isProcessing}
                    >
                      {isProcessing ? (
                        "Processing Tip..."
                      ) : (
                        <>
                          Send ${tipAmount} Tip <DollarSign className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>

                {/* Sticker Tab */}
                <TabsContent value="sticker" className="space-y-4 py-4">
                  <div className="bg-secondary/40 p-4 rounded-lg">
                    <h4 className="text-sm font-medium text-white/90 mb-3">Send a Sticker or NFT</h4>
                    
                    {!walletConnected && (
                      <div className="mb-4 p-3 border border-fan-purple/30 rounded-md">
                        <p className="text-sm text-white/80 mb-2">
                          Connect your wallet to send NFT stickers to this creator
                        </p>
                        <Button
                          className="w-full bg-fan-purple hover:bg-fan-dark-purple"
                          onClick={onConnectWallet}
                          size="sm"
                        >
                          <Wallet className="mr-2 h-4 w-4" /> Connect Wallet for NFTs
                        </Button>
                      </div>
                    )}
                    
                    <div className="grid grid-cols-2 gap-3 mb-4">
                      {predefinedStickers.map((sticker) => (
                        <Button
                          key={sticker.id}
                          variant="outline"
                          className={`h-20 flex flex-col items-center justify-center border-fan-purple/30 ${
                            stickerSelected === sticker.id ? 'bg-fan-purple/50 border-fan-purple' : 'bg-secondary/40'
                          }`}
                          onClick={() => setStickerSelected(sticker.id)}
                        >
                          <div className="w-10 h-10 bg-white/10 rounded-md mb-1 flex items-center justify-center">
                            <img src={sticker.image} alt={sticker.name} className="w-8 h-8" />
                          </div>
                          <span className="text-xs">{sticker.name}</span>
                        </Button>
                      ))}
                    </div>
                    
                    {walletConnected && (
                      <div className="mb-4">
                        <Button
                          variant="outline"
                          className="w-full text-sm border-fan-purple/30 bg-secondary/20 hover:bg-secondary/40"
                          size="sm"
                        >
                          <Image className="mr-2 h-4 w-4" /> Browse Your NFTs
                        </Button>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-end space-x-2 mb-4">
                      <Switch 
                        id="public-sticker" 
                        checked={isPublicInteraction}
                        onCheckedChange={setIsPublicInteraction}
                        className="data-[state=checked]:bg-fan-purple"
                      />
                      <Label htmlFor="public-sticker" className="text-sm text-white/70">Show on creator wall</Label>
                    </div>
                    
                    <Button 
                      onClick={handleSendSticker}
                      className="w-full bg-fan-purple hover:bg-fan-dark-purple"
                      disabled={isProcessing || !stickerSelected}
                    >
                      {isProcessing ? (
                        "Sending Sticker..."
                      ) : (
                        <>
                          Send Sticker <Gift className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            </DialogContent>
          </Dialog>
        )}
        
        {/* Wallet Connection (Only visible for creator's own profile) */}
        {isCurrentUser && !walletConnected && (
          <div className="mb-6">
            <Button 
              variant="outline" 
              className="w-full bg-fan-purple/10 border-fan-purple/30 hover:bg-fan-purple/20 text-white"
              onClick={onConnectWallet}
            >
              <Wallet className="mr-2 h-4 w-4 text-fan-purple" />
              Connect Wallet to Manage NFTs
            </Button>
          </div>
        )}
        
        {/* Social Links Section */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-white/70 mb-2">Connect with me</h4>
          <div className="grid grid-cols-2 gap-2">
            {socialLinks.map((link, index) => (
              <SocialLink
                key={index}
                platform={link.platform}
                username={link.username}
                url={link.url}
              />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProfileBio;
