
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StoreItem, ShippingOption } from '@/types';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Wallet, Tag, Package, ShoppingCart, CreditCard, Truck } from "lucide-react";

interface CreatorStoreProps {
  items: StoreItem[];
  acceptsCrypto?: boolean;
  acceptsFiat?: boolean;
  shippingOptions?: ShippingOption[];
  walletConnected?: boolean;
  onConnectWallet?: () => void;
  isCurrentUser?: boolean; // Add this prop
}

const CreatorStore: React.FC<CreatorStoreProps> = ({
  items,
  acceptsCrypto = true,
  acceptsFiat = true,
  shippingOptions = [],
  walletConnected = false,
  onConnectWallet = () => {},
  isCurrentUser = false // Add default value
}) => {
  const { toast } = useToast();
  const [selectedItem, setSelectedItem] = useState<StoreItem | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'shipping' | 'payment'>('shipping');
  const [selectedShippingOption, setSelectedShippingOption] = useState<string>('');

  // Filter store items by categories
  const digitalItems = items.filter(item => item.isNFT && !item.hasPhysicalProduct);
  const physicalItems = items.filter(item => item.hasPhysicalProduct);
  
  const handleBuyClick = (item: StoreItem) => {
    setSelectedItem(item);
    
    // For pure NFTs without physical components, go straight to NFT purchase
    if (item.isNFT && !item.hasPhysicalProduct) {
      if (!walletConnected) {
        toast({
          title: "Wallet Required",
          description: "You need to connect a wallet to purchase NFTs.",
        });
        return;
      }
      
      // Simulate NFT purchase flow
      toast({
        title: "Starting NFT Purchase",
        description: "Initializing wallet transaction...",
      });
      
      // This would normally open a wallet confirmation dialog
      setTimeout(() => {
        toast({
          title: "NFT Purchased!",
          description: `You now own "${item.name}" NFT!`,
        });
      }, 2000);
    } 
    // For physical products or NFTs with physical components, open checkout
    else {
      setCheckoutStep('shipping');
      setIsCheckoutOpen(true);
    }
  };

  const formSchema = z.object({
    fullName: z.string().min(3, { message: "Full name is required" }),
    addressLine1: z.string().min(5, { message: "Address is required" }),
    addressLine2: z.string().optional(),
    city: z.string().min(2, { message: "City is required" }),
    state: z.string().min(2, { message: "State is required" }),
    postalCode: z.string().min(4, { message: "Postal code is required" }),
    country: z.string().min(2, { message: "Country is required" }),
    email: z.string().email({ message: "Valid email is required" }),
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      fullName: "",
      addressLine1: "",
      addressLine2: "",
      city: "",
      state: "",
      postalCode: "",
      country: "",
      email: "",
    },
  });

  const handleShippingSubmit = (values: z.infer<typeof formSchema>) => {
    console.log("Shipping details:", values);
    setCheckoutStep('payment');
  };

  const handlePaymentSubmit = () => {
    if (!selectedItem) return;
    
    toast({
      title: "Processing Order",
      description: "Your order is being processed...",
    });
    
    // Simulate payment processing
    setTimeout(() => {
      toast({
        title: "Order Complete!",
        description: selectedItem.isNFT 
          ? "Your NFT has been sent to your wallet and your physical product will be shipped soon!"
          : "Your order has been placed and will be shipped soon!",
      });
      setIsCheckoutOpen(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Creator Store</h2>
        {!walletConnected && items.some(item => item.isNFT) && (
          <Button 
            variant="outline"
            onClick={onConnectWallet}
            className="bg-fan-purple/10 border-fan-purple/30 hover:bg-fan-purple/20 text-white"
          >
            <Wallet className="mr-2 h-4 w-4" /> Connect Wallet for NFTs
          </Button>
        )}
      </div>
      
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="bg-fan-background border border-fan-purple/20 mb-4">
          <TabsTrigger value="all" className="data-[state=active]:bg-fan-purple">All Items</TabsTrigger>
          <TabsTrigger value="digital" className="data-[state=active]:bg-fan-purple">Digital Items</TabsTrigger>
          <TabsTrigger value="physical" className="data-[state=active]:bg-fan-purple">Physical Products</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {items.map((item) => (
              <StoreItemCard 
                key={item.id} 
                item={item} 
                onBuyClick={handleBuyClick}
              />
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="digital" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {digitalItems.map((item) => (
              <StoreItemCard 
                key={item.id} 
                item={item} 
                onBuyClick={handleBuyClick}
              />
            ))}
            {digitalItems.length === 0 && (
              <p className="col-span-full text-center text-white/70 py-8">No digital items available.</p>
            )}
          </div>
        </TabsContent>
        
        <TabsContent value="physical" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {physicalItems.map((item) => (
              <StoreItemCard 
                key={item.id} 
                item={item} 
                onBuyClick={handleBuyClick}
              />
            ))}
            {physicalItems.length === 0 && (
              <p className="col-span-full text-center text-white/70 py-8">No physical products available.</p>
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Checkout Dialog */}
      <Dialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
        <DialogContent className="bg-fan-background text-white border-fan-purple/30 max-w-md">
          <DialogHeader>
            <DialogTitle>Complete Your Purchase</DialogTitle>
            <DialogDescription>
              {selectedItem?.name}
              {selectedItem?.isNFT && <Badge className="ml-2 bg-fan-purple">NFT</Badge>}
              {selectedItem?.hasPhysicalProduct && <Badge className="ml-2 bg-green-600">Physical</Badge>}
            </DialogDescription>
          </DialogHeader>
          
          {checkoutStep === 'shipping' && (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(handleShippingSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input className="bg-secondary/40 border-fan-purple/20" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input className="bg-secondary/40 border-fan-purple/20" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="addressLine1"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address Line 1</FormLabel>
                      <FormControl>
                        <Input className="bg-secondary/40 border-fan-purple/20" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="addressLine2"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address Line 2 (Optional)</FormLabel>
                      <FormControl>
                        <Input className="bg-secondary/40 border-fan-purple/20" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input className="bg-secondary/40 border-fan-purple/20" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State/Province</FormLabel>
                        <FormControl>
                          <Input className="bg-secondary/40 border-fan-purple/20" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="postalCode"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Postal Code</FormLabel>
                        <FormControl>
                          <Input className="bg-secondary/40 border-fan-purple/20" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="country"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Country</FormLabel>
                        <FormControl>
                          <Input className="bg-secondary/40 border-fan-purple/20" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="space-y-3 pt-2">
                  <h4 className="text-sm font-medium">Shipping Options</h4>
                  {shippingOptions.map((option) => (
                    <div 
                      key={option.id}
                      className={`p-3 border rounded-md flex justify-between items-center cursor-pointer ${
                        selectedShippingOption === option.id 
                          ? 'border-fan-purple bg-fan-purple/20' 
                          : 'border-gray-600/30 hover:border-fan-purple/50'
                      }`}
                      onClick={() => setSelectedShippingOption(option.id)}
                    >
                      <div className="flex items-center gap-2">
                        <Truck className="h-4 w-4 text-fan-purple" />
                        <div>
                          <p className="text-sm font-medium">{option.name}</p>
                          <p className="text-xs text-white/70">{option.estimatedDelivery}</p>
                        </div>
                      </div>
                      <p className="font-medium">${option.price.toFixed(2)}</p>
                    </div>
                  ))}
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-fan-purple hover:bg-fan-purple/80"
                >
                  Continue to Payment
                </Button>
              </form>
            </Form>
          )}
          
          {checkoutStep === 'payment' && (
            <div className="space-y-6">
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Order Summary</h4>
                <div className="bg-secondary/20 rounded-md p-3">
                  <div className="flex justify-between mb-2">
                    <span>Item Price</span>
                    <span>${selectedItem?.price.toFixed(2)}</span>
                  </div>
                  {selectedItem?.hasPhysicalProduct && (
                    <div className="flex justify-between mb-2">
                      <span>Shipping</span>
                      <span>
                        ${shippingOptions.find(o => o.id === selectedShippingOption)?.price.toFixed(2) || '0.00'}
                      </span>
                    </div>
                  )}
                  <div className="border-t border-white/10 pt-2 mt-2 flex justify-between font-medium">
                    <span>Total</span>
                    <span>
                      ${(
                        (selectedItem?.price || 0) + 
                        (selectedItem?.hasPhysicalProduct 
                          ? (shippingOptions.find(o => o.id === selectedShippingOption)?.price || 0) 
                          : 0)
                      ).toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                <h4 className="text-sm font-medium">Payment Method</h4>
                <Tabs defaultValue={acceptsFiat ? "card" : "crypto"} className="w-full">
                  <TabsList className="bg-fan-background border border-fan-purple/20 mb-4 grid grid-cols-2">
                    {acceptsFiat && (
                      <TabsTrigger value="card" className="data-[state=active]:bg-fan-purple">
                        <CreditCard className="h-4 w-4 mr-2" /> Credit Card
                      </TabsTrigger>
                    )}
                    {acceptsCrypto && (
                      <TabsTrigger value="crypto" className="data-[state=active]:bg-fan-purple">
                        <Wallet className="h-4 w-4 mr-2" /> Crypto
                      </TabsTrigger>
                    )}
                  </TabsList>
                  
                  {acceptsFiat && (
                    <TabsContent value="card" className="space-y-4">
                      <div className="grid gap-4">
                        <div>
                          <label className="text-sm">Card Number</label>
                          <Input 
                            placeholder="4242 4242 4242 4242" 
                            className="bg-secondary/40 border-fan-purple/20" 
                          />
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                          <div className="col-span-2">
                            <label className="text-sm">Expiration Date</label>
                            <Input 
                              placeholder="MM/YY" 
                              className="bg-secondary/40 border-fan-purple/20" 
                            />
                          </div>
                          <div>
                            <label className="text-sm">CVC</label>
                            <Input 
                              placeholder="123" 
                              className="bg-secondary/40 border-fan-purple/20" 
                            />
                          </div>
                        </div>
                      </div>
                    </TabsContent>
                  )}
                  
                  {acceptsCrypto && (
                    <TabsContent value="crypto" className="space-y-4">
                      {!walletConnected ? (
                        <div className="text-center py-4">
                          <p className="text-white/70 mb-4">You need to connect a wallet to pay with crypto</p>
                          <Button 
                            onClick={onConnectWallet}
                            className="bg-fan-purple hover:bg-fan-purple/80"
                          >
                            <Wallet className="mr-2 h-4 w-4" /> Connect Wallet
                          </Button>
                        </div>
                      ) : (
                        <div className="p-4 border border-fan-purple/30 rounded-md">
                          <p className="text-sm text-white/80 mb-2">Connected Wallet:</p>
                          <p className="text-xs bg-fan-purple/20 p-2 rounded font-mono">
                            0x1a2b3c4d5e6f7g8h9i0j...
                          </p>
                        </div>
                      )}
                    </TabsContent>
                  )}
                </Tabs>
              </div>
              
              <div className="flex gap-3 justify-end">
                <Button 
                  variant="outline" 
                  onClick={() => setCheckoutStep('shipping')}
                  className="border-fan-purple/30"
                >
                  Back
                </Button>
                <Button 
                  onClick={handlePaymentSubmit}
                  className="bg-fan-purple hover:bg-fan-purple/80"
                  disabled={!walletConnected && !acceptsFiat}
                >
                  Complete Purchase
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

interface StoreItemCardProps {
  item: StoreItem;
  onBuyClick: (item: StoreItem) => void;
}

const StoreItemCard: React.FC<StoreItemCardProps> = ({ item, onBuyClick }) => {
  return (
    <Card className="bg-white/5 border-white/10 overflow-hidden hover:border-fan-purple/40 transition-all">
      <div className="aspect-video w-full overflow-hidden">
        <img 
          src={item.image} 
          alt={item.name} 
          className="w-full h-full object-cover transition-transform hover:scale-105" 
        />
        <div className="absolute top-2 right-2 flex gap-1">
          {item.isNFT && (
            <Badge className="bg-fan-purple">NFT</Badge>
          )}
          {item.hasPhysicalProduct && (
            <Badge className="bg-green-600">Physical</Badge>
          )}
        </div>
      </div>
      <CardContent className="pt-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-medium text-white">{item.name}</h3>
          <span className="font-bold text-fan-purple">${item.price.toFixed(2)}</span>
        </div>
        <p className="text-sm text-white/70 mb-3">{item.description}</p>
        <div className="flex items-center gap-1 text-xs text-white/60 mb-3">
          {item.category && (
            <div className="flex items-center">
              <Tag className="h-3 w-3 mr-1" />
              {item.category}
            </div>
          )}
          {item.physicalDetails?.requiresShipping && (
            <div className="flex items-center ml-2">
              <Package className="h-3 w-3 mr-1" />
              Ships from {item.physicalDetails.shippingFrom}
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          className="w-full bg-fan-purple hover:bg-fan-purple/80 gap-2"
          onClick={() => onBuyClick(item)}
        >
          <ShoppingCart className="h-4 w-4" />
          {item.isNFT && !item.hasPhysicalProduct ? "Buy NFT" : "Buy Now"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default CreatorStore;
