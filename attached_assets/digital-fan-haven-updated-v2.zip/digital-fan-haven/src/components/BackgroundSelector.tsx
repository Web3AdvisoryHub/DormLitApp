
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Palette } from "lucide-react";

interface BackgroundSelectorProps {
  currentBackground: string;
  onSelectBackground: (background: string) => void;
}

const BackgroundSelector = ({ currentBackground, onSelectBackground }: BackgroundSelectorProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedBackground, setSelectedBackground] = useState(currentBackground);

  const backgrounds = [
    {
      id: 'bg1',
      name: 'Minimal White',
      url: '/background-minimal-white.jpg',
      thumbnail: '/placeholder.svg',
      color: 'bg-white'
    },
    {
      id: 'bg2',
      name: 'Soft Gray',
      url: '/background-soft-gray.jpg',
      thumbnail: '/placeholder.svg',
      color: 'bg-gray-100'
    },
    {
      id: 'bg3',
      name: 'Warm Beige',
      url: '/background-warm-beige.jpg',
      thumbnail: '/placeholder.svg',
      color: 'bg-amber-50'
    },
    {
      id: 'bg4',
      name: 'Cool Blue',
      url: '/background-cool-blue.jpg',
      thumbnail: '/placeholder.svg',
      color: 'bg-blue-50'
    },
    {
      id: 'bg5',
      name: 'Soft Green',
      url: '/background-soft-green.jpg',
      thumbnail: '/placeholder.svg',
      color: 'bg-green-50'
    },
    {
      id: 'bg6',
      name: 'Lavender',
      url: '/background-lavender.jpg',
      thumbnail: '/placeholder.svg',
      color: 'bg-purple-50'
    },
    // Add the uploaded image
    {
      id: 'custom',
      name: 'Modern Beige',
      url: '/lovable-uploads/0ece1a92-de83-4bd9-87b2-249d4e6cb70f.png',
      thumbnail: '/lovable-uploads/0ece1a92-de83-4bd9-87b2-249d4e6cb70f.png',
      color: 'bg-amber-100'
    }
  ];

  const handleSave = () => {
    onSelectBackground(selectedBackground);
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="flex items-center gap-1">
          <Palette className="h-4 w-4" />
          <span>Change Background</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Choose Background</DialogTitle>
          <DialogDescription>
            Select a background for your profile room
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <RadioGroup 
            value={selectedBackground} 
            onValueChange={setSelectedBackground}
            className="grid grid-cols-2 sm:grid-cols-3 gap-4"
          >
            {backgrounds.map((bg) => (
              <div key={bg.id} className="relative flex flex-col items-center">
                <RadioGroupItem
                  value={bg.url}
                  id={bg.id}
                  className="sr-only"
                />
                <Label
                  htmlFor={bg.id}
                  className="cursor-pointer w-full"
                >
                  <div 
                    className={`
                      h-24 w-full rounded-md border-2 overflow-hidden transition-all
                      ${selectedBackground === bg.url ? 'border-primary ring-2 ring-primary ring-opacity-50' : 'border-gray-200'}
                    `}
                  >
                    {bg.thumbnail ? (
                      <img 
                        src={bg.thumbnail} 
                        alt={bg.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className={`w-full h-full ${bg.color}`}></div>
                    )}
                  </div>
                  <p className="mt-1 text-xs text-center">{bg.name}</p>
                </Label>
              </div>
            ))}
          </RadioGroup>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>
            Apply Background
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BackgroundSelector;
