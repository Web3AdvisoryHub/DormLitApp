
import React from 'react';
import { Button } from "@/components/ui/button";
import { Users, Lock } from "lucide-react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface CreatorRoomProps {
  isPublic: boolean;
  visitors?: number;
  roomName?: string;
  roomPreviewImage?: string;
  onEnterRoom: () => void;
  isPremium?: boolean;
}

const CreatorRoom: React.FC<CreatorRoomProps> = ({
  isPublic = true,
  visitors = 0,
  roomName = "Creator Room",
  roomPreviewImage = "/placeholder.svg",
  onEnterRoom,
  isPremium = false
}) => {
  return (
    <Card className="bg-white/5 backdrop-blur-md border-white/10 overflow-hidden">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="20" 
              height="20" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor"
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
              className="h-5 w-5 text-fan-purple"
            >
              <path d="M13 4h3a2 2 0 0 1 2 2v14"></path>
              <path d="M2 20h3"></path>
              <path d="M13 20h9"></path>
              <path d="M10 12v.01"></path>
              <path d="M13 4.562v16.157a1 1 0 0 1-1.242.97L5 20V5.562a2 2 0 0 1 1.515-1.94l4-1A2 2 0 0 1 13 4.561Z"></path>
            </svg>
            {roomName}
          </CardTitle>
          
          <div className="flex items-center gap-2">
            {isPremium && (
              <Badge className="bg-amber-500 text-black">Premium</Badge>
            )}
            
            {!isPublic && (
              <Badge className="bg-zinc-700">
                <Lock className="h-3 w-3 mr-1" /> Private
              </Badge>
            )}
            
            <Badge className="bg-fan-purple">
              <Users className="h-3 w-3 mr-1" /> {visitors}
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-0">
        <div className="relative aspect-video">
          <img 
            src={roomPreviewImage} 
            alt={roomName}
            className="w-full h-full object-cover"
          />
          
          {!isPublic && (
            <div className="absolute inset-0 bg-black/70 flex items-center justify-center">
              <div className="text-center">
                <Lock className="h-8 w-8 mx-auto mb-2 text-white/70" />
                <p className="text-white text-sm">This room is private</p>
              </div>
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="pt-4 pb-4">
        <Button 
          onClick={onEnterRoom}
          className="w-full bg-fan-purple hover:bg-fan-purple/80"
          disabled={!isPublic}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="16" 
            height="16" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor"
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            className="h-4 w-4 mr-2"
          >
            <path d="M13 4h3a2 2 0 0 1 2 2v14"></path>
            <path d="M2 20h3"></path>
            <path d="M13 20h9"></path>
            <path d="M10 12v.01"></path>
            <path d="M13 4.562v16.157a1 1 0 0 1-1.242.97L5 20V5.562a2 2 0 0 1 1.515-1.94l4-1A2 2 0 0 1 13 4.561Z"></path>
          </svg>
          {isPublic ? "Enter Room" : "Private Room"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default CreatorRoom;
