
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Lock, ArrowRight } from 'lucide-react';

interface SimulationRoomSystemProps {
  creatorId: string;
  isUserLoggedIn: boolean;
  isUserPremium?: boolean;
  hasAvatar?: boolean;
  onRequestLogin?: () => void;
  onEnterRoom?: (roomId: string) => void;
  onCreateRoom?: (neighborhoodId: string, themeId: string) => void;
}

const SimulationRoomSystem: React.FC<SimulationRoomSystemProps> = ({
  creatorId,
  isUserLoggedIn,
  isUserPremium = false,
  hasAvatar = false,
  onRequestLogin,
  onEnterRoom,
  onCreateRoom
}) => {
  const [showRoomOptions, setShowRoomOptions] = useState(false);
  
  // Check if user can access rooms (must be logged in and have an avatar)
  const canAccessRooms = isUserLoggedIn && hasAvatar;
  
  const handleEnterRoomClick = () => {
    if (!isUserLoggedIn && onRequestLogin) {
      onRequestLogin();
      return;
    }
    
    if (!hasAvatar) {
      // Alert that user needs an avatar to access rooms
      alert("You need to create an avatar before accessing simulation rooms.");
      return;
    }
    
    if (onEnterRoom) {
      onEnterRoom(creatorId);
    }
  };
  
  const handleCreateRoomClick = (neighborhoodId: string, themeId: string) => {
    if (!isUserLoggedIn && onRequestLogin) {
      onRequestLogin();
      return;
    }
    
    if (!hasAvatar) {
      // Alert that user needs an avatar to create rooms
      alert("You need to create an avatar before creating simulation rooms.");
      return;
    }
    
    if (onCreateRoom) {
      onCreateRoom(neighborhoodId, themeId);
    }
  };
  
  return (
    <Card className="bg-white/5 border-white/10">
      <CardHeader>
        <CardTitle className="text-white flex items-center justify-between">
          <span>Simulation Room</span>
          {!canAccessRooms && (
            <Lock className="h-5 w-5 text-orange-400" />
          )}
        </CardTitle>
        <CardDescription className="text-white/70">
          {canAccessRooms
            ? "Enter the virtual room to interact in real-time"
            : "Create an avatar to access simulation rooms"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="p-4 bg-white/10 rounded-md text-center">
          <div className="aspect-video bg-gradient-to-br from-purple-900 to-indigo-900 rounded-md mb-4 flex items-center justify-center">
            {canAccessRooms ? (
              <img 
                src="/placeholder.svg" 
                alt="Room Preview" 
                className="w-full h-full object-cover rounded-md"
              />
            ) : (
              <div className="text-white/50">Avatar required for room access</div>
            )}
          </div>
          
          <h3 className="text-white font-medium mb-2">
            {canAccessRooms ? "Creator's Virtual Space" : "Create Your Avatar First"}
          </h3>
          <p className="text-white/70 text-sm mb-4">
            {canAccessRooms
              ? "Join this immersive space to interact with other fans and the creator"
              : "You need to create an avatar before you can enter or create rooms"}
          </p>
        </div>
      </CardContent>
      <CardFooter className="flex flex-col gap-2">
        <Button 
          className={`w-full ${canAccessRooms ? 'bg-fan-purple hover:bg-fan-purple/80' : 'bg-gray-600'}`}
          onClick={handleEnterRoomClick}
          disabled={!canAccessRooms}
        >
          {canAccessRooms ? (
            <>Enter Room <ArrowRight className="ml-2 h-4 w-4" /></>
          ) : (
            "Avatar Required"
          )}
        </Button>
        
        {isUserPremium && (
          <Button
            variant="outline"
            className="w-full border-white/20"
            onClick={() => setShowRoomOptions(!showRoomOptions)}
            disabled={!canAccessRooms}
          >
            {showRoomOptions ? "Hide Room Options" : "Show Room Options"}
          </Button>
        )}
        
        {showRoomOptions && isUserPremium && (
          <div className="grid grid-cols-2 gap-2 mt-2 w-full">
            <Button 
              variant="outline" 
              className="border-white/20"
              onClick={() => handleCreateRoomClick('urban', 'modern')}
              disabled={!canAccessRooms}
            >
              Urban Theme
            </Button>
            <Button 
              variant="outline" 
              className="border-white/20"
              onClick={() => handleCreateRoomClick('nature', 'forest')}
              disabled={!canAccessRooms}
            >
              Nature Theme
            </Button>
            <Button 
              variant="outline" 
              className="border-white/20"
              onClick={() => handleCreateRoomClick('space', 'galaxy')}
              disabled={!canAccessRooms}
            >
              Space Theme
            </Button>
            <Button 
              variant="outline" 
              className="border-white/20"
              onClick={() => handleCreateRoomClick('fantasy', 'medieval')}
              disabled={!canAccessRooms}
            >
              Fantasy Theme
            </Button>
          </div>
        )}
      </CardFooter>
    </Card>
  );
};

export default SimulationRoomSystem;
