
import React from 'react';
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, Lock, Crown } from "lucide-react";
import { SimulationRoom } from '@/types';

interface SimulationRoomPreviewProps {
  room: SimulationRoom;
  onEnterRoom: (roomId: string) => void;
  isUserLoggedIn: boolean;
  hasAvatar?: boolean;
  onRequestLogin?: () => void;
}

const SimulationRoomPreview: React.FC<SimulationRoomPreviewProps> = ({
  room,
  onEnterRoom,
  isUserLoggedIn,
  hasAvatar = false,
  onRequestLogin
}) => {
  const handleEnterClick = () => {
    if (!isUserLoggedIn) {
      onRequestLogin?.();
      return;
    }
    
    if (!hasAvatar) {
      alert("You need to create an avatar before accessing simulation rooms.");
      return;
    }
    
    if (room.accessLevel.type !== 'public' && !room.isPremium) {
      // Handle restricted access
      console.log('This room requires invitation or premium status');
      return;
    }
    
    onEnterRoom(room.id);
  };
  
  return (
    <Card className="bg-white/5 backdrop-blur-md border-white/10 overflow-hidden h-full">
      <div className="relative">
        <img 
          src={room.previewImage} 
          alt={room.name}
          className="w-full aspect-video object-cover"
        />
        
        <div className="absolute top-2 right-2 flex gap-1">
          {room.isPremium && (
            <Badge className="bg-amber-500 text-black">
              <Crown className="h-3 w-3 mr-1" /> Premium
            </Badge>
          )}
          
          {room.accessLevel.type !== 'public' && (
            <Badge className="bg-zinc-700">
              <Lock className="h-3 w-3 mr-1" /> 
              {room.accessLevel.type === 'private' ? 'Private' : 'Invite Only'}
            </Badge>
          )}
          
          <Badge className="bg-fan-purple">
            <Users className="h-3 w-3 mr-1" /> {room.currentVisitors}
          </Badge>
        </div>
        
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
          <h3 className="text-white font-medium truncate">{room.name}</h3>
          <div className="flex items-center gap-2 text-xs text-white/70">
            <span>{room.visitorCount} total visits</span>
            <span className="h-1 w-1 bg-white/40 rounded-full"></span>
            <span>{new Date(room.lastVisited).toLocaleDateString()}</span>
          </div>
        </div>
      </div>
      
      <CardContent className="p-3 pb-0">
        <div className="flex items-center gap-1 text-sm text-white/70">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="16" 
            height="16" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor"
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round"
            className="h-4 w-4 mr-1 text-fan-purple"
          >
            <path d="m8 3 4 8 5-5 5 15H2L8 3z"/>
          </svg>
          <span>{room.neighborhoodId} Neighborhood</span>
        </div>
      </CardContent>
      
      <CardFooter className="p-3">
        <Button 
          onClick={handleEnterClick}
          className="w-full bg-fan-purple hover:bg-fan-purple/80"
          disabled={!isUserLoggedIn || !hasAvatar || (room.accessLevel.type !== 'public' && !room.isPremium)}
        >
          {!hasAvatar ? "Avatar Required" : (
            <>
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="16" 
                height="16" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor"
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
                className="h-4 w-4 mr-2"
              >
                <path d="M13 4h3a2 2 0 0 1 2 2v14"></path>
                <path d="M2 20h3"></path>
                <path d="M13 20h9"></path>
                <path d="M10 12v.01"></path>
                <path d="M13 4.562v16.157a1 1 0 0 1-1.242.97L5 20V5.562a2 2 0 0 1 1.515-1.94l4-1A2 2 0 0 1 13 4.561Z"></path>
              </svg>
              Enter Room
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default SimulationRoomPreview;
