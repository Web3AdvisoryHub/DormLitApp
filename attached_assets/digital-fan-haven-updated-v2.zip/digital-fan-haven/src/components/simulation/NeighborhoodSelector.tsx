
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown, Users } from "lucide-react";
import { Neighborhood } from '@/types';

interface NeighborhoodSelectorProps {
  neighborhoods: Neighborhood[];
  selectedNeighborhoodId: string | null;
  onSelectNeighborhood: (neighborhoodId: string) => void;
  isUserPremium?: boolean;
}

const NeighborhoodSelector: React.FC<NeighborhoodSelectorProps> = ({
  neighborhoods,
  selectedNeighborhoodId,
  onSelectNeighborhood,
  isUserPremium = false
}) => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Choose Neighborhood</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {neighborhoods.map((neighborhood) => (
          <Card 
            key={neighborhood.id}
            className={`cursor-pointer transition-all duration-300 overflow-hidden ${
              selectedNeighborhoodId === neighborhood.id 
                ? 'ring-2 ring-fan-purple border-transparent' 
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            } ${
              neighborhood.isPremium && !isUserPremium ? 'opacity-60' : ''
            }`}
            onClick={() => {
              if (!neighborhood.isPremium || isUserPremium) {
                onSelectNeighborhood(neighborhood.id);
              }
            }}
          >
            <div className="relative">
              <img 
                src={neighborhood.previewImage} 
                alt={neighborhood.name}
                className="w-full aspect-video object-cover"
              />
              
              <div className="absolute top-2 right-2 flex gap-1">
                {neighborhood.isPremium && (
                  <Badge className="bg-amber-500 text-black">
                    <Crown className="h-3 w-3 mr-1" /> Premium
                  </Badge>
                )}
                
                <Badge className="bg-fan-purple">
                  <Users className="h-3 w-3 mr-1" /> {neighborhood.residentCount}
                </Badge>
              </div>
              
              {neighborhood.isPremium && !isUserPremium && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <div className="text-center bg-black/80 px-3 py-2 rounded">
                    <Crown className="h-5 w-5 mx-auto mb-1 text-amber-500" />
                    <p className="text-white text-sm">Premium Required</p>
                  </div>
                </div>
              )}
            </div>
            
            <CardContent className="p-3">
              <h4 className="font-medium text-white">{neighborhood.name}</h4>
              <p className="text-sm text-white/70 line-clamp-2">{neighborhood.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default NeighborhoodSelector;
