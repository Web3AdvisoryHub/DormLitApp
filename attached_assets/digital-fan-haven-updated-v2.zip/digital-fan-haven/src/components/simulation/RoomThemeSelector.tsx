
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown } from "lucide-react";
import { RoomTheme } from '@/types';

interface RoomThemeSelectorProps {
  themes: RoomTheme[];
  selectedThemeId: string | null;
  onSelectTheme: (themeId: string) => void;
  isUserPremium?: boolean;
}

const RoomThemeSelector: React.FC<RoomThemeSelectorProps> = ({
  themes,
  selectedThemeId,
  onSelectTheme,
  isUserPremium = false
}) => {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-white">Choose Room Theme</h3>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {themes.map((theme) => (
          <Card 
            key={theme.id}
            className={`cursor-pointer transition-all duration-300 overflow-hidden ${
              selectedThemeId === theme.id 
                ? 'ring-2 ring-fan-purple border-transparent' 
                : 'bg-white/5 border-white/10 hover:bg-white/10'
            } ${
              theme.isPremium && !isUserPremium ? 'opacity-60' : ''
            }`}
            onClick={() => {
              if (!theme.isPremium || isUserPremium) {
                onSelectTheme(theme.id);
              }
            }}
          >
            <div className="relative">
              <img 
                src={theme.previewImage} 
                alt={theme.name}
                className="w-full aspect-square object-cover"
              />
              
              {theme.isPremium && (
                <Badge className="absolute top-2 right-2 bg-amber-500 text-black">
                  <Crown className="h-3 w-3 mr-1" /> Premium
                </Badge>
              )}
              
              {theme.isPremium && !isUserPremium && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <div className="text-center bg-black/80 px-3 py-2 rounded">
                    <Crown className="h-5 w-5 mx-auto mb-1 text-amber-500" />
                    <p className="text-white text-sm">Premium Required</p>
                  </div>
                </div>
              )}
            </div>
            
            <CardContent className="p-3">
              <h4 className="font-medium text-white">{theme.name}</h4>
              <p className="text-sm text-white/70 line-clamp-2">{theme.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RoomThemeSelector;
