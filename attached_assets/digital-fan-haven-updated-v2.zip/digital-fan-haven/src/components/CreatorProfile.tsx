import React, { useState } from 'react';
import AvatarEditor from 'react-avatar-editor';
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Verified, Copy, Check, Mail, Bell } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import ContentScroller, { ContentItem } from './ContentScroller';
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider"
import { Textarea } from "@/components/ui/textarea"
import { PhoneCall, MessageSquare, DollarSign, Gift } from 'lucide-react';

export interface CreatorProfileProps {
  name: string;
  avatarSrc: string;
  bio: string;
  socialLinks: SocialLinkData[];
  messageRate: number;
  callRate: number;
  isCurrentUser: boolean;
  walletConnected?: boolean;
  onConnectWallet?: () => void;
  onSendMessage: (message: string, isPublic: boolean) => Promise<void>;
  onScheduleCall: (duration: number) => Promise<void>;
  onSendTip: (amount: number, isPublic: boolean) => Promise<void>;
  onSendSticker: (stickerId: string, isPublic: boolean) => Promise<void>;
  onOpeningFeeMessage?: (recipient: string, amount: number, message: string) => Promise<void>;
  isRiggable?: boolean;
  onAvatarChange?: (newUrl: string, isRiggable: boolean) => void;
  contentItems?: ContentItem[];
  hasEmailList?: boolean;
  hasTextAlerts?: boolean;
  onSendEmailAlert?: () => void;
  onSendTextAlert?: () => void;
  subscribersCount?: number;
  hideButtons?: boolean;
  isFanView?: boolean;
  onTextRequest?: () => void;
  onCallRequest?: () => void;
  onTipRequest?: () => void;
  onStickerRequest?: () => void;
  children?: React.ReactNode;
}

export interface SocialLinkData {
  platform: string;
  url: string;
  username: string;
  icon?: string;
}

const CreatorProfile: React.FC<CreatorProfileProps> = ({
  name,
  avatarSrc,
  bio, 
  socialLinks,
  messageRate,
  callRate,
  isCurrentUser,
  walletConnected = false,
  onConnectWallet,
  onSendMessage,
  onScheduleCall,
  onSendTip,
  onSendSticker,
  onOpeningFeeMessage,
  isRiggable = false,
  onAvatarChange,
  contentItems = [],
  hasEmailList = false,
  hasTextAlerts = false,
  onSendEmailAlert,
  onSendTextAlert,
  subscribersCount = 0,
  hideButtons = false,
  isFanView = false,
  onTextRequest,
  onCallRequest,
  onTipRequest,
  onStickerRequest,
  children
}) => {
  const [isCopied, setIsCopied] = useState(false);
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [message, setMessage] = useState('');
  const [callDuration, setCallDuration] = useState(15);
  const [tipAmount, setTipAmount] = useState(5);
  const [selectedSticker, setSelectedSticker] = useState('');
  const [openingFeeAmount, setOpeningFeeAmount] = useState(1);
  const [openingFeeMessage, setOpeningFeeMessage] = useState('');
  const [isPublicMessage, setIsPublicMessage] = useState(false);
  const [isPublicTip, setIsPublicTip] = useState(false);
  const [isPublicSticker, setIsPublicSticker] = useState(false);
  const [editor, setEditor] = useState<AvatarEditor | null>(null);
  const [scale, setScale] = useState(1.2);
  const [rotate, setRotate] = useState(0);
  const [image, setImage] = useState<string | null>(null);
  const [isRiggableAvatar, setIsRiggableAvatar] = useState(false);
  
  const handleCopyAddress = () => {
    navigator.clipboard.writeText("0x12345...ABCDE");
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleConnectWalletClick = () => {
    setShowConnectModal(true);
    onConnectWallet && onConnectWallet();
  };

  const handleSendMessageClick = async () => {
    if (!message.trim()) return;
    await onSendMessage(message, isPublicMessage);
    setMessage('');
  };

  const handleScheduleCallClick = async () => {
    await onScheduleCall(callDuration);
  };

  const handleSendTipClick = async () => {
    await onSendTip(tipAmount, isPublicTip);
  };

  const handleSendStickerClick = async () => {
    if (!selectedSticker) return;
    await onSendSticker(selectedSticker, isPublicSticker);
    setSelectedSticker('');
  };
  
  const handleOpeningFeeMessageClick = async () => {
    if (!openingFeeMessage.trim()) return;
    if (!onOpeningFeeMessage) return;
    await onOpeningFeeMessage('recipient', openingFeeAmount, openingFeeMessage);
    setOpeningFeeMessage('');
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    if (editor) {
      const canvas = editor.getImageScaledToCanvas();
      const dataURL = canvas.toDataURL('image/png');
      
      if (onAvatarChange) {
        onAvatarChange(dataURL, isRiggableAvatar);
      }
    }
  };

  const handleJoinAffiliate = () => {
    // Redirect to signup with affiliate tracking
    window.location.href = `/signup?ref=${name.replace(/\s+/g, '').toLowerCase()}`;
  };

  // Function to handle the main connect button click
  const handleConnectClick = () => {
    // Open the standard connect dialog which will use the ScrollableConnectOptions
    setShowConnectModal(true);
  };

  return (
    <div className="bg-secondary/10 rounded-2xl p-6 mb-6 glass-card border-0">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="flex-shrink-0">
          {isCurrentUser ? (
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Avatar className="w-32 h-32 cursor-pointer">
                        <AvatarImage src={avatarSrc} alt={name} className="object-cover" />
                        <AvatarFallback>{name.charAt(0)}</AvatarFallback>
                      </Avatar>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px] bg-secondary/80 border-secondary/50">
                      <DialogHeader>
                        <DialogTitle className="text-white">Edit Avatar</DialogTitle>
                        <DialogDescription className="text-white/80">
                          Upload a new avatar or adjust your current one.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="picture" className="text-right text-white">
                            New Avatar
                          </Label>
                          <Input
                            type="file"
                            id="picture"
                            accept="image/*"
                            onChange={handleImageChange}
                            className="col-span-3 text-white"
                          />
                        </div>
                        {image && (
                          <>
                            <AvatarEditor
                              ref={(e) => setEditor(e)}
                              image={image}
                              width={256}
                              height={256}
                              border={50}
                              borderRadius={128}
                              color={[255, 255, 255, 0.6]} // RGBA
                              scale={scale}
                              rotate={rotate}
                            />
                            <div className="grid grid-cols-4 items-center gap-4">
                              <Label htmlFor="scale" className="text-right text-white">
                                Zoom
                              </Label>
                              <Slider
                                id="scale"
                                defaultValue={[scale]}
                                min={1}
                                max={3}
                                step={0.01}
                                onValueChange={(value) => setScale(value[0])}
                                className="col-span-3"
                              />
                            </div>
                            <div className="grid grid-cols-4 items-center gap-4">
                              <Label htmlFor="rotate" className="text-right text-white">
                                Rotate
                              </Label>
                              <Slider
                                id="rotate"
                                defaultValue={[rotate]}
                                min={0}
                                max={360}
                                step={1}
                                onValueChange={(value) => setRotate(value[0])}
                                className="col-span-3"
                              />
                            </div>
                            <div className="grid grid-cols-4 items-center gap-4">
                              <Label htmlFor="riggable" className="text-right text-white">
                                Riggable
                              </Label>
                              <Switch 
                                id="riggable"
                                checked={isRiggableAvatar}
                                onCheckedChange={(checked) => setIsRiggableAvatar(checked)}
                                className="col-span-3 data-[state=checked]:bg-fan-purple"
                              />
                            </div>
                          </>
                        )}
                      </div>
                      <Button type="submit" onClick={handleSave}>Save changes</Button>
                    </DialogContent>
                  </Dialog>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Click to change your avatar</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ) : (
            <Avatar className="w-32 h-32">
              <AvatarImage src={avatarSrc} alt={name} className="object-cover" />
              <AvatarFallback>{name.charAt(0)}</AvatarFallback>
            </Avatar>
          )}
        </div>
        
        <div className="flex-grow">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-2xl font-semibold text-white">{name}</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-sm text-white/70">@{name.replace(/\s+/g, '').toLowerCase()}</span>
                <Verified className="h-4 w-4 text-blue-500" />
              </div>
            </div>
            
            {!hideButtons && !isFanView && (
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline" 
                  className="px-3 border-fan-purple/20 hover:bg-fan-purple/20 text-white"
                >
                  <span className="text-sm font-bold text-fan-purple">NFT</span>
                </Button>
                <Button
                  size="sm"
                  variant="outline" 
                  className="px-3 border-fan-purple/20 hover:bg-fan-purple/20 text-white"
                >
                  <span className="text-sm font-bold text-fan-purple">NFT</span>
                </Button>
                <Button
                  size="sm"
                  variant="outline" 
                  className="px-3 border-fan-purple/20 hover:bg-fan-purple/20 text-white"
                >
                  <span className="text-sm font-bold text-fan-purple">Phone</span>
                </Button>
              </div>
            )}
          </div>
          
          <p className="text-white/80 mt-2">{bio}</p>
          
          <div className="flex gap-4 mt-4">
            {socialLinks.map(link => (
              <a 
                key={link.platform} 
                href={link.url} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-white hover:text-fan-purple transition-colors"
              >
                {link.platform}
              </a>
            ))}
          </div>
          
          {contentItems && contentItems.length > 0 && (
            <div className="mt-6">
              <ContentScroller items={contentItems} />
            </div>
          )}
          
          <div className="mt-4 flex flex-wrap gap-3">
            {!isFanView && walletConnected && isCurrentUser && (
              <div className="flex items-center gap-2 bg-green-500/10 text-green-400 rounded-md px-3 py-1.5 text-sm">
                Wallet Connected <Check className="h-4 w-4" />
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button onClick={handleCopyAddress} className="hover:underline">
                        0x12345...ABCDE
                      </button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Copy address</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
                <Button size="icon" variant="ghost" onClick={handleCopyAddress}>
                  {isCopied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            )}
            
            {!isFanView && !walletConnected && isCurrentUser && (
              <Button onClick={handleConnectWalletClick}>
                Connect Wallet
              </Button>
            )}
            
            {isCurrentUser && !isFanView && (
              <>
                {hasEmailList && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline">Send Email Alert</Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px] bg-secondary/80 border-secondary/50">
                      <DialogHeader>
                        <DialogTitle className="text-white">Send Email Alert</DialogTitle>
                        <DialogDescription className="text-white/80">
                          Send an email alert to all your subscribers.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="email-subject" className="text-right text-white">
                            Subject
                          </Label>
                          <Input
                            type="text"
                            id="email-subject"
                            defaultValue="New Content Alert!"
                            className="col-span-3 text-white"
                          />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="email-body" className="text-right text-white">
                            Body
                          </Label>
                          <Textarea
                            id="email-body"
                            defaultValue="Check out my latest content!"
                            className="col-span-3 text-white"
                          />
                        </div>
                      </div>
                      <Button onClick={onSendEmailAlert}>Send Email</Button>
                    </DialogContent>
                  </Dialog>
                )}
                
                {hasTextAlerts && (
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline">Send Text Alert</Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[425px] bg-secondary/80 border-secondary/50">
                      <DialogHeader>
                        <DialogTitle className="text-white">Send Text Alert</DialogTitle>
                        <DialogDescription className="text-white/80">
                          Send a text alert to all your subscribers.
                        </DialogDescription>
                      </DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                          <Label htmlFor="text-message" className="text-right text-white">
                            Message
                          </Label>
                          <Input
                            type="text"
                            id="text-message"
                            defaultValue="New Content Alert!"
                            className="col-span-3 text-white"
                          />
                        </div>
                      </div>
                      <Button onClick={onSendTextAlert}>Send Text</Button>
                    </DialogContent>
                  </Dialog>
                )}
              </>
            )}
            
            {!isCurrentUser && !hideButtons && !children && (
              <div className="flex flex-wrap gap-2">
                <Button 
                  className="bg-fan-purple hover:bg-fan-purple/80" 
                  onClick={onTextRequest}
                >
                  <MessageSquare className="mr-2 h-4 w-4" />
                  Text
                </Button>
                <Button 
                  className="bg-fan-purple hover:bg-fan-purple/80" 
                  onClick={onCallRequest}
                >
                  <PhoneCall className="mr-2 h-4 w-4" />
                  Call
                </Button>
                <Button 
                  className="bg-fan-purple hover:bg-fan-purple/80" 
                  onClick={onTipRequest}
                >
                  <DollarSign className="mr-2 h-4 w-4" />
                  Tip
                </Button>
                <Button 
                  className="bg-fan-purple hover:bg-fan-purple/80" 
                  onClick={onStickerRequest}
                >
                  <Gift className="mr-2 h-4 w-4" />
                  Sticker
                </Button>
              </div>
            )}
            
            {!isCurrentUser && !hideButtons && children && (
              <div className="flex flex-wrap gap-2">
                {children}
              </div>
            )}
            
            {isFanView && (
              <Button 
                className="bg-fan-purple hover:bg-fan-purple/80" 
                onClick={handleJoinAffiliate}
              >
                Join Dormlit.Grow
              </Button>
            )}
          </div>
        </div>
      </div>
      
      {!isFanView && hasEmailList && hasTextAlerts && (
        <div className="mt-6 p-4 bg-secondary/20 rounded-md">
          <h4 className="text-lg font-semibold text-white mb-2">Stay Updated</h4>
          <p className="text-white/70 text-sm">
            Get notified about new content and updates from {name}.
          </p>
          <div className="mt-4 flex gap-2">
            <Button variant="secondary" onClick={onSendEmailAlert}>
              <Mail className="h-4 w-4 mr-2" /> Email Alert ({subscribersCount})
            </Button>
            <Button variant="secondary" onClick={onSendTextAlert}>
              <Bell className="h-4 w-4 mr-2" /> Text Alert ({subscribersCount})
            </Button>
          </div>
        </div>
      )}
      
      {showConnectModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
          <div className="bg-secondary/80 p-6 rounded-md">
            <h3 className="text-lg font-semibold text-white mb-4">Connect Wallet</h3>
            <p className="text-white/70 mb-4">
              Please connect your wallet to interact with this profile.
            </p>
            <Button onClick={() => {
              handleConnectWalletClick();
              setShowConnectModal(false);
            }}>
              Connect with MetaMask
            </Button>
            <Button variant="ghost" onClick={() => setShowConnectModal(false)}>
              Cancel
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreatorProfile;
