
import React from 'react';
import { cn } from "@/lib/utils";
import AvatarUploader from './AvatarUploader';

type AvatarProps = {
  src: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showGlow?: boolean;
  className?: string;
  isEditable?: boolean;
  isRiggable?: boolean;
  onAvatarChange?: (newSrc: string, isRiggable: boolean) => void;
};

const Avatar = ({ 
  src, 
  size = 'md', 
  showGlow = false, 
  className,
  isEditable = false,
  isRiggable = false,
  onAvatarChange
}: AvatarProps) => {
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-20 h-20',
    lg: 'w-32 h-32',
    xl: 'w-40 h-40'
  };

  return (
    <div className={cn(
      "rounded-full overflow-hidden border-2 border-fan-purple relative",
      sizeClasses[size],
      showGlow && "avatar-glow",
      isRiggable && "ring-2 ring-offset-2 ring-fan-purple ring-offset-black/50",
      className
    )}>
      <img 
        src={src || "/placeholder.svg"} 
        alt="Avatar" 
        className="w-full h-full object-cover"
      />
      
      {isRiggable && (
        <div className="absolute top-0 right-0 w-4 h-4 bg-fan-purple rounded-full border border-white transform translate-x-1 -translate-y-1" 
          title="Riggable Avatar"
        />
      )}
      
      {isEditable && onAvatarChange && (
        <AvatarUploader 
          onAvatarChange={onAvatarChange}
          currentAvatar={src}
          currentRiggable={isRiggable}
        />
      )}
    </div>
  );
};

export default Avatar;
