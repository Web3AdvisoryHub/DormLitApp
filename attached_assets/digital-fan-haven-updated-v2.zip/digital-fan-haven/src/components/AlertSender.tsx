
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Mail, Bell, Send } from "lucide-react";

interface AlertSenderProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: 'email' | 'text';
  subscriberCount: number;
  onSend: (message: string, subject?: string) => Promise<void>;
}

const AlertSender: React.FC<AlertSenderProps> = ({
  open,
  onOpenChange,
  type,
  subscriberCount,
  onSend
}) => {
  const { toast } = useToast();
  const [message, setMessage] = useState('');
  const [subject, setSubject] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async () => {
    if (!message) {
      toast({
        title: "Message Required",
        description: "Please enter a message to send to your subscribers.",
        variant: "destructive"
      });
      return;
    }

    if (type === 'email' && !subject) {
      toast({
        title: "Subject Required",
        description: "Please enter a subject for your email.",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      await onSend(message, type === 'email' ? subject : undefined);
      toast({
        title: "Alert Sent",
        description: `Your ${type === 'email' ? 'email' : 'text'} has been sent to ${subscriberCount} subscribers.`,
      });
      setMessage('');
      setSubject('');
      onOpenChange(false);
    } catch (error) {
      toast({
        title: "Failed to Send",
        description: `There was an error sending your ${type === 'email' ? 'email' : 'text'}.`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-fan-background text-white border-fan-purple/30 max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {type === 'email' ? (
              <>
                <Mail className="h-5 w-5 text-fan-purple" />
                Send Email to Subscribers
              </>
            ) : (
              <>
                <Bell className="h-5 w-5 text-fan-purple" />
                Send Text Alert to Subscribers
              </>
            )}
          </DialogTitle>
          <DialogDescription>
            Your message will be sent to {subscriberCount} subscribers.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {type === 'email' && (
            <div className="space-y-2">
              <Label htmlFor="subject">Email Subject</Label>
              <Input
                id="subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Enter email subject"
                className="bg-secondary/40 border-fan-purple/20"
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={`Enter your ${type === 'email' ? 'email' : 'text'} message`}
              className="bg-secondary/40 border-fan-purple/20 min-h-[150px]"
            />
            <p className="text-xs text-white/70">
              {type === 'text'
                ? "Text messages are limited to 160 characters. Longer messages may be split."
                : "This email will be sent to all subscribers who have opted in."}
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            className="border-fan-purple/30"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSend}
            className="bg-fan-purple hover:bg-fan-purple/80"
            disabled={isLoading}
          >
            {isLoading ? "Sending..." : "Send to All Subscribers"}
            {!isLoading && <Send className="ml-2 h-4 w-4" />}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AlertSender;
