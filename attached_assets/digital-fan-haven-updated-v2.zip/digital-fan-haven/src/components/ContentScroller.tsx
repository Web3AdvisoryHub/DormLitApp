
import React, { useRef } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Instagram, Twitter, Youtube, Globe, ExternalLink } from 'lucide-react';

export interface ContentItem {
  id: string;
  title: string;
  imageUrl: string;
  link: string;
  socialPlatform?: 'instagram' | 'twitter' | 'youtube' | 'website' | 'other';
}

interface ContentScrollerProps {
  items: ContentItem[];
  title?: string;
}

const ContentScroller: React.FC<ContentScrollerProps> = ({ 
  items, 
  title = "Featured Content" 
}) => {
  const scrollerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollerRef.current) return;
    
    const container = scrollerRef.current;
    const scrollAmount = container.clientWidth * 0.75;
    
    if (direction === 'left') {
      container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
    } else {
      container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const getSocialIcon = (platform?: string) => {
    switch(platform) {
      case 'instagram': return <Instagram className="h-4 w-4 text-pink-400" />;
      case 'twitter': return <Twitter className="h-4 w-4 text-blue-400" />;
      case 'youtube': return <Youtube className="h-4 w-4 text-red-500" />;
      case 'website': return <Globe className="h-4 w-4 text-green-400" />;
      default: return <ExternalLink className="h-4 w-4 text-white/70" />;
    }
  };

  if (items.length === 0) return null;

  return (
    <div className="relative max-w-4xl mx-auto">
      <h3 className="text-lg font-medium text-white mb-3">{title}</h3>
      
      <div className="flex items-center">
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute left-0 z-10 bg-black/40 hover:bg-black/60 text-white rounded-full h-8 w-8 -translate-x-1/2"
          onClick={() => scroll('left')}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        
        <div 
          ref={scrollerRef}
          className="flex gap-4 overflow-x-auto py-4 px-8 hide-scrollbar snap-x snap-mandatory"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {items.map((item) => (
            <a 
              key={item.id} 
              href={item.link}
              target="_blank" 
              rel="noopener noreferrer"
              className="snap-start flex-none"
            >
              <Card className="w-64 h-40 relative overflow-hidden group border-fan-purple/30 hover:border-fan-purple transition-all">
                <img 
                  src={item.imageUrl} 
                  alt={item.title} 
                  className="absolute inset-0 w-full h-full object-cover transition-transform group-hover:scale-105" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-white font-medium text-sm truncate">{item.title}</h4>
                    {getSocialIcon(item.socialPlatform)}
                  </div>
                </div>
              </Card>
            </a>
          ))}
        </div>
        
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute right-0 z-10 bg-black/40 hover:bg-black/60 text-white rounded-full h-8 w-8 translate-x-1/2"
          onClick={() => scroll('right')}
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>
      
      {/* Hidden scrollbar styles */}
      <style>
        {`
          .hide-scrollbar::-webkit-scrollbar {
            display: none;
          }
        `}
      </style>
    </div>
  );
};

export default ContentScroller;
