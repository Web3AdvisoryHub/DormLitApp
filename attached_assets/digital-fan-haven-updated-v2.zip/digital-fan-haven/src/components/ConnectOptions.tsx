
import React from 'react';
import { Button } from "@/components/ui/button";
import { PhoneCall, MessageSquare, DollarSign, Gift } from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

interface ConnectOptionsProps {
  creatorName: string;
  onTextRequest?: () => void;
  onCallRequest?: () => void;
  onTipRequest?: () => void;
  onStickerRequest?: () => void;
}

const ConnectOptions: React.FC<ConnectOptionsProps> = ({
  creatorName,
  onTextRequest,
  onCallRequest,
  onTipRequest,
  onStickerRequest
}) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button className="bg-fan-purple hover:bg-fan-purple/80">
          Connect with {creatorName.split(' ')[0]}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="bg-secondary/95 border-fan-purple/30 text-white">
        <DropdownMenuItem 
          className="hover:bg-fan-purple/20 cursor-pointer"
          onClick={onTextRequest}
        >
          <MessageSquare className="mr-2 h-4 w-4" /> Text Message
        </DropdownMenuItem>
        <DropdownMenuItem 
          className="hover:bg-fan-purple/20 cursor-pointer"
          onClick={onCallRequest}
        >
          <PhoneCall className="mr-2 h-4 w-4" /> Schedule Call
        </DropdownMenuItem>
        <DropdownMenuItem 
          className="hover:bg-fan-purple/20 cursor-pointer"
          onClick={onTipRequest}
        >
          <DollarSign className="mr-2 h-4 w-4" /> Send Tip
        </DropdownMenuItem>
        <DropdownMenuItem 
          className="hover:bg-fan-purple/20 cursor-pointer"
          onClick={onStickerRequest}
        >
          <Gift className="mr-2 h-4 w-4" /> Send Sticker/NFT
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default ConnectOptions;
