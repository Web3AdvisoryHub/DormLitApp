
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Mail, Bell, UserPlus, Download, Trash, Upload } from "lucide-react"; // Added Upload from lucide-react
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface Subscriber {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  subscribedToEmails: boolean;
  subscribedToTexts: boolean;
  joinedAt: Date;
}

interface SubscriberManagementProps {
  subscribers: Subscriber[];
  onAddSubscriber: (subscriber: Omit<Subscriber, 'id' | 'joinedAt'>) => Promise<void>;
  onRemoveSubscriber: (id: string) => Promise<void>;
  onExportSubscribers: () => Promise<void>;
  onImportSubscribers?: (file: File) => Promise<void>;
}

const SubscriberManagement: React.FC<SubscriberManagementProps> = ({
  subscribers,
  onAddSubscriber,
  onRemoveSubscriber,
  onExportSubscribers,
  onImportSubscribers
}) => {
  const { toast } = useToast();
  const [isAddSubscriberOpen, setIsAddSubscriberOpen] = useState(false);
  const [newSubscriber, setNewSubscriber] = useState({
    name: '',
    email: '',
    phone: '',
    subscribedToEmails: true,
    subscribedToTexts: false
  });

  const handleAddSubscriber = async () => {
    if (!newSubscriber.name) {
      toast({
        title: "Name Required",
        description: "Please enter a name for the subscriber.",
        variant: "destructive"
      });
      return;
    }

    if (!newSubscriber.email && !newSubscriber.phone) {
      toast({
        title: "Contact Info Required",
        description: "Please enter either an email or phone number.",
        variant: "destructive"
      });
      return;
    }

    try {
      await onAddSubscriber(newSubscriber);
      toast({
        title: "Subscriber Added",
        description: `${newSubscriber.name} has been added to your subscriber list.`,
      });
      setNewSubscriber({
        name: '',
        email: '',
        phone: '',
        subscribedToEmails: true,
        subscribedToTexts: false
      });
      setIsAddSubscriberOpen(false);
    } catch (error) {
      toast({
        title: "Failed to Add",
        description: "There was an error adding the subscriber.",
        variant: "destructive"
      });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onImportSubscribers) {
      onImportSubscribers(file)
        .then(() => {
          toast({
            title: "Import Successful",
            description: "Your subscriber list has been imported.",
          });
        })
        .catch(() => {
          toast({
            title: "Import Failed",
            description: "There was an error importing your subscriber list.",
            variant: "destructive"
          });
        });
    }
  };

  const emailSubscriberCount = subscribers.filter(s => s.subscribedToEmails).length;
  const textSubscriberCount = subscribers.filter(s => s.subscribedToTexts).length;

  return (
    <Card className="bg-secondary/10 border-secondary/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          Subscriber Management
        </CardTitle>
        <CardDescription>
          Manage your email and text alert subscribers
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="flex items-center justify-between p-4 rounded-md bg-fan-purple/10 border border-fan-purple/20">
            <div className="flex items-center gap-3">
              <Mail className="h-5 w-5 text-fan-purple" />
              <div>
                <p className="font-medium text-white">Email Subscribers</p>
                <p className="text-sm text-white/70">{emailSubscriberCount} subscribers</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between p-4 rounded-md bg-fan-purple/10 border border-fan-purple/20">
            <div className="flex items-center gap-3">
              <Bell className="h-5 w-5 text-fan-purple" />
              <div>
                <p className="font-medium text-white">Text Subscribers</p>
                <p className="text-sm text-white/70">{textSubscriberCount} subscribers</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-white">Subscribers ({subscribers.length})</h3>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              className="border-fan-purple/30"
              onClick={() => onExportSubscribers()}
            >
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
            {onImportSubscribers && (
              <div className="relative">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="border-fan-purple/30"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Import
                </Button>
                <input
                  type="file"
                  accept=".csv"
                  onChange={handleFileUpload}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
              </div>
            )}
            <Button 
              size="sm"
              className="bg-fan-purple hover:bg-fan-purple/80"
              onClick={() => setIsAddSubscriberOpen(true)}
            >
              <UserPlus className="mr-2 h-4 w-4" />
              Add
            </Button>
          </div>
        </div>

        <ScrollArea className="h-60 rounded-md border border-secondary/30 p-4">
          {subscribers.length === 0 ? (
            <div className="text-center py-8 text-white/50">
              No subscribers yet. Add subscribers to start sending alerts.
            </div>
          ) : (
            <div className="space-y-2">
              {subscribers.map((subscriber) => (
                <div 
                  key={subscriber.id}
                  className="flex items-center justify-between p-2 rounded hover:bg-fan-purple/10"
                >
                  <div>
                    <p className="font-medium text-white">{subscriber.name}</p>
                    <div className="flex text-xs text-white/70 gap-3">
                      {subscriber.email && (
                        <span className="flex items-center">
                          <Mail className="h-3 w-3 mr-1 text-fan-purple" />
                          {subscriber.email}
                        </span>
                      )}
                      {subscriber.phone && (
                        <span className="flex items-center">
                          <Bell className="h-3 w-3 mr-1 text-fan-purple" />
                          {subscriber.phone}
                        </span>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-white/50 hover:text-white hover:bg-red-500/20"
                    onClick={() => onRemoveSubscriber(subscriber.id)}
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

// Add Subscriber Dialog
const AddSubscriberDialog: React.FC<{
  open: boolean;
  onOpenChange: (open: boolean) => void;
  subscriber: any;
  onChange: (field: string, value: any) => void;
  onAdd: () => Promise<void>;
}> = ({ open, onOpenChange, subscriber, onChange, onAdd }) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-fan-background text-white border-fan-purple/30">
        <DialogHeader>
          <DialogTitle>Add New Subscriber</DialogTitle>
        </DialogHeader>
        
        <div className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label htmlFor="name">Full Name</Label>
            <Input
              id="name"
              value={subscriber.name}
              onChange={(e) => onChange('name', e.target.value)}
              className="bg-secondary/40 border-fan-purple/20"
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={subscriber.email}
              onChange={(e) => onChange('email', e.target.value)}
              className="bg-secondary/40 border-fan-purple/20"
            />
          </div>
          
          <div className="grid gap-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              type="tel"
              value={subscriber.phone}
              onChange={(e) => onChange('phone', e.target.value)}
              className="bg-secondary/40 border-fan-purple/20"
            />
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="subscribedToEmails"
              checked={subscriber.subscribedToEmails}
              onCheckedChange={(checked) => 
                onChange('subscribedToEmails', checked === true)
              }
            />
            <Label htmlFor="subscribedToEmails">Subscribe to emails</Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="subscribedToTexts"
              checked={subscriber.subscribedToTexts}
              onCheckedChange={(checked) => 
                onChange('subscribedToTexts', checked === true)
              }
            />
            <Label htmlFor="subscribedToTexts">Subscribe to text alerts</Label>
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
            className="border-fan-purple/30"
          >
            Cancel
          </Button>
          <Button
            onClick={onAdd}
            className="bg-fan-purple hover:bg-fan-purple/80"
          >
            Add Subscriber
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SubscriberManagement;
