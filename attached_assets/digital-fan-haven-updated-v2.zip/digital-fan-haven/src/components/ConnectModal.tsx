import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useToast } from "@/hooks/use-toast";
import { ExploreFilters, SocialLink } from "@/types";
import { Check, Heart, X, Filter, ArrowRight, Users, Video } from 'lucide-react';
import { motion, PanInfo, useAnimation } from 'framer-motion';
import SocialLinkComponent from "@/components/SocialLink";

// Mock function to fetch creators - would be replaced with an actual API call
const fetchCreators = async (filters: ExploreFilters) => {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return [
    {
      id: '1',
      username: 'pixelpanda',
      displayName: 'Pixel Panda',
      avatarSrc: '/placeholder.svg',
      bio: 'Digital artist specializing in pixel art and NFTs',
      followers: 1203,
      hasStore: true,
      category: 'Art',
      tags: ['digital', 'pixel', 'nft'],
      isLive: false,
      showInExplore: true,
      socialLinks: [
        { platform: 'instagram', url: 'https://instagram.com/pixelpanda', username: 'pixelpanda', icon: '' }
      ]
    },
    {
      id: '2',
      username: 'musicmaven',
      displayName: 'Music Maven',
      avatarSrc: '/placeholder.svg',
      bio: 'Independent musician sharing original tracks and playlists',
      followers: 856,
      hasStore: true,
      category: 'Music',
      tags: ['indie', 'electronic', 'producer'],
      isLive: true,
      showInExplore: true,
      socialLinks: [
        { platform: 'twitter', url: 'https://twitter.com/musicmaven', username: 'musicmaven', icon: '' },
        { platform: 'youtube', url: 'https://youtube.com/musicmaven', username: 'Music Maven', icon: '' }
      ]
    },
    {
      id: '3',
      username: 'fitnessfury',
      displayName: 'Fitness Fury',
      avatarSrc: '/placeholder.svg',
      bio: 'Personal trainer sharing workout tips and meal plans',
      followers: 2450,
      hasStore: true,
      category: 'Fitness',
      tags: ['workout', 'nutrition', 'health'],
      isLive: false,
      showInExplore: true,
      socialLinks: [
        { platform: 'instagram', url: 'https://instagram.com/fitnessfury', username: 'fitnessfury', icon: '' },
        { platform: 'website', url: 'https://fitnessplan.com', username: 'FitnessPlan', icon: '' }
      ]
    },
    {
      id: '4',
      username: 'techtalker',
      displayName: 'Tech Talker',
      avatarSrc: '/placeholder.svg',
      bio: 'Tech enthusiast discussing the latest in gadgets and software',
      followers: 1780,
      hasStore: false,
      category: 'Technology',
      tags: ['gadgets', 'reviews', 'tutorials'],
      isLive: false,
      showInExplore: true,
      socialLinks: [
        { platform: 'youtube', url: 'https://youtube.com/techtalker', username: 'Tech Talker', icon: '' },
        { platform: 'twitter', url: 'https://twitter.com/techtalker', username: 'techtalker', icon: '' }
      ]
    },
    {
      id: '5',
      username: 'culinarycrafter',
      displayName: 'Culinary Crafter',
      avatarSrc: '/placeholder.svg',
      bio: 'Chef sharing recipes and cooking techniques',
      followers: 3210,
      hasStore: true,
      category: 'Cooking',
      tags: ['recipes', 'food', 'culinary'],
      isLive: true,
      showInExplore: true,
      socialLinks: [
        { platform: 'instagram', url: 'https://instagram.com/culinarycrafter', username: 'culinarycrafter', icon: '' },
        { platform: 'website', url: 'https://culinarycrafter.com', username: 'CulinaryCrafter', icon: '' }
      ]
    },
    {
      id: '6',
      username: 'wanderluster',
      displayName: 'Wanderluster',
      avatarSrc: '/placeholder.svg',
      bio: 'Travel blogger documenting adventures around the world',
      followers: 4500,
      hasStore: true,
      category: 'Travel',
      tags: ['travel', 'adventure', 'photography'],
      isLive: false,
      showInExplore: true,
      socialLinks: [
        { platform: 'instagram', url: 'https://instagram.com/wanderluster', username: 'wanderluster', icon: '' },
        { platform: 'website', url: 'https://wanderluster.com', username: 'Wanderluster', icon: '' }
      ]
    }
  ].filter(creator => {
    // Apply filters
    if (filters.category && filters.category !== 'all' && creator.category !== filters.category) {
      return false;
    }
    
    if (filters.tags && filters.tags.length > 0) {
      const hasMatchingTag = filters.tags.some(tag => creator.tags.includes(tag));
      if (!hasMatchingTag) {
        return false;
      }
    }

    // Apply "show in explore" filter
    if (filters.onlyPublic) {
      return creator.showInExplore;
    }
    
    // Apply "live now" filter
    if (filters.onlyLive) {
      return creator.isLive;
    }
    
    return true;
  }).sort((a, b) => {
    // Apply sorting
    if (filters.sortBy === 'popular') {
      return b.followers - a.followers;
    }
    
    // Live creators first if in that view
    if (filters.onlyLive) {
      if (a.isLive && !b.isLive) return -1;
      if (!a.isLive && b.isLive) return 1;
    }
    
    // For demo purposes, recent and trending use the same logic
    return 0;
  });
};

const Explore = () => {
  const { toast } = useToast();
  const [creators, setCreators] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<ExploreFilters>({
    tags: [], // Added tags property
    category: 'all',
    priceRange: [0, 1000],
    sortBy: 'popular',
    onlyPublic: true,
    onlyLive: false
  });
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showInExplore, setShowInExplore] = useState(true);
  const [viewMode, setViewMode] = useState<'all' | 'live'>('all');
  const controls = useAnimation();
  const constraintsRef = useRef(null);

  useEffect(() => {
    const checkAuth = () => {
      const auth = localStorage.getItem('dormlet_is_authenticated') === 'true';
      setIsAuthenticated(auth);
    };
    
    checkAuth();
  }, []);

  useEffect(() => {
    const loadCreators = async () => {
      try {
        setIsLoading(true);
        // Update filters based on viewMode
        const updatedFilters = {
          ...filters,
          onlyLive: viewMode === 'live'
        };
        
        const data = await fetchCreators(updatedFilters);
        setCreators(data);
        setCurrentIndex(0);
        setIsLoading(false);
      } catch (error) {
        console.error('Error loading creators:', error);
        toast({
          title: 'Error',
          description: 'Failed to load creators. Please try again later.',
          variant: 'destructive'
        });
        setIsLoading(false);
      }
    };
    
    loadCreators();
  }, [filters, viewMode, toast]);

  const handleSwipe = async (direction: 'left' | 'right') => {
    if (!creators.length || currentIndex >= creators.length) return;
    
    const creator = creators[currentIndex];
    
    // Animate the card off screen
    await controls.start({
      x: direction === 'left' ? -500 : 500,
      opacity: 0,
      transition: { duration: 0.3 }
    });
    
    // Reset position for next card
    controls.set({ x: 0, opacity: 1 });
    
    if (direction === 'right') {
      if (!isAuthenticated) {
        // Prompt user to sign up
        toast({
          title: 'Authentication Required',
          description: 'Please sign up or log in to like creators.',
          action: (
            <Link to="/signup">
              <Button size="sm">Sign Up</Button>
            </Link>
          ),
        });
      } else {
        // Handle like logic here (follow if it's a live creator)
        if (creator.isLive) {
          toast({
            title: 'Following Live Creator',
            description: `You're now following ${creator.displayName}! You can join their live session.`,
          });
        } else {
          toast({
            title: 'Success',
            description: `You liked ${creator.displayName}!`,
          });
        }
      }
    }
    
    // Move to next card
    setCurrentIndex(prevIndex => {
      const nextIndex = prevIndex + 1;
      if (nextIndex >= creators.length) {
        toast({
          title: 'End of Profiles',
          description: 'You\'ve seen all available profiles. Refresh to start over.',
        });
        return prevIndex; // Stay on last card
      }
      return nextIndex;
    });
  };

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    if (Math.abs(info.offset.x) < 100) {
      controls.start({ x: 0, opacity: 1 });
      return;
    }
    
    const direction = info.offset.x > 0 ? 'right' : 'left';
    handleSwipe(direction);
  };

  const handlePrivacyToggle = (checked: boolean) => {
    setShowInExplore(checked);
    toast({
      title: checked ? 'Profile Visible' : 'Profile Hidden',
      description: checked 
        ? 'Your profile is now visible in Explore' 
        : 'Your profile is now hidden from Explore',
    });
  };

  const handleViewModeChange = (value: string) => {
    setViewMode(value as 'all' | 'live');
  };

  const currentCreator = creators[currentIndex];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col justify-between items-center mb-8">
          <h1 className="text-3xl font-bold mb-4">Explore Dormlit</h1>
          
          <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md">
            <ToggleGroup 
              type="single" 
              value={viewMode} 
              onValueChange={(value) => value && handleViewModeChange(value)}
              className="justify-center"
            >
              <ToggleGroupItem value="all" aria-label="All profiles">
                <Users className="h-4 w-4 mr-2" />
                All
              </ToggleGroupItem>
              <ToggleGroupItem value="live" aria-label="Live now">
                <Video className="h-4 w-4 mr-2" />
                Live Now
              </ToggleGroupItem>
            </ToggleGroup>
            
            <Button 
              variant="outline" 
              className="flex items-center" 
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </Button>
          </div>
        </div>
        
        {showFilters && (
          <div className="mb-8 p-4 rounded-lg bg-white dark:bg-gray-800 shadow-md animate-fade-in">
            <h3 className="font-semibold mb-3">Sort By</h3>
            <Select onValueChange={(value) => setFilters({ ...filters, sortBy: value as 'popular' | 'recent' | 'trending' })}>
              <SelectTrigger className="w-full mb-4">
                <SelectValue placeholder="Popular" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Popular</SelectItem>
                <SelectItem value="recent">Recent</SelectItem>
                <SelectItem value="trending">Trending</SelectItem>
              </SelectContent>
            </Select>
            
            <h3 className="font-semibold mb-3">Category</h3>
            <Select onValueChange={(value) => setFilters({ ...filters, category: value })}>
              <SelectTrigger className="w-full mb-4">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Art">Art</SelectItem>
                <SelectItem value="Music">Music</SelectItem>
                <SelectItem value="Fitness">Fitness</SelectItem>
                <SelectItem value="Technology">Technology</SelectItem>
                <SelectItem value="Cooking">Cooking</SelectItem>
                <SelectItem value="Travel">Travel</SelectItem>
              </SelectContent>
            </Select>
            
            {isAuthenticated && (
              <div className="mt-4">
                <h3 className="font-semibold mb-3">Privacy Settings</h3>
                <div className="flex items-center justify-between">
                  <span>Show my profile in Explore</span>
                  <Switch 
                    checked={showInExplore}
                    onCheckedChange={handlePrivacyToggle}
                  />
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  {showInExplore 
                    ? "Your profile is visible to other users in Explore" 
                    : "Your profile is hidden from Explore"}
                </p>
              </div>
            )}
          </div>
        )}
        
        <div className="flex justify-center items-center" ref={constraintsRef}>
          {isLoading ? (
            <Card className="w-full max-w-md h-[550px] border border-gray-200 dark:border-gray-700">
              <CardContent className="p-6 h-full flex flex-col justify-center items-center animate-pulse">
                <div className="rounded-full bg-gray-200 dark:bg-gray-700 h-24 w-24 mb-8"></div>
                <div className="space-y-4 w-full">
                  <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mx-auto"></div>
                  <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2 mx-auto"></div>
                  <div className="h-20 bg-gray-200 dark:bg-gray-700 rounded w-full mt-6"></div>
                  <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-full mt-6"></div>
                </div>
              </CardContent>
            </Card>
          ) : creators.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 dark:text-gray-400">No creators found matching your criteria.</p>
            </div>
          ) : (
            <motion.div
              animate={controls}
              drag="x"
              dragConstraints={constraintsRef}
              onDragEnd={handleDragEnd}
              className="touch-none"
            >
              <Card className="w-full max-w-md border border-gray-200 dark:border-gray-700 overflow-hidden shadow-xl hover:shadow-2xl transition-shadow duration-300">
                {currentCreator && (
                  <>
                    <CardContent className="p-6">
                      <div className="flex flex-col items-center mb-6 relative">
                        {currentCreator.isLive && (
                          <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-2 py-1 rounded-full animate-pulse flex items-center">
                            <span className="h-2 w-2 bg-white rounded-full mr-1"></span>
                            LIVE
                          </div>
                        )}
                        <Avatar className="h-24 w-24 mb-4">
                          <AvatarImage src={currentCreator.avatarSrc} alt={currentCreator.displayName} />
                          <AvatarFallback>{currentCreator.displayName.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="text-center">
                          <h3 className="text-xl font-bold">{currentCreator.displayName}</h3>
                          <p className="text-sm text-gray-500 dark:text-gray-400">@{currentCreator.username}</p>
                        </div>
                      </div>
                      
                      <p className="text-center text-gray-600 dark:text-gray-300 mb-6">{currentCreator.bio}</p>
                      
                      <div className="flex flex-wrap justify-center gap-2 mb-6">
                        {currentCreator.tags.map((tag: string) => (
                          <span key={tag} className="px-3 py-1 bg-gray-100 dark:bg-gray-800 rounded-full text-xs">
                            {tag}
                          </span>
                        ))}
                      </div>
                      
                      {currentCreator.socialLinks && currentCreator.socialLinks.length > 0 && (
                        <div className="mb-6">
                          <h4 className="text-sm font-medium text-center mb-2">Connect on:</h4>
                          <div className="flex flex-wrap justify-center gap-2">
                            {currentCreator.socialLinks.map((link: SocialLink, index: number) => (
                              <SocialLinkComponent
                                key={index}
                                platform={link.platform as any}
                                username={link.username}
                                url={link.url}
                              />
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div className="flex items-center justify-center text-sm text-gray-500 dark:text-gray-400">
                        <span>{currentCreator.followers} followers</span>
                        {currentCreator.hasStore && (
                          <span className="ml-4 flex items-center">
                            <Check className="h-4 w-4 mr-1 text-green-500" />
                            Store
                          </span>
                        )}
                      </div>
                    </CardContent>
                    
                    <CardFooter className="bg-gray-50 dark:bg-gray-800 p-6 flex justify-between">
                      <div className="flex justify-between w-full">
                        <Button 
                          variant="outline" 
                          className="bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 hover:bg-red-100 dark:hover:bg-red-900/30 rounded-full h-14 w-14 p-0"
                          onClick={() => handleSwipe('left')}
                        >
                          <X className="h-6 w-6 text-red-500" />
                        </Button>
                        
                        <Link to={`/profile/${currentCreator.username}`} className="flex items-center justify-center">
                          <Button variant="ghost" className="text-sm">
                            View Dorm <ArrowRight className="h-4 w-4 ml-1" />
                          </Button>
                        </Link>
                        
                        <Button 
                          variant="outline" 
                          className={`${currentCreator.isLive ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800 hover:bg-red-100' : 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800 hover:bg-green-100'} dark:hover:bg-green-900/30 rounded-full h-14 w-14 p-0`}
                          onClick={() => handleSwipe('right')}
                        >
                          <Heart className={`h-6 w-6 ${currentCreator.isLive ? 'text-red-500' : 'text-green-500'}`} />
                        </Button>
                      </div>
                    </CardFooter>
                  </>
                )}
              </Card>
            </motion.div>
          )}
        </div>
        
        <div className="mt-8 text-center text-sm text-gray-500 dark:text-gray-400">
          {!isLoading && creators.length > 0 && (
            <p>
              {viewMode === 'live' 
                ? "Swipe left to skip, right to follow and join live." 
                : "Swipe left to skip, right to like."}
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Explore;
