
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Phone, MessageSquare, Send } from "lucide-react";
import { CommunicationSettings } from '../types';

interface CommunicationSectionProps {
  settings: CommunicationSettings;
  onSettingsChange: (newSettings: CommunicationSettings) => void;
  onInitiateCall: (duration: number) => Promise<void>;
  onSendText: (message: string) => Promise<void>;
}

const CommunicationSection: React.FC<CommunicationSectionProps> = ({
  settings,
  onSettingsChange,
  onInitiateCall,
  onSendText
}) => {
  const [message, setMessage] = useState('');
  const [callDuration, setCallDuration] = useState(15);
  const [isCallLoading, setIsCallLoading] = useState(false);
  const [isTextLoading, setIsTextLoading] = useState(false);

  const handleCall = async () => {
    if (settings.callEnabled) {
      try {
        setIsCallLoading(true);
        await onInitiateCall(callDuration);
      } finally {
        setIsCallLoading(false);
      }
    }
  };

  const handleText = async () => {
    if (settings.textEnabled && message.trim()) {
      try {
        setIsTextLoading(true);
        await onSendText(message.trim());
        setMessage('');
      } finally {
        setIsTextLoading(false);
      }
    }
  };

  return (
    <Card className="glass-card border-0">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-white">Communication</CardTitle>
      </CardHeader>
      <CardContent className="pt-4 space-y-6">
        {/* Call Settings */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Phone className="h-4 w-4 text-fan-purple" />
              <Label className="text-white font-medium">Voice Calls</Label>
            </div>
            <Switch 
              checked={settings.callEnabled} 
              onCheckedChange={(checked) => onSettingsChange({
                ...settings,
                callEnabled: checked
              })}
              className="data-[state=checked]:bg-fan-purple"
            />
          </div>
          
          {settings.callEnabled && (
            <div className="bg-secondary/40 p-3 rounded-lg space-y-3">
              <div className="flex items-center gap-2">
                <Label className="text-sm text-white/70">Rate per minute:</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-sm text-white/70">$</span>
                  <Input
                    type="number"
                    value={settings.callRatePerMinute}
                    onChange={(e) => onSettingsChange({
                      ...settings,
                      callRatePerMinute: Number(e.target.value)
                    })}
                    className="pl-7 w-24 bg-secondary/70 border-fan-purple/20"
                    min={0}
                    step={0.01}
                  />
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  value={callDuration}
                  onChange={(e) => setCallDuration(Number(e.target.value))}
                  className="w-16 bg-secondary/70 border-fan-purple/20"
                  min={1}
                />
                <span className="text-sm text-white/70">minutes</span>
                <Button 
                  onClick={handleCall} 
                  className="ml-auto bg-fan-purple hover:bg-fan-purple/80"
                  disabled={isCallLoading}
                >
                  <Phone className="mr-2 h-4 w-4" />
                  Call (${(settings.callRatePerMinute * callDuration).toFixed(2)})
                </Button>
              </div>
            </div>
          )}
        </div>
        
        {/* Text Settings */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-fan-purple" />
              <Label className="text-white font-medium">Text Messages</Label>
            </div>
            <Switch 
              checked={settings.textEnabled} 
              onCheckedChange={(checked) => onSettingsChange({
                ...settings,
                textEnabled: checked
              })}
              className="data-[state=checked]:bg-fan-purple"
            />
          </div>
          
          {settings.textEnabled && (
            <div className="bg-secondary/40 p-3 rounded-lg space-y-3">
              <div className="flex items-center gap-2">
                <Label className="text-sm text-white/70">Rate per message:</Label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-sm text-white/70">$</span>
                  <Input
                    type="number"
                    value={settings.textRatePerMessage}
                    onChange={(e) => onSettingsChange({
                      ...settings,
                      textRatePerMessage: Number(e.target.value)
                    })}
                    className="pl-7 w-24 bg-secondary/70 border-fan-purple/20"
                    min={0}
                    step={0.01}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="w-full bg-secondary/70 border-fan-purple/20 text-white min-h-[80px]"
                />
                <div className="flex justify-end">
                  <Button 
                    onClick={handleText} 
                    className="bg-fan-purple hover:bg-fan-purple/80"
                    disabled={!message.trim() || isTextLoading}
                  >
                    <Send className="mr-2 h-4 w-4" />
                    Send (${settings.textRatePerMessage.toFixed(2)})
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* Availability Information */}
        <div className="bg-fan-purple/10 p-3 rounded-lg">
          <p className="text-sm text-white/80">
            <span className="font-medium">Available:</span> {settings.availability.startTime} - {settings.availability.endTime} ({settings.availability.timezone})
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default CommunicationSection;
