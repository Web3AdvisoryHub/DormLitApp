
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { ChevronRight, InfoIcon, Store, Sparkles, BarChart } from "lucide-react";

interface WhyUpgradePromoProps {
  currentTier?: 'free' | 'premium' | 'pro';
  onUpgrade?: () => void;
  className?: string;
}

const WhyUpgradePromo = ({ 
  currentTier = 'free',
  onUpgrade,
  className 
}: WhyUpgradePromoProps) => {
  
  // Skip rendering if already at Pro tier
  if (currentTier === 'pro') return null;
  
  const getNextTier = () => {
    return currentTier === 'free' ? 'Premium' : 'Pro';
  };
  
  const getUpgradeContent = () => {
    if (currentTier === 'free') {
      return {
        title: "Premium unlocks your style.",
        description: "Multiple rooms. Store access. Custom themes. NFT minting. You go from \"just landed\" to \"main character.\"",
        features: [
          { icon: <Store className="h-5 w-5" />, text: "Open your store" },
          { icon: <Sparkles className="h-5 w-5" />, text: "Custom room themes" },
          { icon: <BarChart className="h-5 w-5" />, text: "Basic analytics" }
        ]
      };
    } else {
      return {
        title: "Pro turns your profile into a portal.",
        description: "Yard expansions. Custom rigged avatars. Neighborhood placement. Full analytics. Your space becomes a vibe—and a business.",
        features: [
          { icon: <Store className="h-5 w-5" />, text: "Expanded store limits" },
          { icon: <Sparkles className="h-5 w-5" />, text: "Riggable avatars" },
          { icon: <BarChart className="h-5 w-5" />, text: "Advanced analytics" }
        ]
      };
    }
  };
  
  const content = getUpgradeContent();
  const nextTier = getNextTier();
  
  return (
    <TooltipProvider>
      <Card className={`bg-gradient-to-br from-fan-purple/30 to-fan-purple/5 border-fan-purple/20 ${className}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white">{content.title}</CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <InfoIcon className="h-5 w-5 text-white/70 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <p>More than a profile...</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Premium and Pro tiers unlock rooms, stores, and avatar magic.
                  It's not just an upgrade—it's your whole vibe leveling up.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription className="text-white/80">
            {content.description}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {content.features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-2">
                <div className="bg-fan-purple/20 p-2 rounded-full">
                  {feature.icon}
                </div>
                <span className="text-white">{feature.text}</span>
              </div>
            ))}
          </div>
          
          <div className="mt-2 text-white/70 text-sm mb-4">
            And yes, you keep your earnings. We take a small fee for system upkeep. The rest? Straight to you.
          </div>
          
          <Button 
            onClick={onUpgrade} 
            className="w-full bg-fan-purple hover:bg-fan-purple/80"
          >
            Upgrade to {nextTier} <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
          
          <div className="mt-4 text-center text-white/50 text-xs">
            Dormlit is more than a profile. It's your digital domain.
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default WhyUpgradePromo;
