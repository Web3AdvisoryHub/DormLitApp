
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  AlertCircle, 
  ChevronUp, 
  ChevronDown, 
  HelpCircle, 
  MessageCircle, 
  X 
} from "lucide-react";
import { cn } from "@/lib/utils";

interface DormlitHelperProps {
  className?: string;
  position?: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
  username?: string;
  tier?: 'free' | 'premium' | 'pro';
}

const DormlitHelper: React.FC<DormlitHelperProps> = ({ 
  className,
  position = 'bottom-right',
  username = 'Creator',
  tier = 'free'
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTip, setSelectedTip] = useState<number | null>(null);
  
  const positionClasses = {
    'bottom-right': 'bottom-6 right-6',
    'bottom-left': 'bottom-6 left-6',
    'top-right': 'top-24 right-6',
    'top-left': 'top-24 left-6'
  };
  
  const tips = [
    `Hey ${username}! Did you know you can customize your avatar with our editor?`,
    `Want to turn on message notifications? Check your communication settings.`,
    tier === 'free' ? 'Upgrade to Premium to unlock your own store and sell items!' : 
    tier === 'premium' ? 'Pro tier unlocks riggable avatars and expanded analytics!' : 
    'As a Pro user, you have access to all Dormlit features!',
    `Need help setting up your rooms? Click here for a step-by-step guide.`,
    `Want to see who's been visiting your dorm? Check your analytics tab.`
  ];
  
  return (
    <div className={cn("fixed z-50", positionClasses[position], className)}>
      {isOpen ? (
        <Card className="w-72 border-fan-purple/30 shadow-lg shadow-fan-purple/10 animate-fade-in bg-black/90">
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-medium text-white flex items-center">
                <HelpCircle className="h-4 w-4 mr-2 text-fan-purple" />
                Dormlit Helper
              </h3>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7 rounded-full" 
                onClick={() => setIsOpen(false)}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="space-y-3">
              {selectedTip !== null ? (
                <div className="animate-fade-in">
                  <div className="flex items-start gap-3 mb-3">
                    <MessageCircle className="h-5 w-5 text-fan-purple mt-0.5" />
                    <p className="text-sm text-white/90">{tips[selectedTip]}</p>
                  </div>
                  <div className="flex justify-between mt-3">
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-xs" 
                      onClick={() => setSelectedTip(null)}
                    >
                      Back to tips
                    </Button>
                    <Button 
                      size="sm" 
                      className="text-xs bg-fan-purple hover:bg-fan-purple/80"
                    >
                      Learn more
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <p className="text-sm text-white/70">
                    What can I help you with today?
                  </p>
                  
                  <div className="space-y-2 mt-3">
                    {tips.map((tip, index) => (
                      <Button 
                        key={index}
                        variant="outline" 
                        className="w-full justify-start text-left h-auto py-2 text-xs border-fan-purple/20 bg-fan-purple/5 hover:bg-fan-purple/10"
                        onClick={() => setSelectedTip(index)}
                      >
                        <AlertCircle className="h-3 w-3 mr-2 text-fan-purple" />
                        <span className="line-clamp-1">{tip.substring(0, 35)}...</span>
                      </Button>
                    ))}
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      ) : (
        <Button
          className="rounded-full h-12 w-12 bg-fan-purple hover:bg-fan-purple/80 shadow-lg shadow-fan-purple/20 animate-pulse"
          onClick={() => setIsOpen(true)}
        >
          <HelpCircle className="h-6 w-6" />
        </Button>
      )}
    </div>
  );
};

export default DormlitHelper;
