
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChevronRight, Lock, Sparkles, User } from "lucide-react";
import { Link } from "react-router-dom";

interface OnboardingMessageProps {
  isCreator?: boolean;
  tier?: 'free' | 'premium' | 'pro';
  onUpgrade?: () => void;
  onDismiss?: () => void;
}

const OnboardingMessages = ({ 
  isCreator = false, 
  tier = 'free',
  onUpgrade,
  onDismiss
}: OnboardingMessageProps) => {
  
  const getTierUpgradeMessage = () => {
    switch(tier) {
      case 'free':
        return {
          title: "Want to unlock more rooms, custom themes, or even your own store?",
          description: "Your next upgrade is just a scroll away.",
          cta: "Upgrade Your Profile",
          feature: "Premium"
        };
      case 'premium':
        return {
          title: "Ready for full customization, riggable avatars, and advanced analytics?",
          description: "Pro tier gives you everything Dormlit has to offer.",
          cta: "Upgrade to Pro",
          feature: "Pro"
        };
      default:
        return {
          title: "You've reached Pro status!",
          description: "Enjoy all the premium features Dormlit has to offer.",
          cta: "Explore Pro Features",
          feature: "Pro"
        };
    }
  };
  
  const upgradeMessage = getTierUpgradeMessage();
  
  return (
    <Tabs defaultValue={isCreator ? "creator" : "free"}>
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="free">Free User</TabsTrigger>
        <TabsTrigger value="upgrade">Upgrade Prompt</TabsTrigger>
        <TabsTrigger value="creator">Creator</TabsTrigger>
      </TabsList>
      
      <TabsContent value="free" className="mt-4">
        <Card className="border-fan-purple/20 bg-gradient-to-br from-fan-purple/10 to-black/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-fan-purple" />
              Welcome to your Dorm
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-white/80">
              Hey, welcome to your Dorm. 💤<br />
              This is your creative base—where your profile becomes a room, your room becomes a world, 
              and your world grows when you do.
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              className="bg-fan-purple hover:bg-fan-purple/80 w-full" 
              onClick={onUpgrade}
              asChild
            >
              <Link to="/upgrade">
                Upgrade Your Profile <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
      </TabsContent>
      
      <TabsContent value="creator" className="mt-4">
        <Card className="border-fan-purple/20 bg-gradient-to-br from-fan-purple/10 to-black/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-fan-purple" />
              This is your home base
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-white/80">
              From here, you can build your profile, set your rates, decorate your rooms, 
              and connect with people who vibe with what you do.<br /><br />
              You're not just a user—you're a builder. Let's set your world in motion.
            </p>
          </CardContent>
          <CardFooter>
            <Button className="bg-fan-purple hover:bg-fan-purple/80 w-full">
              Go to My Dashboard <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </CardFooter>
        </Card>
      </TabsContent>
      
      <TabsContent value="upgrade" className="mt-4">
        <Card className="border-fan-purple/20 bg-gradient-to-br from-fan-purple/10 to-black/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-fan-purple" />
              {tier === 'pro' ? "You've unlocked all features" : "Unlock more features"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-white/80">
              {tier === 'free' ? (
                <>🚨 Looks like you've hit the edge of your free space.<br />
                Want to unlock another room? Upload more links? Access full customization?</>
              ) : tier === 'premium' ? (
                <>You've reached a Pro-only feature.<br />
                Riggable avatars, advanced analytics, and premium discovery live here.</>
              ) : (
                <>You have access to all Dormlit features including riggable avatars, 
                advanced analytics, unlimited store items, and more.</>
              )}
            </p>
          </CardContent>
          <CardFooter>
            {tier !== 'pro' && (
              <Button 
                className="bg-fan-purple hover:bg-fan-purple/80 w-full" 
                onClick={onUpgrade}
                asChild
              >
                <Link to="/upgrade">
                  Upgrade to {upgradeMessage.feature} <ChevronRight className="h-4 w-4 ml-1" />
                </Link>
              </Button>
            )}
          </CardFooter>
        </Card>
      </TabsContent>
    </Tabs>
  );
};

export default OnboardingMessages;
