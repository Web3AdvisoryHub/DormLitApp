
import React, { useState } from 'react';
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import Avatar from './Avatar';

type RoomState = 'online' | 'busy' | 'offline';

type RoomToggleProps = {
  initialState?: RoomState;
  avatarSrc: string;
};

const RoomToggle = ({ initialState = 'offline', avatarSrc }: RoomToggleProps) => {
  const [roomState, setRoomState] = useState<RoomState>(initialState);
  
  const handleToggle = () => {
    setRoomState(current => {
      if (current === 'offline') return 'online';
      if (current === 'online') return 'busy';
      return 'offline';
    });
  };

  const getBgColor = () => {
    switch (roomState) {
      case 'online': return 'bg-gradient-to-br from-fan-purple to-fan-dark-purple';
      case 'busy': return 'bg-gradient-to-br from-fan-dark-purple to-[#2C2540]';
      default: return 'bg-secondary';
    }
  };

  const getStatusText = () => {
    switch (roomState) {
      case 'online': return 'Available';
      case 'busy': return 'Busy';
      default: return 'Offline';
    }
  };

  return (
    <div className="glass-card p-6 w-full">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Room Status</h3>
        <div className="flex items-center">
          <span className="text-sm mr-2 text-white/80">{getStatusText()}</span>
          <Switch 
            checked={roomState !== 'offline'} 
            onCheckedChange={handleToggle}
            className="data-[state=checked]:bg-fan-purple"
          />
        </div>
      </div>
      
      <div 
        className={cn(
          "rounded-xl p-6 h-48 transition-all duration-500 relative overflow-hidden",
          getBgColor()
        )}
      >
        <div className="absolute bottom-4 right-4 z-10">
          <Avatar 
            src={avatarSrc} 
            size="lg"
            showGlow={roomState === 'online'}
            className={cn(
              "transition-all duration-300",
              roomState === 'online' && "animate-float"
            )}
          />
        </div>
        
        {roomState === 'online' && (
          <div className="absolute top-4 left-4 animate-fade-in">
            <span className="inline-block px-3 py-1 bg-white/10 backdrop-blur-sm rounded-full text-white text-xs">
              💬 Available to chat
            </span>
          </div>
        )}
        
        {roomState === 'busy' && (
          <div className="absolute top-4 left-4 animate-fade-in">
            <span className="inline-block px-3 py-1 bg-black/30 backdrop-blur-sm rounded-full text-white text-xs">
              🔴 On a call
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default RoomToggle;
