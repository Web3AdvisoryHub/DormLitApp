
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { DollarSign, CreditCard, Ticket, BadgeDollarSign } from "lucide-react";
import { PaymentSettings, PaymentPlan } from '@/types';
import { useToast } from '@/hooks/use-toast';

interface PaymentSectionProps {
  settings: PaymentSettings;
  onTip?: (amount: number) => Promise<void>;
  onSubscribe?: (planId: string) => Promise<void>;
}

const PaymentSection = ({
  settings,
  onTip = async () => {},
  onSubscribe = async () => {}
}: PaymentSectionProps) => {
  const [tipAmount, setTipAmount] = useState(5);
  const [isProcessingTip, setIsProcessingTip] = useState(false);
  const [isProcessingSubscription, setIsProcessingSubscription] = useState<string | null>(null);
  const { toast } = useToast();

  const handleTip = async () => {
    if (tipAmount <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid tip amount.",
        variant: "destructive"
      });
      return;
    }

    setIsProcessingTip(true);
    try {
      await onTip(tipAmount);
      toast({
        title: "Tip Sent",
        description: `Successfully sent a ${tipAmount} ${settings.acceptedCurrencies[0]} tip!`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send tip. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessingTip(false);
    }
  };

  const handleSubscribe = async (plan: PaymentPlan) => {
    setIsProcessingSubscription(plan.id);
    try {
      await onSubscribe(plan.id);
      toast({
        title: "Subscription Started",
        description: `Successfully subscribed to ${plan.name}!`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start subscription. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessingSubscription(null);
    }
  };

  // Format currency with dollar sign
  const formatCurrency = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };

  return (
    <div className="space-y-6">
      {settings.tipEnabled && (
        <Card className="glass-card border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold text-white">
              Support this Creator
            </CardTitle>
            <CardDescription>
              Show your appreciation with a tip
            </CardDescription>
          </CardHeader>
          <CardContent className="pb-4">
            <div className="flex gap-2 items-center">
              <div className="relative flex-1">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-white/50 h-4 w-4" />
                <Input
                  type="number"
                  value={tipAmount}
                  onChange={(e) => setTipAmount(Math.max(1, Number(e.target.value)))}
                  min="1"
                  className="pl-9 bg-secondary/80 border-fan-purple/20 text-white"
                />
              </div>
              <Button 
                onClick={handleTip}
                disabled={isProcessingTip}
                className="bg-fan-purple hover:bg-fan-dark-purple"
              >
                {isProcessingTip ? (
                  "Processing..."
                ) : (
                  <>
                    <BadgeDollarSign className="mr-2 h-4 w-4" />
                    Send Tip
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {settings.subscriptionPlans.length > 0 && (
        <Card className="glass-card border-0">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-semibold text-white">
              Subscription Plans
            </CardTitle>
            <CardDescription>
              Get exclusive benefits and content
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {settings.subscriptionPlans.map((plan) => (
                <Card key={plan.id} className="glass-card border-0 overflow-hidden">
                  <CardHeader className="bg-fan-purple/20 pb-2">
                    <CardTitle className="text-md text-white">{plan.name}</CardTitle>
                    <CardDescription className="text-white/90 text-lg font-bold">
                      {formatCurrency(plan.price)}/{plan.duration}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-4 pb-2">
                    <ul className="space-y-2">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="text-sm flex items-start">
                          <Ticket className="h-4 w-4 mr-2 text-fan-purple shrink-0 mt-0.5" />
                          <span className="text-white/80">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      onClick={() => handleSubscribe(plan)}
                      disabled={isProcessingSubscription !== null}
                      className="w-full bg-fan-purple hover:bg-fan-dark-purple"
                    >
                      {isProcessingSubscription === plan.id ? (
                        "Processing..."
                      ) : (
                        <>
                          <CreditCard className="mr-2 h-4 w-4" />
                          Subscribe Now
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PaymentSection;
