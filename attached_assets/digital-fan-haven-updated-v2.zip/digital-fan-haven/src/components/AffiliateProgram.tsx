
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Copy, Users, DollarSign, TrendingUp, Share2, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { AffiliateInfo, Referral, AffiliateProgramProps } from "@/types";

const AffiliateProgram: React.FC<AffiliateProgramProps> = ({ 
  isEnabled = true, 
  affiliateInfo,
  creatorId = '1',
  creatorName = 'Creator',
  onEnable,
  onEnableAffiliate,
  isCurrentUser = true
}) => {
  const { toast } = useToast();
  const [showAffiliateModal, setShowAffiliateModal] = useState(false);
  
  // Default values if affiliateInfo is not provided
  const referralCode = affiliateInfo?.referralCode || `${creatorId.substring(0, 6)}`;
  const commissionRate = 30; // Updated to 30% as per requirements
  const totalEarnings = affiliateInfo?.totalEarnings || 0;
  const pendingPayouts = affiliateInfo?.pendingPayouts || 0;
  const referrals = affiliateInfo?.referrals || [];
  
  const handleCopyReferralLink = () => {
    const link = `https://yourdomain.com/join?ref=${referralCode}`;
    navigator.clipboard.writeText(link).then(() => {
      toast({
        title: "Copied to clipboard",
        description: "Your referral link has been copied to clipboard!",
      });
    });
  };
  
  const handleCopyReferralCode = () => {
    navigator.clipboard.writeText(referralCode).then(() => {
      toast({
        title: "Copied to clipboard",
        description: "Your referral code has been copied to clipboard!",
      });
    });
  };
  
  const handleEnableAffiliate = () => {
    // Support both prop names for backward compatibility
    if (onEnableAffiliate) {
      onEnableAffiliate();
    } else if (onEnable) {
      onEnable();
    }
    
    toast({
      title: "Affiliate Program Enabled",
      description: "You've successfully joined the affiliate program!",
    });
    
    setShowAffiliateModal(false);
  };
  
  const handleJoinAffiliate = () => {
    // Redirect to signup with affiliate tracking
    window.location.href = `/signup?ref=${referralCode}`;
  };
  
  // Fan view - show simplified UI
  if (!isCurrentUser) {
    return (
      <Card className="bg-secondary/10 border-secondary/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="h-5 w-5 text-fan-purple" /> 
            Join Dormlit.Grow
          </CardTitle>
          <CardDescription>
            Join our platform and start building your own creator page
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-white/80 mb-4">
            Join Dormlit.Grow through {creatorName}'s referral and get special benefits when you sign up.
          </p>
          <Button 
            className="w-full bg-fan-purple hover:bg-fan-purple/80"
            onClick={handleJoinAffiliate}
          >
            Join Now
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  // Creator view - disabled affiliate program
  if (!isEnabled) {
    return (
      <Card className="bg-secondary/10 border-secondary/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Users className="h-5 w-5 text-fan-purple" /> 
            Affiliate Program
          </CardTitle>
          <CardDescription>
            Earn 30% commission for the first 3 months when referring creators
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="bg-secondary/20 border-fan-purple/30">
            <AlertCircle className="h-4 w-4 text-fan-purple" />
            <AlertTitle>Unlock Affiliate Benefits</AlertTitle>
            <AlertDescription>
              Upgrade to our Platinum tier to unlock the affiliate program and earn 30% commission for the first 3 months when creators you refer join our platform.
            </AlertDescription>
          </Alert>
        </CardContent>
        <CardFooter>
          <Dialog open={showAffiliateModal} onOpenChange={setShowAffiliateModal}>
            <DialogTrigger asChild>
              <Button className="w-full bg-fan-purple hover:bg-fan-purple/80">
                Learn More
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-fan-background border-fan-purple/30">
              <DialogHeader>
                <DialogTitle className="text-white">Affiliate Program Benefits</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="p-4 bg-secondary/20 rounded-lg border border-secondary/30">
                    <div className="flex items-start gap-3">
                      <div className="bg-fan-purple/20 p-2 rounded-full">
                        <DollarSign className="h-5 w-5 text-fan-purple" />
                      </div>
                      <div>
                        <h3 className="text-white font-medium mb-1">Earn Commissions</h3>
                        <p className="text-white/70 text-sm">
                          Earn 30% commission on all payments made by creators you refer for their first 3 months on the platform.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-secondary/20 rounded-lg border border-secondary/30">
                    <div className="flex items-start gap-3">
                      <div className="bg-fan-purple/20 p-2 rounded-full">
                        <Users className="h-5 w-5 text-fan-purple" />
                      </div>
                      <div>
                        <h3 className="text-white font-medium mb-1">Grow The Community</h3>
                        <p className="text-white/70 text-sm">
                          Help grow our community of creators and earn while doing so.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-secondary/20 rounded-lg border border-secondary/30">
                    <div className="flex items-start gap-3">
                      <div className="bg-fan-purple/20 p-2 rounded-full">
                        <TrendingUp className="h-5 w-5 text-fan-purple" />
                      </div>
                      <div>
                        <h3 className="text-white font-medium mb-1">Track Performance</h3>
                        <p className="text-white/70 text-sm">
                          Get detailed analytics on your referrals and earnings.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4">
                  <Button className="w-full bg-fan-purple hover:bg-fan-purple/80">
                    Upgrade to Platinum
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardFooter>
      </Card>
    );
  }
  
  // Creator view - enabled affiliate program
  return (
    <Card className="bg-secondary/10 border-secondary/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Users className="h-5 w-5 text-fan-purple" /> 
          Affiliate Program
        </CardTitle>
        <CardDescription>
          Earn 30% commission for the first 3 months when referring creators
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-secondary/20 rounded-lg">
            <p className="text-sm text-white/70 mb-1">Total Earnings</p>
            <p className="text-xl font-semibold text-white">${totalEarnings.toFixed(2)}</p>
          </div>
          
          <div className="p-3 bg-secondary/20 rounded-lg">
            <p className="text-sm text-white/70 mb-1">Pending</p>
            <p className="text-xl font-semibold text-white">${pendingPayouts.toFixed(2)}</p>
          </div>
        </div>
        
        <div className="p-4 bg-secondary/20 rounded-lg border border-fan-purple/30">
          <p className="text-sm font-medium text-white mb-2">Your Referral Link</p>
          <div className="flex items-center">
            <Input 
              value={`https://yourdomain.com/join?ref=${referralCode}`}
              readOnly
              className="bg-secondary/30 border-fan-purple/20 text-white"
            />
            <Button 
              variant="outline"
              size="icon"
              className="ml-2 bg-secondary/40 border-fan-purple/20"
              onClick={handleCopyReferralLink}
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="mt-3 flex items-center justify-between">
            <div className="flex items-center">
              <p className="text-sm text-white/70 mr-2">Referral Code:</p>
              <p className="text-sm font-mono bg-secondary/40 px-2 py-1 rounded text-white">{referralCode}</p>
            </div>
            <Button 
              variant="ghost" 
              size="sm"
              className="h-7 text-white/70 hover:text-white hover:bg-secondary/40"
              onClick={handleCopyReferralCode}
            >
              <Copy className="h-3 w-3 mr-1" /> Copy
            </Button>
          </div>
        </div>
        
        <div className="flex justify-end">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="border-fan-purple/30">
                <Share2 className="h-4 w-4 mr-2" /> Share
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-fan-background border-fan-purple/30">
              <DialogHeader>
                <DialogTitle className="text-white">Share Your Referral</DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4 py-4">
                <p className="text-white/70">
                  Share your referral link with other creators to earn 30% commission for their first 3 months.
                </p>
                
                <div className="space-y-2">
                  <p className="text-sm text-white/90 font-medium">Custom Message</p>
                  <textarea
                    className="w-full p-3 bg-secondary/30 border border-fan-purple/20 rounded-md text-white"
                    rows={3}
                    placeholder="Join me on this amazing platform for creators!"
                    defaultValue={`Hey! I've been using this amazing platform called Dormlit for my creator business. Join using my referral code: ${referralCode}`}
                  ></textarea>
                </div>
                
                <div className="grid grid-cols-3 gap-2">
                  <Button variant="outline" className="border-fan-purple/30">
                    Twitter
                  </Button>
                  <Button variant="outline" className="border-fan-purple/30">
                    Instagram
                  </Button>
                  <Button variant="outline" className="border-fan-purple/30">
                    Email
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardContent>
    </Card>
  );
};

export default AffiliateProgram;
