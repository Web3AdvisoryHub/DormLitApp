
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CheckCircle, ChevronRight, Edit, Link, ShoppingBag, MessageSquare, Image, Music, Dumbbell, Computer } from "lucide-react";
import { useNavigate } from 'react-router-dom';

interface WelcomeModalProps {
  isOpen: boolean;
  onClose: () => void;
  username: string;
}

const WelcomeModal: React.FC<WelcomeModalProps> = ({ isOpen, onClose, username }) => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const totalSteps = 4;

  const handleNext = () => {
    if (step < totalSteps) {
      setStep(step + 1);
    } else {
      onClose();
    }
  };

  const navigateToCategory = (category: string) => {
    // Store the category filter preference in session storage
    sessionStorage.setItem('dormlet_explore_category', category);
    // Close the modal and navigate to explore page
    onClose();
    navigate('/explore');
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <>
            <DialogHeader>
              <DialogTitle className="text-2xl">Welcome to Dormlit, {username}!</DialogTitle>
              <DialogDescription>
                Your creator profile is ready! Let's take a quick tour of what you can do.
              </DialogDescription>
            </DialogHeader>
            <div className="py-6 space-y-4">
              <div className="flex items-center space-x-4">
                <div className="bg-primary/20 p-3 rounded-full">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Your profile is set up</h3>
                  <p className="text-sm text-muted-foreground">Everything's ready for you to personalize</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="bg-primary/20 p-3 rounded-full">
                  <Edit className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Customize your profile</h3>
                  <p className="text-sm text-muted-foreground">Update your bio, profile picture, and more</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="bg-primary/20 p-3 rounded-full">
                  <Link className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Add your social links</h3>
                  <p className="text-sm text-muted-foreground">Instagram, TikTok, YouTube - all ready to connect</p>
                </div>
              </div>
            </div>
          </>
        );
      case 2:
        return (
          <>
            <DialogHeader>
              <DialogTitle className="text-2xl">Share Your Content</DialogTitle>
              <DialogDescription>
                We've added placeholders for you to showcase your best content.
              </DialogDescription>
            </DialogHeader>
            <div className="py-6">
              <div className="rounded-lg border p-4 mb-4 bg-muted/30">
                <h3 className="font-medium mb-2">Featured Content Bar</h3>
                <p className="text-sm text-muted-foreground mb-2">Highlight your best work from any platform</p>
                <div className="flex gap-2 overflow-x-auto py-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="w-32 h-24 rounded-md bg-secondary/40 flex-shrink-0 flex items-center justify-center border border-dashed">
                      <span className="text-xs">Content {i}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="rounded-lg border p-4 bg-muted/30">
                <h3 className="font-medium mb-2">Creator Links</h3>
                <p className="text-sm text-muted-foreground mb-2">Add links to other platforms or resources</p>
                <div className="space-y-2">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="rounded-md bg-secondary/40 p-2 text-sm border border-dashed flex items-center">
                      <Link className="h-4 w-4 mr-2" />
                      <span>Link {i}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        );
      case 3:
        return (
          <>
            <DialogHeader>
              <DialogTitle className="text-2xl">Connect With Fans</DialogTitle>
              <DialogDescription>
                Your communication channels are ready to activate.
              </DialogDescription>
            </DialogHeader>
            <div className="py-6 space-y-4">
              <div className="flex items-center space-x-4">
                <div className="bg-primary/20 p-3 rounded-full">
                  <MessageSquare className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Direct Messages</h3>
                  <p className="text-sm text-muted-foreground">Set your rates and toggle messages on/off</p>
                </div>
              </div>
              <div className="rounded-lg border p-4 bg-muted/30">
                <h3 className="font-medium mb-2">Fan Wall</h3>
                <p className="text-sm text-muted-foreground">Let fans leave public messages and tips</p>
                <div className="mt-2 p-3 rounded-md bg-secondary/40 border border-dashed text-sm">
                  Your fan messages will appear here
                </div>
              </div>
            </div>
          </>
        );
      case 4:
        return (
          <>
            <DialogHeader>
              <DialogTitle className="text-2xl">Explore Dorm Vibes</DialogTitle>
              <DialogDescription>
                Discover creator dorms by vibe category.
              </DialogDescription>
            </DialogHeader>
            <div className="py-6">
              <div className="grid grid-cols-2 gap-4">
                <div 
                  className="bg-white dark:bg-gray-800 p-4 rounded-lg flex flex-col items-center cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigateToCategory('Arts')}
                >
                  <div className="bg-primary/10 p-3 rounded-full mb-3">
                    <Image className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-medium">Arts</h3>
                  <p className="text-xs text-center text-muted-foreground mt-1">Explore creative dorms</p>
                </div>
                
                <div 
                  className="bg-white dark:bg-gray-800 p-4 rounded-lg flex flex-col items-center cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigateToCategory('Music')}
                >
                  <div className="bg-primary/10 p-3 rounded-full mb-3">
                    <Music className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-medium">Music</h3>
                  <p className="text-xs text-center text-muted-foreground mt-1">Discover musical talents</p>
                </div>
                
                <div 
                  className="bg-white dark:bg-gray-800 p-4 rounded-lg flex flex-col items-center cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigateToCategory('Fitness')}
                >
                  <div className="bg-primary/10 p-3 rounded-full mb-3">
                    <Dumbbell className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-medium">Fitness</h3>
                  <p className="text-xs text-center text-muted-foreground mt-1">Join fitness creators</p>
                </div>
                
                <div 
                  className="bg-white dark:bg-gray-800 p-4 rounded-lg flex flex-col items-center cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => navigateToCategory('Technology')}
                >
                  <div className="bg-primary/10 p-3 rounded-full mb-3">
                    <Computer className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-medium">Technology</h3>
                  <p className="text-xs text-center text-muted-foreground mt-1">Explore tech content</p>
                </div>
              </div>
            </div>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-md">
        {renderStep()}
        <div className="flex justify-between mt-4">
          <div className="flex space-x-1">
            {Array.from({ length: totalSteps }).map((_, i) => (
              <div
                key={i}
                className={`h-1.5 w-6 rounded-full ${
                  i + 1 <= step ? 'bg-primary' : 'bg-muted'
                }`}
              />
            ))}
          </div>
          <Button onClick={handleNext} className="flex items-center gap-2">
            {step < totalSteps ? 'Next' : 'Start Exploring'}
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WelcomeModal;
