
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { EarningsBreakdown, EarningSource } from '@/types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { DollarSign, Calendar, Download, CreditCard, AlertTriangle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { formatCurrency } from '@/utils/formatters';
import EarningsTable from './EarningsTable';

interface EarningsSectionProps {
  earnings: EarningsBreakdown;
  recentTransactions: EarningSource[];
  onRequestPayout: () => Promise<void>;
  isWalletConnected: boolean;
  onConnectWallet: () => void;
  isPayoutAvailable: boolean;
  minimumPayout: number;
}

const COLORS = ['#8b5cf6', '#d946ef', '#ec4899', '#f43f5e', '#f97316', '#facc15'];

const EarningsSection: React.FC<EarningsSectionProps> = ({
  earnings,
  recentTransactions,
  onRequestPayout,
  isWalletConnected,
  onConnectWallet,
  isPayoutAvailable,
  minimumPayout,
}) => {
  const { toast } = useToast();
  const [isProcessingPayout, setIsProcessingPayout] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'transactions' | 'analytics'>('overview');

  const handleRequestPayout = async () => {
    if (!isWalletConnected) {
      toast({
        title: "Wallet Required",
        description: "Please connect your wallet to request a payout.",
        variant: "destructive",
      });
      return;
    }

    if (!isPayoutAvailable) {
      toast({
        title: "Payout Unavailable",
        description: `You need at least $${minimumPayout.toFixed(2)} to request a payout.`,
        variant: "destructive",
      });
      return;
    }

    try {
      setIsProcessingPayout(true);
      await onRequestPayout();
      toast({
        title: "Payout Requested",
        description: "Your payout has been requested and will be processed within 1-3 business days.",
      });
    } catch (error) {
      toast({
        title: "Payout Failed",
        description: "There was an error processing your payout request. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessingPayout(false);
    }
  };

  const earningsData = [
    { name: 'Tips', value: earnings.tipEarnings },
    { name: 'Messages', value: earnings.messageEarnings },
    { name: 'Calls', value: earnings.callEarnings },
    { name: 'Store', value: earnings.storeEarnings },
    { name: 'NFTs', value: earnings.nftEarnings },
    { name: 'Affiliate', value: earnings.affiliateEarnings },
  ].filter(item => item.value > 0);

  const periodData = earnings.byPeriod.map(item => ({
    name: item.period,
    amount: item.amount,
  }));

  return (
    <Card className="bg-secondary/10 border-secondary/20">
      <CardHeader>
        <CardTitle className="text-xl text-white flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-fan-purple" />
          Earnings & Analytics
        </CardTitle>
        <CardDescription className="text-white/70">
          Track your earnings and get insights on your performance
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs 
          defaultValue="overview" 
          value={activeTab} 
          onValueChange={(value) => setActiveTab(value as 'overview' | 'transactions' | 'analytics')}
          className="w-full"
        >
          <TabsList className="grid grid-cols-3 mb-4 bg-secondary/20">
            <TabsTrigger 
              value="overview" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              Overview
            </TabsTrigger>
            <TabsTrigger 
              value="transactions" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              Transactions
            </TabsTrigger>
            <TabsTrigger 
              value="analytics" 
              className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
            >
              Analytics
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card className="bg-secondary/20 border-secondary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-white/80">Total Earnings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{formatCurrency(earnings.totalEarnings)}</div>
                  <p className="text-xs text-white/60 mt-1">Lifetime earnings</p>
                </CardContent>
              </Card>
              
              <Card className="bg-secondary/20 border-secondary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-white/80">Available for Payout</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{formatCurrency(earnings.availableForPayout)}</div>
                  <p className="text-xs text-white/60 mt-1">Ready to withdraw</p>
                </CardContent>
              </Card>
              
              <Card className="bg-secondary/20 border-secondary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-white/80">Pending</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{formatCurrency(earnings.pendingEarnings)}</div>
                  <p className="text-xs text-white/60 mt-1">Processing payments</p>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <h4 className="text-sm font-medium text-white/80 mb-3">Earnings Breakdown</h4>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={earningsData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        paddingAngle={5}
                        dataKey="value"
                        label={({name, percent}) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {earningsData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value: number) => formatCurrency(value)}
                        contentStyle={{ backgroundColor: 'rgba(0, 0, 0, 0.7)', border: 'none' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              <div>
                <h4 className="text-sm font-medium text-white/80 mb-3">Earnings Over Time</h4>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={periodData}
                      margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                      <XAxis dataKey="name" tick={{ fill: 'rgba(255, 255, 255, 0.7)' }} />
                      <YAxis tick={{ fill: 'rgba(255, 255, 255, 0.7)' }} />
                      <Tooltip 
                        formatter={(value: number) => formatCurrency(value)}
                        contentStyle={{ backgroundColor: 'rgba(0, 0, 0, 0.7)', border: 'none' }}
                      />
                      <Bar dataKey="amount" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
            
            <div className="mt-6 flex justify-between items-center">
              <div>
                <h4 className="text-sm font-medium text-white">Payout Options</h4>
                <p className="text-xs text-white/60 mt-1">
                  {isPayoutAvailable
                    ? "You have sufficient funds to request a payout"
                    : `Minimum payout amount: ${formatCurrency(minimumPayout)}`
                  }
                </p>
              </div>
              
              <Dialog>
                <DialogTrigger asChild>
                  <Button 
                    className="bg-fan-purple hover:bg-fan-purple/80"
                    disabled={!isPayoutAvailable || isProcessingPayout}
                  >
                    <DollarSign className="mr-2 h-4 w-4" />
                    Request Payout
                  </Button>
                </DialogTrigger>
                <DialogContent className="bg-secondary border-secondary/30">
                  <DialogHeader>
                    <DialogTitle className="text-white">Request Payout</DialogTitle>
                    <DialogDescription>
                      Confirm that you want to withdraw {formatCurrency(earnings.availableForPayout)} to your connected wallet.
                    </DialogDescription>
                  </DialogHeader>
                  
                  {!isWalletConnected ? (
                    <div className="p-4 bg-black/20 rounded-md mb-4">
                      <div className="flex items-start gap-3">
                        <AlertTriangle className="h-5 w-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <h4 className="text-sm font-medium text-white">Wallet Required</h4>
                          <p className="text-xs text-white/70 mt-1">
                            You need to connect a wallet to receive your payout.
                          </p>
                          <Button 
                            className="mt-3 bg-fan-purple hover:bg-fan-purple/80" 
                            size="sm"
                            onClick={onConnectWallet}
                          >
                            Connect Wallet
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="p-4 bg-black/20 rounded-md">
                        <div className="flex items-center justify-between">
                          <span className="text-white/70">Available for payout</span>
                          <span className="text-white font-medium">{formatCurrency(earnings.availableForPayout)}</span>
                        </div>
                      </div>
                      
                      <div className="p-4 bg-black/20 rounded-md">
                        <div className="flex items-start gap-3">
                          <CreditCard className="h-5 w-5 text-fan-purple flex-shrink-0 mt-0.5" />
                          <div>
                            <h4 className="text-sm font-medium text-white">Payout Information</h4>
                            <p className="text-xs text-white/70 mt-1">
                              Payments are processed within 1-3 business days. You'll receive a notification when your payout is complete.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <DialogFooter className="mt-4">
                    <Button
                      variant="outline"
                      onClick={handleRequestPayout}
                      disabled={!isWalletConnected || !isPayoutAvailable || isProcessingPayout}
                      className="w-full"
                    >
                      {isProcessingPayout ? 'Processing...' : 'Confirm Payout'}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </TabsContent>
          
          <TabsContent value="transactions" className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-white">Recent Transactions</h3>
              <Button variant="outline" size="sm" className="border-fan-purple/30 text-white">
                <Download className="h-4 w-4 mr-2" /> Export
              </Button>
            </div>
            <EarningsTable transactions={recentTransactions} />
          </TabsContent>
          
          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card className="bg-secondary/20 border-secondary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-white/80">Profile Views</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">1,245</div>
                  <p className="text-xs text-white/60 mt-1">
                    <span className="text-green-400">↑ 12%</span> vs last month
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-secondary/20 border-secondary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-white/80">Engagement Rate</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">8.3%</div>
                  <p className="text-xs text-white/60 mt-1">
                    <span className="text-green-400">↑ 2.1%</span> vs last month
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-secondary/20 border-secondary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-white/80">New Followers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">87</div>
                  <p className="text-xs text-white/60 mt-1">
                    <span className="text-red-400">↓ 3%</span> vs last month
                  </p>
                </CardContent>
              </Card>
            </div>
            
            <div className="bg-secondary/20 border border-secondary/30 rounded-lg p-4 mb-6">
              <h4 className="text-sm font-medium text-white/80 mb-3 flex items-center">
                <Calendar className="h-4 w-4 mr-2 text-fan-purple" />
                Profile Views Over Time
              </h4>
              <div className="h-[250px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={[
                      { date: 'Mon', views: 120 },
                      { date: 'Tue', views: 145 },
                      { date: 'Wed', views: 180 },
                      { date: 'Thu', views: 210 },
                      { date: 'Fri', views: 235 },
                      { date: 'Sat', views: 280 },
                      { date: 'Sun', views: 190 },
                    ]}
                    margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                    <XAxis dataKey="date" tick={{ fill: 'rgba(255, 255, 255, 0.7)' }} />
                    <YAxis tick={{ fill: 'rgba(255, 255, 255, 0.7)' }} />
                    <Tooltip
                      formatter={(value: number) => [`${value} views`, 'Views']}
                      contentStyle={{ backgroundColor: 'rgba(0, 0, 0, 0.7)', border: 'none' }}
                    />
                    <Bar dataKey="views" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-secondary/20 border-secondary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-white/80">Top Performing Content</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { title: 'Latest NFT Collection', type: 'NFT', views: 342, engagement: '12.5%' },
                    { title: 'Pixel Art Tutorial', type: 'Post', views: 278, engagement: '9.3%' },
                    { title: 'Creator Room Tour', type: 'Room', views: 215, engagement: '7.8%' },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-2 bg-black/20 rounded">
                      <div>
                        <h5 className="text-sm font-medium text-white">{item.title}</h5>
                        <span className="text-xs text-white/60">{item.type}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-white">{item.views} views</div>
                        <div className="text-xs text-green-400">{item.engagement} engagement</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
              
              <Card className="bg-secondary/20 border-secondary/30">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base text-white/80">Conversion Rates</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-white/70">View to Tip</span>
                      <span className="font-medium text-white">2.4%</span>
                    </div>
                    <div className="w-full bg-secondary/30 rounded-full h-2">
                      <div className="bg-fan-purple h-2 rounded-full" style={{ width: '2.4%' }} />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-white/70">View to Message</span>
                      <span className="font-medium text-white">5.1%</span>
                    </div>
                    <div className="w-full bg-secondary/30 rounded-full h-2">
                      <div className="bg-fan-purple h-2 rounded-full" style={{ width: '5.1%' }} />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-white/70">View to Purchase</span>
                      <span className="font-medium text-white">1.8%</span>
                    </div>
                    <div className="w-full bg-secondary/30 rounded-full h-2">
                      <div className="bg-fan-purple h-2 rounded-full" style={{ width: '1.8%' }} />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-white/70">View to Call</span>
                      <span className="font-medium text-white">0.7%</span>
                    </div>
                    <div className="w-full bg-secondary/30 rounded-full h-2">
                      <div className="bg-fan-purple h-2 rounded-full" style={{ width: '0.7%' }} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default EarningsSection;
