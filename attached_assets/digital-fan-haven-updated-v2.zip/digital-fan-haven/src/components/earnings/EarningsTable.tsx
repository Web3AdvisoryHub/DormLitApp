
import React, { useState } from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuLabel, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { 
  MessageSquare, 
  DollarSign, 
  Phone, 
  ShoppingBag, 
  Image, 
  Users, 
  MoreVertical, 
  ExternalLink, 
  Info,
  Check,
  Clock
} from 'lucide-react';
import { 
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { EarningSource } from '@/types';
import { formatCurrency } from '@/utils/formatters';

interface EarningsTableProps {
  transactions: EarningSource[];
}

const EarningsTable: React.FC<EarningsTableProps> = ({ transactions }) => {
  const [filter, setFilter] = useState<string | null>(null);

  const filteredTransactions = filter 
    ? transactions.filter(tx => tx.type === filter)
    : transactions;

  const getIcon = (type: string) => {
    switch (type) {
      case 'tip':
        return <DollarSign className="h-4 w-4 text-green-500" />;
      case 'message':
        return <MessageSquare className="h-4 w-4 text-blue-500" />;
      case 'call':
        return <Phone className="h-4 w-4 text-indigo-500" />;
      case 'store':
        return <ShoppingBag className="h-4 w-4 text-pink-500" />;
      case 'nft':
        return <Image className="h-4 w-4 text-purple-500" />;
      case 'affiliate':
        return <Users className="h-4 w-4 text-amber-500" />;
      default:
        return <DollarSign className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    return status === 'completed' ? 'text-green-500' : 'text-amber-500';
  };

  const getStatusIcon = (status: string) => {
    return status === 'completed' ? <Check className="h-4 w-4" /> : <Clock className="h-4 w-4" />;
  };
  
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(date);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 overflow-x-auto pb-2">
        <Button
          variant={filter === null ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter(null)}
          className={filter === null ? "bg-fan-purple hover:bg-fan-purple/80" : "border-fan-purple/30"}
        >
          All
        </Button>
        <Button
          variant={filter === 'tip' ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter('tip')}
          className={filter === 'tip' ? "bg-fan-purple hover:bg-fan-purple/80" : "border-fan-purple/30"}
        >
          <DollarSign className="h-4 w-4 mr-1" /> Tips
        </Button>
        <Button
          variant={filter === 'message' ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter('message')}
          className={filter === 'message' ? "bg-fan-purple hover:bg-fan-purple/80" : "border-fan-purple/30"}
        >
          <MessageSquare className="h-4 w-4 mr-1" /> Messages
        </Button>
        <Button
          variant={filter === 'call' ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter('call')}
          className={filter === 'call' ? "bg-fan-purple hover:bg-fan-purple/80" : "border-fan-purple/30"}
        >
          <Phone className="h-4 w-4 mr-1" /> Calls
        </Button>
        <Button
          variant={filter === 'store' ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter('store')}
          className={filter === 'store' ? "bg-fan-purple hover:bg-fan-purple/80" : "border-fan-purple/30"}
        >
          <ShoppingBag className="h-4 w-4 mr-1" /> Store
        </Button>
        <Button
          variant={filter === 'nft' ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter('nft')}
          className={filter === 'nft' ? "bg-fan-purple hover:bg-fan-purple/80" : "border-fan-purple/30"}
        >
          <Image className="h-4 w-4 mr-1" /> NFTs
        </Button>
        <Button
          variant={filter === 'affiliate' ? "default" : "outline"}
          size="sm"
          onClick={() => setFilter('affiliate')}
          className={filter === 'affiliate' ? "bg-fan-purple hover:bg-fan-purple/80" : "border-fan-purple/30"}
        >
          <Users className="h-4 w-4 mr-1" /> Affiliate
        </Button>
      </div>

      <div className="rounded-md border border-secondary/30 overflow-hidden">
        <Table>
          <TableHeader className="bg-secondary/20">
            <TableRow>
              <TableHead className="text-white/70 w-[250px]">Transaction</TableHead>
              <TableHead className="text-white/70">Type</TableHead>
              <TableHead className="text-white/70">Date</TableHead>
              <TableHead className="text-white/70">Amount</TableHead>
              <TableHead className="text-white/70">Status</TableHead>
              <TableHead className="text-white/70 text-right"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTransactions.length > 0 ? (
              filteredTransactions.map((tx) => (
                <TableRow key={tx.id} className="border-secondary/20 hover:bg-secondary/10">
                  <TableCell className="font-medium text-white">
                    {tx.name}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getIcon(tx.type)}
                      <span className="capitalize text-white/80">{tx.type}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-white/70">
                    {formatDate(tx.date)}
                  </TableCell>
                  <TableCell className="font-medium text-white">
                    {formatCurrency(tx.amount)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(tx.status)}
                      <span className={`capitalize ${getStatusColor(tx.status)}`}>
                        {tx.status}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end">
                      <HoverCard>
                        <HoverCardTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Info className="h-4 w-4 text-white/60" />
                          </Button>
                        </HoverCardTrigger>
                        <HoverCardContent className="w-80" align="end">
                          <div className="space-y-2">
                            <h4 className="font-semibold text-sm">Transaction Details</h4>
                            <div className="grid grid-cols-3 gap-2 text-sm">
                              <div className="text-muted-foreground">ID</div>
                              <div className="col-span-2 font-mono text-xs">{tx.id}</div>
                              <div className="text-muted-foreground">Type</div>
                              <div className="col-span-2 capitalize">{tx.type}</div>
                              <div className="text-muted-foreground">Amount</div>
                              <div className="col-span-2">{formatCurrency(tx.amount)}</div>
                              <div className="text-muted-foreground">Date</div>
                              <div className="col-span-2">{formatDate(tx.date)}</div>
                              <div className="text-muted-foreground">Status</div>
                              <div className="col-span-2 capitalize">{tx.status}</div>
                            </div>
                          </div>
                        </HoverCardContent>
                      </HoverCard>
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4 text-white/60" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-secondary/80 text-white border-secondary/50">
                          <DropdownMenuLabel>Options</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            <ExternalLink className="h-4 w-4 mr-2" />
                            <span>View details</span>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={6} className="h-24 text-center text-white/60">
                  No transactions found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default EarningsTable;
