
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { InfoIcon, DollarSign } from "lucide-react";
import { EarningsEstimate } from '@/types';

interface EarningsCalculatorProps {
  defaultMessageRate?: number;
  defaultCallRate?: number;
  className?: string;
}

const EarningsCalculator = ({ 
  defaultMessageRate = 0.99, 
  defaultCallRate = 4.99,
  className
}: EarningsCalculatorProps) => {
  const [estimate, setEstimate] = useState<EarningsEstimate>({
    messages: 50,
    messageRate: defaultMessageRate,
    calls: 10,
    callRate: defaultCallRate,
    tips: 5,
    averageTip: 5,
    nftGifts: 5,
    averageNftValue: 8,
    storeSales: 3,
    averageStoreValue: 20,
    referrals: 2,
    referralValue: 9
  });
  
  const [totalEarnings, setTotalEarnings] = useState(0);
  
  useEffect(() => {
    // Calculate total potential earnings
    const messageEarnings = estimate.messages * estimate.messageRate * 0.9; // 90% kept by creator
    const callEarnings = estimate.calls * (estimate.callRate * 10) * 0.9; // 10 min calls, 90% kept
    const tipEarnings = estimate.tips * estimate.averageTip * 0.9; // 90% kept
    const nftEarnings = estimate.nftGifts * estimate.averageNftValue * 0.85; // 85% kept
    const storeEarnings = estimate.storeSales * estimate.averageStoreValue; // 100% kept (minus Stripe)
    const referralEarnings = estimate.referrals * estimate.referralValue; // Full commission
    
    const total = messageEarnings + callEarnings + tipEarnings + nftEarnings + storeEarnings + referralEarnings;
    setTotalEarnings(total);
  }, [estimate]);
  
  const handleSliderChange = (field: keyof EarningsEstimate, value: number[]) => {
    setEstimate(prev => ({
      ...prev,
      [field]: value[0]
    }));
  };
  
  return (
    <TooltipProvider>
      <Card className={`bg-white/5 backdrop-blur-md border-white/10 ${className}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white">Earnings Calculator</CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <InfoIcon className="h-5 w-5 text-white/70 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <p>What could you earn?</p>
                <p className="text-xs text-muted-foreground mt-1">
                  This calculator shows how much you could make on Dormlit based on your activity.
                  Tip: You set your own prices for DMs, calls, stickers, and more.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription className="text-white/70">
            Estimate your potential monthly earnings based on your activity
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Messages */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white">Monthly Messages</Label>
                <span className="text-white/70 text-sm">{estimate.messages}</span>
              </div>
              <Slider 
                defaultValue={[estimate.messages]} 
                max={200}
                step={5}
                onValueChange={(value) => handleSliderChange('messages', value)}
                className="my-4"
              />
              <div className="text-white/70 text-sm">
                ≈ ${(estimate.messages * estimate.messageRate * 0.9).toFixed(2)} earned
              </div>
            </div>
            
            {/* Calls */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white">Monthly Calls (10min)</Label>
                <span className="text-white/70 text-sm">{estimate.calls}</span>
              </div>
              <Slider 
                defaultValue={[estimate.calls]} 
                max={50}
                step={1}
                onValueChange={(value) => handleSliderChange('calls', value)}
                className="my-4"
              />
              <div className="text-white/70 text-sm">
                ≈ ${(estimate.calls * (estimate.callRate * 10) * 0.9).toFixed(2)} earned
              </div>
            </div>
            
            {/* Tips */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white">Monthly Tips</Label>
                <span className="text-white/70 text-sm">{estimate.tips}</span>
              </div>
              <Slider 
                defaultValue={[estimate.tips]} 
                max={30}
                step={1}
                onValueChange={(value) => handleSliderChange('tips', value)}
                className="my-4"
              />
              <div className="text-white/70 text-sm">
                ≈ ${(estimate.tips * estimate.averageTip * 0.9).toFixed(2)} earned
              </div>
            </div>
            
            {/* NFT Gifts */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white">Monthly NFT Gifts</Label>
                <span className="text-white/70 text-sm">{estimate.nftGifts}</span>
              </div>
              <Slider 
                defaultValue={[estimate.nftGifts]} 
                max={30}
                step={1}
                onValueChange={(value) => handleSliderChange('nftGifts', value)}
                className="my-4"
              />
              <div className="text-white/70 text-sm">
                ≈ ${(estimate.nftGifts * estimate.averageNftValue * 0.85).toFixed(2)} earned
              </div>
            </div>
            
            {/* Store Sales */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white">Monthly Store Sales</Label>
                <span className="text-white/70 text-sm">{estimate.storeSales}</span>
              </div>
              <Slider 
                defaultValue={[estimate.storeSales]} 
                max={20}
                step={1}
                onValueChange={(value) => handleSliderChange('storeSales', value)}
                className="my-4"
              />
              <div className="text-white/70 text-sm">
                ≈ ${(estimate.storeSales * estimate.averageStoreValue).toFixed(2)} earned
              </div>
            </div>
            
            {/* Referrals */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <Label className="text-white">Monthly Pro Referrals</Label>
                <span className="text-white/70 text-sm">{estimate.referrals}</span>
              </div>
              <Slider 
                defaultValue={[estimate.referrals]} 
                max={10}
                step={1}
                onValueChange={(value) => handleSliderChange('referrals', value)}
                className="my-4"
              />
              <div className="text-white/70 text-sm">
                ≈ ${(estimate.referrals * estimate.referralValue).toFixed(2)} earned
              </div>
            </div>
          </div>
          
          <div className="mt-8 p-4 bg-primary/20 border border-primary/30 rounded-md flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-white">Estimated Monthly Earnings</h3>
              <p className="text-white/70 text-sm">Based on your interaction levels</p>
            </div>
            <div className="text-2xl font-bold text-primary flex items-center">
              <DollarSign className="h-5 w-5 mr-1" />
              {totalEarnings.toFixed(2)}
            </div>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default EarningsCalculator;
