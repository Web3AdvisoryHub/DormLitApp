
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { InfoIcon, MessageSquare, Phone, Heart, Sparkles, ShoppingBag, Users } from "lucide-react";
import { PaymentBreakdown } from '@/types';

interface EarningsBreakdownChartProps {
  className?: string;
}

const EarningsBreakdownChart = ({ className }: EarningsBreakdownChartProps) => {
  
  const earningsBreakdown: PaymentBreakdown[] = [
    {
      method: "Text Message",
      userPays: "$1 per message",
      creatorKeeps: "$0.90",
      notes: "Set your own pricing soon"
    },
    {
      method: "Video Call (10 min)",
      userPays: "$2.99+ per call",
      creatorKeeps: "$2.50–$2.70",
      notes: "You set your per-minute rate"
    },
    {
      method: "Public Tip",
      userPays: "Custom (e.g. $5)",
      creatorKeeps: "90% of amount",
      notes: "Optional public shoutout"
    },
    {
      method: "Private Tip",
      userPays: "Custom",
      creatorKeeps: "90% of amount",
      notes: "Anonymous option"
    },
    {
      method: "Sticker Gift (NFT)",
      userPays: "$3–$20",
      creatorKeeps: "80–90%",
      notes: "Depends on sticker tier"
    },
    {
      method: "Store Sale",
      userPays: "Creator sets price",
      creatorKeeps: "100% (minus Stripe fee)",
      notes: "Sell physical/digital goods"
    },
    {
      method: "Affiliate Referral",
      userPays: "30% (first 3 months of sub)",
      creatorKeeps: "You keep full revenue after that",
      notes: "Applies to Pro subs you refer"
    }
  ];
  
  // Helper function to get icon for each method
  const getMethodIcon = (method: string) => {
    switch (true) {
      case method.includes("Message"):
        return <MessageSquare className="h-5 w-5" />;
      case method.includes("Call"):
        return <Phone className="h-5 w-5" />;
      case method.includes("Tip"):
        return <Heart className="h-5 w-5" />;
      case method.includes("Sticker"):
        return <Sparkles className="h-5 w-5" />;
      case method.includes("Store"):
        return <ShoppingBag className="h-5 w-5" />;
      case method.includes("Affiliate"):
        return <Users className="h-5 w-5" />;
      default:
        return <InfoIcon className="h-5 w-5" />;
    }
  };
  
  return (
    <TooltipProvider>
      <Card className={`bg-white/5 backdrop-blur-md border-white/10 ${className}`}>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl text-white">Creator Earnings Breakdown</CardTitle>
            <Tooltip>
              <TooltipTrigger asChild>
                <InfoIcon className="h-5 w-5 text-white/70 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-sm">
                <p>Real Money Moves</p>
                <p className="text-xs text-muted-foreground mt-1">
                  This chart shows how much you keep after platform fees.
                  You're in control of your prices and payout flow.
                </p>
              </TooltipContent>
            </Tooltip>
          </div>
          <CardDescription className="text-white/70">
            See exactly what you earn from each monetization method
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr className="bg-white/10">
                  <th className="p-4 text-left text-white font-medium rounded-tl-md">Monetization Method</th>
                  <th className="p-4 text-left text-white font-medium">User Pays</th>
                  <th className="p-4 text-left text-white font-medium">Creator Keeps</th>
                  <th className="p-4 text-left text-white font-medium rounded-tr-md">Notes</th>
                </tr>
              </thead>
              <tbody>
                {earningsBreakdown.map((item, index) => (
                  <tr 
                    key={index} 
                    className={`border-b border-white/10 ${index % 2 === 0 ? 'bg-white/5' : ''}`}
                  >
                    <td className="p-4 text-white">
                      <div className="flex items-center gap-2">
                        <div className="bg-fan-purple/20 p-1.5 rounded-full">
                          {getMethodIcon(item.method)}
                        </div>
                        <span>{item.method}</span>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <InfoIcon className="h-4 w-4 text-white/50 cursor-help ml-1" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p className="text-xs">
                              {item.notes}
                            </p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </td>
                    <td className="p-4 text-white">{item.userPays}</td>
                    <td className="p-4 text-white font-medium text-green-400">{item.creatorKeeps}</td>
                    <td className="p-4 text-white/70">{item.notes}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-8 p-6 bg-fan-purple/10 rounded-md border border-fan-purple/20">
            <h3 className="text-lg font-semibold text-white mb-2">Example Monthly Earnings (Light Engagement)</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              <div className="text-white">
                <div className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4 text-fan-purple" />
                  <span>50 messages: $45</span>
                </div>
              </div>
              <div className="text-white">
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-fan-purple" />
                  <span>10 calls: $27</span>
                </div>
              </div>
              <div className="text-white">
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4 text-fan-purple" />
                  <span>5 tips: $25</span>
                </div>
              </div>
              <div className="text-white">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-fan-purple" />
                  <span>5 NFT gifts: $40</span>
                </div>
              </div>
              <div className="text-white">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="h-4 w-4 text-fan-purple" />
                  <span>3 store sales: $60</span>
                </div>
              </div>
              <div className="text-white">
                <div className="flex items-center gap-2">
                  <Users className="h-4 w-4 text-fan-purple" />
                  <span>2 Pro referrals: $18</span>
                </div>
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-white/10 flex justify-between items-center">
              <span className="text-white">Total monthly potential:</span>
              <span className="text-xl font-bold text-fan-purple">$195</span>
            </div>
            <div className="mt-2 text-white/50 text-sm">
              Not including higher-tier content or upsells.
            </div>
          </div>
        </CardContent>
      </Card>
    </TooltipProvider>
  );
};

export default EarningsBreakdownChart;
