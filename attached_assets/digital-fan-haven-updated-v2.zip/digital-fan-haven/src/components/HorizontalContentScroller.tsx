
import React, { useRef } from 'react';
import { ChevronLeft, ChevronRight, Youtube, Twitter, Instagram, Play } from 'lucide-react';
import { Button } from '@/components/ui/button';

export interface ContentItem {
  id: string;
  title: string;
  imageUrl: string;
  link: string;
  socialPlatform?: string;
}

interface HorizontalContentScrollerProps {
  items: ContentItem[];
}

const HorizontalContentScroller: React.FC<HorizontalContentScrollerProps> = ({ items }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollLeft = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: -300, behavior: 'smooth' });
    }
  };

  const scrollRight = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({ left: 300, behavior: 'smooth' });
    }
  };

  // Function to get platform icon
  const getPlatformIcon = (platform?: string) => {
    switch (platform?.toLowerCase()) {
      case 'youtube':
        return <Youtube className="h-5 w-5 text-red-500" />;
      case 'twitter':
        return <Twitter className="h-5 w-5 text-blue-400" />;
      case 'instagram':
        return <Instagram className="h-5 w-5 text-pink-500" />;
      default:
        return <Play className="h-5 w-5 text-white" />;
    }
  };

  return (
    <div className="relative bg-white/5 backdrop-blur-md rounded-xl p-4 border border-white/10">
      {/* Navigation buttons */}
      <div className="absolute top-1/2 left-2 z-10 transform -translate-y-1/2">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-black/50 hover:bg-black/70 text-white"
          onClick={scrollLeft}
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
      </div>
      
      <div className="absolute top-1/2 right-2 z-10 transform -translate-y-1/2">
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full bg-black/50 hover:bg-black/70 text-white"
          onClick={scrollRight}
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>
      
      {/* Scrollable content */}
      <div
        ref={scrollRef}
        className="flex overflow-x-auto gap-4 py-2 hide-scrollbar"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {items.map((item) => (
          <a
            key={item.id}
            href={item.link}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 w-64 group"
          >
            <div className="relative overflow-hidden rounded-lg">
              <div className="aspect-video bg-black/30 relative">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                
                {/* Play overlay */}
                <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="h-12 w-12 rounded-full bg-fan-purple flex items-center justify-center">
                    <Play className="h-6 w-6 text-white" fill="white" />
                  </div>
                </div>
              </div>
              
              <div className="p-3 bg-black/60">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-white line-clamp-1">{item.title}</h3>
                  {item.socialPlatform && (
                    <span className="flex-shrink-0">{getPlatformIcon(item.socialPlatform)}</span>
                  )}
                </div>
              </div>
            </div>
          </a>
        ))}
      </div>
      
      {/* Hidden scrollbar styles */}
      <style>
        {`
          .hide-scrollbar::-webkit-scrollbar {
            display: none;
          }
        `}
      </style>
    </div>
  );
};

export default HorizontalContentScroller;
