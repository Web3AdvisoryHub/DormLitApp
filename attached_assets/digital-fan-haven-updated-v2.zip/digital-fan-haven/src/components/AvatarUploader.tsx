
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { PencilIcon, Upload, Camera, CircleUserRound } from 'lucide-react';

interface AvatarUploaderProps {
  onAvatarChange: (src: string, isRiggable: boolean) => void;
  currentAvatar: string;
  currentRiggable?: boolean;
}

const AvatarUploader: React.FC<AvatarUploaderProps> = ({ 
  onAvatarChange, 
  currentAvatar,
  currentRiggable = false
}) => {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [isRiggable, setIsRiggable] = useState(currentRiggable);
  const [selectedTab, setSelectedTab] = useState<string>("upload");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>(currentAvatar);
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Check file size (limit to 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select an image under 5MB",
          variant: "destructive",
        });
        return;
      }
      
      // Check file type
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: "Please select an image file",
          variant: "destructive",
        });
        return;
      }
      
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };
  
  const handleSave = () => {
    // For now, just use the preview URL
    // In a real app, you would upload this to a server
    onAvatarChange(previewUrl, isRiggable);
    setIsOpen(false);
    
    toast({
      title: "Avatar Updated",
      description: isRiggable ? "Your riggable avatar has been updated." : "Your avatar has been updated.",
    });
  };
  
  const handleCancel = () => {
    // Reset to current avatar if canceled
    setPreviewUrl(currentAvatar);
    setSelectedFile(null);
    setIsRiggable(currentRiggable);
    setIsOpen(false);
  };
  
  // Sample avatar options - in a real app these would come from an API
  const avatarOptions = [
    '/placeholder.svg',
    '/placeholder.svg',
    '/placeholder.svg',
    '/placeholder.svg',
    '/placeholder.svg',
    '/placeholder.svg',
  ];

  return (
    <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 hover:opacity-100 transition-opacity rounded-full">
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" size="icon" className="text-white hover:bg-black/60">
            <PencilIcon className="h-5 w-5" />
          </Button>
        </DialogTrigger>
        <DialogContent className="bg-fan-background text-white border-fan-purple/30 max-w-md">
          <DialogHeader>
            <DialogTitle>Update Your Avatar</DialogTitle>
          </DialogHeader>
          
          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
            <TabsList className="grid grid-cols-3 bg-secondary/40">
              <TabsTrigger value="upload" className="data-[state=active]:bg-fan-purple">
                <Upload className="h-4 w-4 mr-2" />
                Upload
              </TabsTrigger>
              <TabsTrigger value="camera" className="data-[state=active]:bg-fan-purple">
                <Camera className="h-4 w-4 mr-2" />
                Camera
              </TabsTrigger>
              <TabsTrigger value="preset" className="data-[state=active]:bg-fan-purple">
                <CircleUserRound className="h-4 w-4 mr-2" />
                Presets
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="upload" className="space-y-4 pt-4">
              <div className="flex flex-col items-center gap-4">
                <div className="w-32 h-32 rounded-full overflow-hidden border-2 border-fan-purple relative">
                  <img 
                    src={previewUrl} 
                    alt="Avatar Preview" 
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="w-full">
                  <Label htmlFor="avatar-upload" className="block mb-2 text-sm">
                    Select an image (JPG, PNG, or GIF, max 5MB)
                  </Label>
                  <div className="relative">
                    <input
                      id="avatar-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="absolute inset-0 opacity-0 cursor-pointer z-10"
                    />
                    <div className="bg-secondary/40 border border-fan-purple/20 rounded-md py-2 px-4 text-center text-sm text-white/70">
                      Click to browse or drag an image
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="camera" className="space-y-4 pt-4">
              <div className="flex flex-col items-center justify-center gap-4">
                <div className="w-full aspect-square max-w-xs bg-black rounded-md flex items-center justify-center">
                  <p className="text-white/50">Camera functionality would go here</p>
                </div>
                <Button 
                  variant="outline" 
                  className="border-fan-purple/30"
                >
                  <Camera className="mr-2 h-4 w-4" />
                  Take Photo
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="preset" className="space-y-4 pt-4">
              <div className="grid grid-cols-3 gap-4">
                {avatarOptions.map((avatarSrc, index) => (
                  <div 
                    key={index}
                    className={`aspect-square rounded-full overflow-hidden border-2 cursor-pointer transition-all ${
                      previewUrl === avatarSrc 
                        ? 'border-fan-purple ring-2 ring-fan-purple/50' 
                        : 'border-white/20 hover:border-fan-purple/50'
                    }`}
                    onClick={() => setPreviewUrl(avatarSrc)}
                  >
                    <img 
                      src={avatarSrc} 
                      alt={`Avatar option ${index + 1}`} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
          
          <div className="flex items-center space-x-2 mb-4">
            <Switch
              id="riggable"
              checked={isRiggable}
              onCheckedChange={setIsRiggable}
            />
            <Label htmlFor="riggable">Make avatar riggable for animation</Label>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={handleCancel}
              className="border-fan-purple/30"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="bg-fan-purple hover:bg-fan-purple/80"
              disabled={!previewUrl}
            >
              Save Avatar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AvatarUploader;
