
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Home, Compass, User, MessageSquare, Settings, Menu, Image,
  Phone, Edit, PenSquare, Calendar, HelpCircle, LogOut
} from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface NavigationProps {
  isAuthenticated?: boolean;
  avatarSrc?: string;
  username?: string;
}

const Navigation = ({ isAuthenticated = false, avatarSrc = '/placeholder.svg', username = 'User' }: NavigationProps) => {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  const navItems = [
    { icon: Home, label: 'Home', path: '/explore' },
    { icon: Compass, label: 'Explore', path: '/explore' },
    { icon: User, label: 'Profile', path: '/profile' },
    { icon: MessageSquare, label: 'Messages', path: '/messages' },
    { icon: Settings, label: 'Settings', path: '/settings' }
  ];

  const profileMenuItems = [
    { icon: MessageSquare, label: 'Inbox', path: '/messages' },
    { icon: Phone, label: 'Call Log', path: '/calls' },
    { icon: PenSquare, label: 'Edit Bio', path: '/profile/edit' },
    { icon: Image, label: 'Update Avatar', path: '/profile/avatar' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === path;
    }
    return location.pathname.startsWith(path);
  };

  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-gray-950 border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <span className="text-xl font-bold text-primary">Dormlit</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => (
              <Link 
                key={item.label} 
                to={item.path}
                className={`flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors
                  ${isActive(item.path) 
                    ? 'bg-primary/10 text-primary' 
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                  }`}
              >
                <item.icon className="h-5 w-5 mr-1" />
                <span>{item.label}</span>
              </Link>
            ))}
          </div>

          {/* Auth/Avatar */}
          <div className="flex items-center">
            {isAuthenticated ? (
              <div className="flex items-center">
                <Link to="/profile">
                  <Avatar className="h-8 w-8 cursor-pointer">
                    <AvatarImage src={avatarSrc} alt={username} />
                    <AvatarFallback>{username.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Link>
              </div>
            ) : (
              <div className="hidden md:flex items-center space-x-2">
                <Link to="/login">
                  <Button variant="ghost" size="sm">Log in</Button>
                </Link>
                <Link to="/signup">
                  <Button size="sm">Sign up</Button>
                </Link>
              </div>
            )}

            {/* Mobile Menu Button */}
            <div className="md:hidden ml-4">
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="h-6 w-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-[80%] sm:w-[350px]">
                  <div className="flex flex-col h-full py-6">
                    {!isAuthenticated && (
                      <div className="flex flex-col space-y-2 mb-6">
                        <Link to="/login" onClick={() => setMobileMenuOpen(false)}>
                          <Button variant="outline" className="w-full">Log in</Button>
                        </Link>
                        <Link to="/signup" onClick={() => setMobileMenuOpen(false)}>
                          <Button className="w-full">Sign up</Button>
                        </Link>
                      </div>
                    )}
                    
                    <div className="flex flex-col space-y-1">
                      {navItems.map((item) => (
                        <Link 
                          key={item.label} 
                          to={item.path}
                          onClick={() => setMobileMenuOpen(false)}
                          className={`flex items-center px-4 py-3 rounded-md text-sm font-medium transition-colors
                            ${isActive(item.path) 
                              ? 'bg-primary/10 text-primary' 
                              : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                            }`}
                        >
                          <item.icon className="h-5 w-5 mr-3" />
                          <span>{item.label}</span>
                        </Link>
                      ))}
                    </div>
                    
                    {/* Profile Submenu - Only shown when authenticated */}
                    {isAuthenticated && (
                      <div className="mt-6 border-t pt-6">
                        <h3 className="px-4 text-sm font-semibold mb-2 text-gray-500 dark:text-gray-400">Profile Options</h3>
                        <div className="flex flex-col space-y-1">
                          {profileMenuItems.map((item) => (
                            <Link
                              key={item.label}
                              to={item.path}
                              onClick={() => setMobileMenuOpen(false)}
                              className="flex items-center px-4 py-3 rounded-md text-sm font-medium transition-colors text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
                            >
                              <item.icon className="h-4 w-4 mr-3" />
                              <span>{item.label}</span>
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {isAuthenticated && (
                      <div className="mt-auto pt-6 border-t">
                        <div className="flex items-center px-4 py-2">
                          <Avatar className="h-10 w-10 mr-3">
                            <AvatarImage src={avatarSrc} alt={username} />
                            <AvatarFallback>{username.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="text-sm font-medium">{username}</p>
                            <Button 
                              variant="link" 
                              className="p-0 h-auto text-xs text-gray-500 dark:text-gray-400"
                              onClick={() => {
                                // Handle logout here
                                setMobileMenuOpen(false);
                              }}
                            >
                              Log out
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navigation;
