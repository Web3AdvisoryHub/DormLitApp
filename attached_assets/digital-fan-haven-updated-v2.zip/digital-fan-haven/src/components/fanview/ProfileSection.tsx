
import React, { useState } from 'react';
import CreatorProfile from '../CreatorProfile';
import VerticalSocialLinks from '../VerticalSocialLinks';
import ConnectOptions from '../ConnectOptions';
import PaymentModal from '../payments/PaymentModal';

interface ProfileSectionProps {
  creatorData: any;
  isAuthenticated: boolean;
  onSendMessage: (message: string, isPublic: boolean) => Promise<void>;
  onScheduleCall: (duration: number) => Promise<void>;
  onSendTip: (amount: number, isPublic: boolean) => Promise<void>;
  onSendSticker: (stickerId: string, isPublic: boolean) => Promise<void>;
  promptSignup: () => void;
}

const ProfileSection: React.FC<ProfileSectionProps> = ({
  creatorData,
  isAuthenticated,
  onSendMessage,
  onScheduleCall,
  onSendTip,
  onSendSticker,
  promptSignup
}) => {
  const [isConnectModalOpen, setIsConnectModalOpen] = useState(false);
  const [activeConnectionOption, setActiveConnectionOption] = useState<'text' | 'call' | 'tip' | 'sticker' | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  const handleConnectRequest = (type: 'text' | 'call' | 'tip' | 'sticker') => {
    if (!isAuthenticated) {
      promptSignup();
      return;
    }
    setActiveConnectionOption(type);
    setIsConnectModalOpen(true);
  };
  
  const handleSendMessageWithAuth = async (message: string, isPublic: boolean) => {
    try {
      setIsProcessing(true);
      await onSendMessage(message, isPublic);
      setIsConnectModalOpen(false);
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleScheduleCallWithAuth = async (duration: number) => {
    try {
      setIsProcessing(true);
      await onScheduleCall(duration);
      setIsConnectModalOpen(false);
    } catch (error) {
      console.error('Error scheduling call:', error);
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleSendTipWithAuth = async (amount: number, isPublic: boolean) => {
    try {
      setIsProcessing(true);
      await onSendTip(amount, isPublic);
      setIsConnectModalOpen(false);
    } catch (error) {
      console.error('Error sending tip:', error);
    } finally {
      setIsProcessing(false);
    }
  };
  
  const handleSendStickerWithAuth = async (stickerId: string, isPublic: boolean) => {
    try {
      setIsProcessing(true);
      await onSendSticker(stickerId, isPublic);
      setIsConnectModalOpen(false);
    } catch (error) {
      console.error('Error sending sticker:', error);
    } finally {
      setIsProcessing(false);
    }
  };
  
  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Left side - Avatar and links */}
        <div className="md:col-span-1">
          <div className="flex flex-col items-center">
            <div className="mb-6">
              <img 
                src={creatorData.avatarSrc} 
                alt={creatorData.displayName}
                className="w-48 h-auto rounded-lg"
              />
            </div>
            <VerticalSocialLinks socialLinks={creatorData.socialLinks} />
          </div>
        </div>
        
        {/* Right side - Profile info and action buttons */}
        <div className="md:col-span-3">
          <CreatorProfile 
            name={creatorData.displayName}
            avatarSrc={creatorData.avatarSrc}
            bio={creatorData.bio}
            socialLinks={creatorData.socialLinks}
            messageRate={creatorData.messageRate}
            callRate={creatorData.callRate}
            isCurrentUser={false}
            onSendMessage={onSendMessage}
            onScheduleCall={onScheduleCall}
            onSendTip={onSendTip}
            onSendSticker={onSendSticker}
            hideButtons={false}
            isFanView={true}
          >
            <ConnectOptions 
              creatorName={creatorData.displayName}
              onTextRequest={() => handleConnectRequest('text')}
              onCallRequest={() => handleConnectRequest('call')}
              onTipRequest={() => handleConnectRequest('tip')}
              onStickerRequest={() => handleConnectRequest('sticker')}
            />
          </CreatorProfile>
        </div>
      </div>
      
      <PaymentModal
        isOpen={isConnectModalOpen}
        onOpenChange={setIsConnectModalOpen}
        creatorName={creatorData.displayName}
        activeOption={activeConnectionOption}
        onSelectOption={setActiveConnectionOption}
        messageRate={creatorData.messageRate}
        callRate={creatorData.callRate}
        walletConnected={false}
        onConnectWallet={() => {}} // Would be implemented in a real app
        onSendMessage={handleSendMessageWithAuth}
        onScheduleCall={handleScheduleCallWithAuth}
        onSendTip={handleSendTipWithAuth}
        onSendSticker={handleSendStickerWithAuth}
        isProcessing={isProcessing}
      />
    </>
  );
};

export default ProfileSection;
