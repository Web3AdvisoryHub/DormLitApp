
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DollarSign, MessageSquare, Gift } from "lucide-react";

interface WallInteraction {
  id: string;
  type: 'message' | 'tip' | 'sticker';
  username: string;
  userAvatar: string;
  content: string;
  amount?: number;
  imageUrl?: string;
  timestamp: Date;
}

interface MutualRespectWallProps {
  interactions: WallInteraction[];
}

const MutualRespectWall: React.FC<MutualRespectWallProps> = ({
  interactions
}) => {
  if (interactions.length === 0) {
    return (
      <Card className="bg-white/5 backdrop-blur-md border-white/10 p-6">
        <p className="text-white/70 text-center">No interactions yet. Be the first to show some love!</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {interactions.map((interaction) => (
        <Card 
          key={interaction.id}
          className="bg-white/5 backdrop-blur-md border-white/10 overflow-hidden"
        >
          <CardContent className="p-4">
            <div className="flex gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={interaction.userAvatar} alt={interaction.username} />
                <AvatarFallback>{interaction.username[0]}</AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-white">{interaction.username}</span>
                  {interaction.type === 'tip' && (
                    <div className="flex items-center text-green-400 text-sm">
                      <DollarSign className="h-3 w-3 mr-1" />
                      <span>${interaction.amount?.toFixed(2)}</span>
                    </div>
                  )}
                  <span className="text-xs text-white/40">
                    {new Date(interaction.timestamp).toLocaleString()}
                  </span>
                </div>
                
                <div className="mt-1">
                  {interaction.type === 'message' && (
                    <div className="flex items-start gap-2">
                      <MessageSquare className="h-4 w-4 text-fan-purple mt-0.5" />
                      <p className="text-white/80">{interaction.content}</p>
                    </div>
                  )}
                  
                  {interaction.type === 'tip' && (
                    <div className="flex items-start gap-2">
                      <DollarSign className="h-4 w-4 text-green-400 mt-0.5" />
                      <p className="text-white/80">{interaction.content}</p>
                    </div>
                  )}
                  
                  {interaction.type === 'sticker' && (
                    <div className="flex flex-col items-center gap-2">
                      <Gift className="h-4 w-4 text-fan-purple" />
                      {interaction.imageUrl && (
                        <div className="mt-2 bg-white/10 p-2 rounded w-24 h-24 mx-auto">
                          <img 
                            src={interaction.imageUrl} 
                            alt="Sticker" 
                            className="w-full h-full object-contain"
                          />
                        </div>
                      )}
                      {interaction.content && (
                        <p className="text-white/80 text-sm mt-1">{interaction.content}</p>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default MutualRespectWall;
