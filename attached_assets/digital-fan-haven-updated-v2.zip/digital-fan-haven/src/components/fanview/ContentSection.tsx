
import React from 'react';
import { ContentSectionType } from '@/types';
import { Button } from '@/components/ui/button';
import CreatorRoom from '@/components/CreatorRoom';
import MutualRespectWall from './MutualRespectWall';
import SimulationRoomSystem from '@/components/simulation/SimulationRoomSystem';
import EarningsSection from '@/components/earnings/EarningsSection';

interface ContentSectionProps {
  sectionId: ContentSectionType;
  creatorData: any;
  handleJoinAffiliate: () => void;
  handleEnterRoom: () => void;
}

const ContentSection: React.FC<ContentSectionProps> = ({
  sectionId,
  creatorData,
  handleJoinAffiliate,
  handleEnterRoom
}) => {
  // Render different content based on the section type
  switch(sectionId) {
    case 'featured':
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {creatorData.featuredContent.map((item: any) => (
            <div key={item.id} className="bg-secondary/10 rounded-lg overflow-hidden">
              <img 
                src={item.imageUrl} 
                alt={item.title} 
                className="w-full aspect-video object-cover"
              />
              <div className="p-3">
                <h3 className="font-medium text-white">{item.title}</h3>
                {item.socialPlatform && (
                  <span className="text-sm text-white/60">{item.socialPlatform}</span>
                )}
              </div>
            </div>
          ))}
        </div>
      );
      
    case 'links':
      return (
        <div className="flex flex-wrap gap-3">
          {creatorData.creatorLinks.map((link: any) => (
            <a 
              key={link.id}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-secondary/10 hover:bg-secondary/20 px-4 py-2 rounded-md text-white"
            >
              {link.title}
            </a>
          ))}
        </div>
      );
      
    case 'store':
      return (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {creatorData.storeItems.map((item: any) => (
            <div key={item.id} className="bg-secondary/10 rounded-lg overflow-hidden">
              <img 
                src={item.image} 
                alt={item.name} 
                className="w-full aspect-video object-cover"
              />
              <div className="p-3">
                <div className="flex justify-between items-start">
                  <h3 className="font-medium text-white">{item.name}</h3>
                  <span className="bg-fan-purple px-2 py-0.5 rounded text-white text-sm">
                    ${item.price.toFixed(2)}
                  </span>
                </div>
                <p className="text-sm text-white/60 mt-1 line-clamp-2">{item.description}</p>
                {item.isNFT && (
                  <div className="mt-2">
                    <span className="bg-secondary/30 text-white/80 text-xs px-2 py-0.5 rounded">
                      NFT
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      );
      
    case 'wall':
      return (
        <MutualRespectWall interactions={creatorData.fanInteractions} />
      );
      
    case 'affiliate':
      return (
        <div className="bg-secondary/10 p-6 rounded-lg text-center">
          <h3 className="text-xl font-semibold text-white mb-2">Join the Dormlit Community</h3>
          <p className="text-white/70 mb-4">
            Join {creatorData.displayName}'s community and earn rewards when you refer friends.
          </p>
          <Button
            className="bg-fan-purple hover:bg-fan-purple/80"
            onClick={handleJoinAffiliate}
          >
            Join Dormlit.Grow
          </Button>
        </div>
      );
      
    case 'room':
      return (
        <div className="space-y-6">
          <CreatorRoom
            isPublic={creatorData.roomState.isPublic}
            visitors={creatorData.fanInteractions.length}
            roomName={`${creatorData.displayName}'s Room`}
            roomPreviewImage={creatorData.roomState.background}
            onEnterRoom={handleEnterRoom}
            isPremium={false}
          />
          
          <SimulationRoomSystem
            creatorId={creatorData.id}
            isUserLoggedIn={true}
            isUserPremium={false}
            onEnterRoom={handleEnterRoom}
          />
        </div>
      );
    
    case 'earnings':
      // Only show if the earnings data exists and it's the creator's own profile
      if (creatorData.earnings && creatorData.isOwnProfile) {
        return (
          <EarningsSection
            earnings={creatorData.earnings}
            recentTransactions={creatorData.recentTransactions || []}
            onRequestPayout={async () => {
              // This would call an API endpoint to request a payout
              await new Promise(resolve => setTimeout(resolve, 1500));
              return Promise.resolve();
            }}
            isWalletConnected={creatorData.walletConnected || false}
            onConnectWallet={() => {
              // This would trigger wallet connection
              console.log('Connect wallet');
            }}
            isPayoutAvailable={
              (creatorData.earnings.availableForPayout || 0) >= (creatorData.minimumPayout || 25)
            }
            minimumPayout={creatorData.minimumPayout || 25}
          />
        );
      }
      return null;
      
    default:
      return <div>Content not available</div>;
  }
};

export default ContentSection;
