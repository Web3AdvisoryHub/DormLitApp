
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";

const FooterSection = () => {
  return (
    <footer className="py-16 px-4 bg-black/40">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and description */}
          <div className="md:col-span-1">
            <h2 className="text-2xl font-bold text-white mb-4">Dormlit</h2>
            <p className="text-white/70 mb-4">
              The ultimate platform for creators to connect with fans and monetize their content.
            </p>
          </div>
          
          {/* Quick links */}
          <div>
            <h3 className="text-lg font-medium text-white mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-white/70 hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/explore" className="text-white/70 hover:text-white transition-colors">Explore</Link></li>
              <li><Link to="/login" className="text-white/70 hover:text-white transition-colors">Login</Link></li>
              <li><Link to="/signup" className="text-white/70 hover:text-white transition-colors">Sign Up</Link></li>
            </ul>
          </div>
          
          {/* Help & Support */}
          <div>
            <h3 className="text-lg font-medium text-white mb-4">Help & Support</h3>
            <ul className="space-y-2">
              <li><Link to="/help" className="text-white/70 hover:text-white transition-colors">Help Center</Link></li>
              <li><Link to="/contact" className="text-white/70 hover:text-white transition-colors">Contact Us</Link></li>
              <li><Link to="/terms" className="text-white/70 hover:text-white transition-colors">Terms of Service</Link></li>
              <li><Link to="/privacy" className="text-white/70 hover:text-white transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>
          
          {/* Call to action */}
          <div>
            <h3 className="text-lg font-medium text-white mb-4">Ready to Start?</h3>
            <p className="text-white/70 mb-4">
              Create your creator profile today and start connecting with fans.
            </p>
            <Link to="/signup">
              <Button className="w-full bg-fan-purple hover:bg-fan-purple/80">
                Create Profile
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col md:flex-row justify-between items-center">
          <p className="text-white/60 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} Dormlit. All rights reserved.
          </p>
          <div className="flex gap-4">
            <a href="#" className="text-white/60 hover:text-white transition-colors">
              Instagram
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors">
              Twitter
            </a>
            <a href="#" className="text-white/60 hover:text-white transition-colors">
              Discord
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FooterSection;
