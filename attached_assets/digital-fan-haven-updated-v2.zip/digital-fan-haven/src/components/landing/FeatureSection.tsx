
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { MessageSquare, PhoneCall, ShoppingBag, Users, Gift, Ticket } from 'lucide-react';

const features = [
  {
    icon: <MessageSquare className="h-8 w-8 text-fan-purple" />,
    title: "Direct Messaging",
    description: "Connect with fans through private messages and earn with every interaction."
  },
  {
    icon: <PhoneCall className="h-8 w-8 text-fan-purple" />,
    title: "Creator Calls",
    description: "Schedule and host paid video calls with your biggest supporters."
  },
  {
    icon: <ShoppingBag className="h-8 w-8 text-fan-purple" />,
    title: "Digital Store",
    description: "Sell digital goods, NFTs, and physical merchandise directly to fans."
  },
  {
    icon: <Users className="h-8 w-8 text-fan-purple" />,
    title: "Fan Communities",
    description: "Build your own community with interactive spaces and exclusive content."
  },
  {
    icon: <Gift className="h-8 w-8 text-fan-purple" />,
    title: "Fan Gifts & Tips",
    description: "Receive tips, gifts, and support from your dedicated audience."
  },
  {
    icon: <Ticket className="h-8 w-8 text-fan-purple" />,
    title: "Dormlit.Grow",
    description: "Join our affiliate program and earn by growing the creator community."
  }
];

const FeatureSection = () => {
  return (
    <section className="py-20 px-4 bg-black/30">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">
          Everything You Need to <span className="text-fan-purple">Connect & Earn</span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="bg-white/5 backdrop-blur-sm border-white/10 overflow-hidden hover:bg-white/10 transition-colors">
              <CardContent className="p-6">
                <div className="mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold mb-2 text-white">{feature.title}</h3>
                <p className="text-white/70">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeatureSection;
