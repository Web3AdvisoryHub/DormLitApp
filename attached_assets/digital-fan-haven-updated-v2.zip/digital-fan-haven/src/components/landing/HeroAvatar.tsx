
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const HeroAvatar = () => {
  return (
    <div className="relative">
      {/* Main avatar with animation */}
      <div className="animate-float">
        <Avatar className="w-64 h-64 border-4 border-fan-purple/50">
          <AvatarImage src="/placeholder.svg" alt="Creator Avatar" />
          <AvatarFallback className="bg-fan-purple/20">CD</AvatarFallback>
        </Avatar>
      </div>
      
      {/* Floating elements around avatar */}
      <div className="absolute -top-4 -right-4 animate-float-delay-1">
        <div className="bg-pink-500/80 text-white p-2 rounded-full w-12 h-12 flex items-center justify-center">
          💰
        </div>
      </div>
      <div className="absolute -bottom-2 -left-2 animate-float-delay-2">
        <div className="bg-blue-500/80 text-white p-2 rounded-full w-10 h-10 flex items-center justify-center">
          💬
        </div>
      </div>
      <div className="absolute top-1/4 -right-8 animate-float-delay-3">
        <div className="bg-green-500/80 text-white p-2 rounded-full w-8 h-8 flex items-center justify-center">
          🎮
        </div>
      </div>
    </div>
  );
};

export default HeroAvatar;
