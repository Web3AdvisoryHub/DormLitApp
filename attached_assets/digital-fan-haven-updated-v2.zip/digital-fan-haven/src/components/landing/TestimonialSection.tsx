
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: "Alex Chen",
    role: "Digital Artist",
    content: "Dormlit has completely transformed how I connect with my audience. The direct messaging and call features have created deeper relationships with my fans.",
    avatar: "/placeholder.svg",
    rating: 5
  },
  {
    name: "Maya Johnson",
    role: "Content Creator",
    content: "I've tried many creator platforms, but Dormlit's room system and monetization tools are unmatched. My earnings have increased by 40% since joining!",
    avatar: "/placeholder.svg",
    rating: 5
  },
  {
    name: "Jason Williams",
    role: "Gaming Streamer",
    content: "The affiliate program is a game-changer. I'm not only earning from my content but also from bringing other creators to the platform.",
    avatar: "/placeholder.svg",
    rating: 4
  }
];

const TestimonialSection = () => {
  return (
    <section className="py-20 px-4">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-4">
          Creators Love <span className="text-fan-purple">Dormlit</span>
        </h2>
        <p className="text-center text-white/70 mb-12 max-w-2xl mx-auto">
          Join thousands of creative professionals who are building their digital presence and income with Dormlit.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white/5 backdrop-blur-sm border-white/10 overflow-hidden">
              <CardContent className="p-6">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-400'}`} 
                    />
                  ))}
                </div>
                <p className="text-white/90 mb-6">"{testimonial.content}"</p>
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={testimonial.avatar} alt={testimonial.name} />
                    <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-white">{testimonial.name}</p>
                    <p className="text-sm text-white/70">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;
