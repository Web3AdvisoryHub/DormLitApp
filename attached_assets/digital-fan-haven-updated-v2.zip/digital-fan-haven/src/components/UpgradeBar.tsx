import React from 'react';
import { Button } from "@/components/ui/button";
import { ChevronRight, Star } from "lucide-react";

interface UpgradeBarProps {
  currentPlan: 'free' | 'premium' | 'pro';
  onUpgrade: () => void;
  className?: string;
}

const UpgradeBar: React.FC<UpgradeBarProps> = ({ 
  currentPlan, 
  onUpgrade,
  className
}) => {
  if (currentPlan === 'pro') return null;
  
  const getUpgradeText = () => {
    switch(currentPlan) {
      case 'free':
        return {
          title: 'Want layout control & storefront?',
          description: 'Upgrade to Premium for store access, customizable layout, and monetization features.'
        };
      case 'premium':
        return {
          title: 'Want unlimited items & affiliate options?',
          description: 'Upgrade to Pro for unlimited store items, affiliates program, and advanced customization.'
        };
      default:
        return {
          title: 'Upgrade your account',
          description: 'Get access to more features'
        };
    }
  };
  
  const upgradeInfo = getUpgradeText();
  const nextPlan = currentPlan === 'free' ? 'Premium' : 'Pro';
  
  return (
    <div className={`bg-fan-purple/10 border border-fan-purple/20 p-4 rounded-lg ${className}`}>
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-medium text-white">{upgradeInfo.title}</h4>
          <p className="text-xs text-white/70 mt-1">{upgradeInfo.description}</p>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="bg-fan-purple/20 hover:bg-fan-purple/30 text-white"
          onClick={onUpgrade}
        >
          <Star className="h-3.5 w-3.5 mr-1 text-fan-purple" />
          Try {nextPlan}
          <ChevronRight className="h-3.5 w-3.5 ml-1" />
        </Button>
      </div>
    </div>
  );
};

export default UpgradeBar;
