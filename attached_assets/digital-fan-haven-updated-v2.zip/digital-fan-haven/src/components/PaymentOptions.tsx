
import React, { useState, useRef, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { PhoneCall, MessageSquare, Heart, Wallet, CreditCard, Gift, DollarSign } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

type ConnectionOption = {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  action?: () => void;
};

type PaymentOptionsProps = {
  callRate: number;
  textRate: number;
  hasEarnings?: boolean;
  isCreator?: boolean;
  onCallRequest?: () => void;
  onTextRequest?: () => void;
  onSendMessage?: (message: string, isPublic: boolean) => Promise<void>;
  onScheduleCall?: (duration: number) => Promise<void>;
  onSendTip?: (amount: number, isPublic: boolean) => Promise<void>;
  onSendSticker?: (stickerId: string, isPublic: boolean) => Promise<void>;
  isOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  activeOption?: 'text' | 'call' | 'tip' | 'sticker' | null;
  onSelectOption?: (option: 'text' | 'call' | 'tip' | 'sticker' | null) => void;
};

const PaymentOptions = ({ 
  callRate, 
  textRate, 
  hasEarnings = false, 
  isCreator = false,
  onCallRequest,
  onTextRequest,
  onSendMessage,
  onScheduleCall,
  onSendTip,
  onSendSticker,
  isOpen = false,
  onOpenChange,
  activeOption = null,
  onSelectOption
}: PaymentOptionsProps) => {
  const [tipAmount, setTipAmount] = useState(5);
  const [message, setMessage] = useState('');
  const [isPublic, setIsPublic] = useState(false);
  const [activeOptionIndex, setActiveOptionIndex] = useState(0);
  const [callDuration, setCallDuration] = useState(5);
  const [selectedSticker, setSelectedSticker] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  // Pre-defined stickers
  const predefinedStickers = [
    { id: 'sticker1', name: 'Heart', image: '/placeholder.svg' },
    { id: 'sticker2', name: 'Star', image: '/placeholder.svg' },
    { id: 'sticker3', name: 'Flame', image: '/placeholder.svg' },
    { id: 'sticker4', name: 'Trophy', image: '/placeholder.svg' },
  ];

  // Update active option based on the prop
  useEffect(() => {
    if (activeOption) {
      const optionMapping: Record<string, number> = {
        'text': 0,
        'call': 1,
        'tip': 2,
        'sticker': 3
      };
      setActiveOptionIndex(optionMapping[activeOption]);
    }
  }, [activeOption]);

  const handleTip = async () => {
    if (!onSendTip) {
      toast({
        title: "Coming Soon!",
        description: "Tip functionality will be available soon.",
        duration: 3000,
      });
      return;
    }

    try {
      setIsProcessing(true);
      await onSendTip(tipAmount, isPublic);
      toast({
        title: "Tip Sent!",
        description: `Your $${tipAmount.toFixed(2)} tip has been sent!${isPublic ? ' and posted to the Mutual Respect Wall' : ''}`,
      });
      onOpenChange && onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem sending your tip.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSendMessage = async () => {
    if (!message.trim() || !onSendMessage) {
      if (!message.trim()) {
        toast({
          title: "Empty Message",
          description: "Please enter a message to send.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Coming Soon!",
          description: "Message functionality will be available soon.",
          duration: 3000,
        });
      }
      return;
    }

    try {
      setIsProcessing(true);
      await onSendMessage(message, isPublic);
      setMessage('');
      onOpenChange && onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem sending your message.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleScheduleCallClick = async () => {
    if (!onScheduleCall) {
      toast({
        title: "Coming Soon!",
        description: "Call functionality will be available soon.",
        duration: 3000,
      });
      return;
    }

    try {
      setIsProcessing(true);
      await onScheduleCall(callDuration);
      onOpenChange && onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem scheduling your call.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSendStickerClick = async () => {
    if (!selectedSticker || !onSendSticker) {
      if (!selectedSticker) {
        toast({
          title: "No Sticker Selected",
          description: "Please select a sticker to send.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Coming Soon!",
          description: "Sticker functionality will be available soon.",
          duration: 3000,
        });
      }
      return;
    }

    try {
      setIsProcessing(true);
      await onSendSticker(selectedSticker, isPublic);
      const sticker = predefinedStickers.find(s => s.id === selectedSticker);
      toast({
        title: "Sticker Sent!",
        description: `Your ${sticker?.name || 'sticker'} was sent successfully!${isPublic ? ' and posted to the Mutual Respect Wall' : ''}`,
      });
      setSelectedSticker('');
      onOpenChange && onOpenChange(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "There was a problem sending your sticker.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCashOutToWallet = () => {
    toast({
      title: "Connect Your Wallet",
      description: "Web3 wallet connection will be available soon.",
      duration: 3000,
    });
  };

  const handleCashOutToBank = () => {
    toast({
      title: "Connect Your Bank",
      description: "Stripe Connect bank payout will be available soon.",
      duration: 3000,
    });
  };

  const connectionOptions: ConnectionOption[] = [
    {
      id: 'text',
      name: 'Text Chat',
      icon: <MessageSquare className="h-6 w-6 text-fan-purple" />,
      description: `Private messages for $${textRate.toFixed(2)}/message`,
      action: onTextRequest
    },
    {
      id: 'call',
      name: 'Voice Call',
      icon: <PhoneCall className="h-6 w-6 text-fan-purple" />,
      description: `Personal calls for $${callRate.toFixed(2)}/minute`,
      action: onCallRequest
    },
    {
      id: 'tip',
      name: 'Send Tip',
      icon: <DollarSign className="h-6 w-6 text-fan-purple" />,
      description: 'Show appreciation with a tip',
      action: null // Will be handled by the form
    },
    {
      id: 'sticker',
      name: 'Send Sticker',
      icon: <Gift className="h-6 w-6 text-fan-purple" />,
      description: 'Gift a digital sticker or NFT',
      action: null // Will be handled by the form
    }
  ];

  // Handle mouse events for scrolling
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setStartX(e.pageX - (scrollRef.current?.offsetLeft || 0));
    setScrollLeft(scrollRef.current?.scrollLeft || 0);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    e.preventDefault();
    const x = e.pageX - (scrollRef.current?.offsetLeft || 0);
    const walk = (x - startX) * 1.5;
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = scrollLeft - walk;
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleMouseLeave = () => {
    setIsDragging(false);
  };

  // Update active option based on scroll position
  const handleScroll = () => {
    if (!scrollRef.current) return;
    
    const optionWidth = scrollRef.current.scrollWidth / connectionOptions.length;
    const scrollPos = scrollRef.current.scrollLeft;
    const newIndex = Math.round(scrollPos / optionWidth);
    
    if (newIndex !== activeOptionIndex && newIndex >= 0 && newIndex < connectionOptions.length) {
      setActiveOptionIndex(newIndex);
      // Update the parent component about the selected option
      if (onSelectOption) {
        const optionId = connectionOptions[newIndex].id as any;
        onSelectOption(optionId);
      }
    }
  };

  // Snap to closest option after scrolling stops
  useEffect(() => {
    const handleScrollEnd = () => {
      if (!scrollRef.current) return;
      
      const optionWidth = scrollRef.current.scrollWidth / connectionOptions.length;
      scrollRef.current.scrollTo({
        left: activeOptionIndex * optionWidth,
        behavior: 'smooth'
      });
    };

    let scrollTimeout: NodeJS.Timeout;
    
    const handleScrollWithDebounce = () => {
      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(handleScrollEnd, 150);
    };

    const scrollElement = scrollRef.current;
    if (scrollElement) {
      scrollElement.addEventListener('scroll', handleScrollWithDebounce);
    }

    return () => {
      if (scrollElement) {
        scrollElement.removeEventListener('scroll', handleScrollWithDebounce);
      }
      clearTimeout(scrollTimeout);
    };
  }, [activeOptionIndex, onSelectOption]);

  const getActiveOptionAction = () => {
    switch (activeOptionIndex) {
      case 0: // Text
        return handleSendMessage;
      case 1: // Call
        return handleScheduleCallClick;
      case 2: // Tip
        return handleTip;
      case 3: // Sticker
        return handleSendStickerClick;
      default:
        return () => {};
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="bg-fan-background border-fan-purple/30 max-w-md w-full">
        <DialogHeader>
          <DialogTitle className="text-white">Connect Options</DialogTitle>
          <DialogDescription>Choose how you want to connect</DialogDescription>
        </DialogHeader>
        
        {/* Scrollable connection options */}
        <div 
          ref={scrollRef}
          className="flex items-center overflow-x-auto snap-x snap-mandatory py-2 mb-4 no-scrollbar"
          style={{ scrollBehavior: 'smooth', scrollSnapType: 'x mandatory' }}
          onScroll={handleScroll}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseLeave}
        >
          {connectionOptions.map((option, index) => (
            <div 
              key={option.id}
              className="flex-none w-full snap-center px-4"
              style={{ scrollSnapAlign: 'center' }}
            >
              <div 
                className={`h-32 flex flex-col items-center justify-center p-4 rounded-lg transition-all duration-300 ${
                  index === activeOptionIndex ? 'bg-fan-purple/20 border border-fan-purple' : 'bg-secondary/20'
                }`}
              >
                <div className="mb-2">{option.icon}</div>
                <h3 className="text-lg font-medium text-white mb-1">{option.name}</h3>
                <p className="text-sm text-white/70 text-center">{option.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        {/* Option indicator dots */}
        <div className="flex justify-center space-x-2 mb-4">
          {connectionOptions.map((_, index) => (
            <div 
              key={index} 
              className={`h-2 w-2 rounded-full transition-all duration-300 ${
                index === activeOptionIndex ? 'bg-fan-purple w-4' : 'bg-white/30'
              }`}
              onClick={() => {
                if (scrollRef.current) {
                  const optionWidth = scrollRef.current.scrollWidth / connectionOptions.length;
                  scrollRef.current.scrollTo({
                    left: index * optionWidth,
                    behavior: 'smooth'
                  });
                }
              }}
            />
          ))}
        </div>
        
        {/* Action area that changes based on active option */}
        <div className="mt-4">
          {activeOptionIndex === 0 && (
            <div className="space-y-3">
              <Textarea
                placeholder="Type your message here..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="bg-secondary/20 border-fan-purple/20 text-white resize-none"
              />
              <div className="flex items-center justify-between">
                <p className="text-sm text-white/70">
                  ${textRate.toFixed(2)} per message
                </p>
                <div className="flex items-center space-x-2">
                  <Switch 
                    id="public-message" 
                    checked={isPublic}
                    onCheckedChange={setIsPublic}
                    className="data-[state=checked]:bg-fan-purple"
                  />
                  <Label htmlFor="public-message" className="text-sm text-white/70">Post publicly</Label>
                </div>
              </div>
            </div>
          )}
          
          {activeOptionIndex === 1 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between bg-secondary/20 p-3 rounded-md">
                <p className="text-sm text-white/70">Call Duration:</p>
                <div className="flex items-center gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="h-8 w-8 p-0 border-fan-purple/30"
                    onClick={() => setCallDuration(Math.max(1, callDuration - 1))}
                  >
                    -
                  </Button>
                  <span className="text-white w-8 text-center">{callDuration}</span>
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="h-8 w-8 p-0 border-fan-purple/30"
                    onClick={() => setCallDuration(callDuration + 1)}
                  >
                    +
                  </Button>
                  <span className="text-white/70 text-sm">min</span>
                </div>
              </div>
              <p className="text-sm text-white/70">
                Total cost: ${(callRate * callDuration).toFixed(2)}
              </p>
            </div>
          )}
          
          {activeOptionIndex === 2 && (
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2">
                {[1, 5, 10, 20, 50, 100].map((amount, i) => i < 6 && (
                  <Button
                    key={amount}
                    variant="outline"
                    className={`border-fan-purple/30 ${
                      tipAmount === amount ? 'bg-fan-purple text-white' : 'bg-secondary/20'
                    }`}
                    onClick={() => setTipAmount(amount)}
                  >
                    ${amount}
                  </Button>
                ))}
              </div>
              <div className="flex items-center justify-between">
                <p className="text-sm text-white/70">Custom amount:</p>
                <Input
                  type="number"
                  value={tipAmount}
                  onChange={(e) => setTipAmount(Number(e.target.value))}
                  className="w-24 bg-secondary/20 border-fan-purple/20 text-white"
                />
              </div>
              <div className="flex items-center justify-end space-x-2">
                <Switch 
                  id="public-tip" 
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                  className="data-[state=checked]:bg-fan-purple"
                />
                <Label htmlFor="public-tip" className="text-sm text-white/70">Show on Mutual Respect Wall</Label>
              </div>
            </div>
          )}
          
          {activeOptionIndex === 3 && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {predefinedStickers.map((sticker) => (
                  <Button
                    key={sticker.id}
                    variant="outline"
                    className={`h-20 border-fan-purple/30 bg-secondary/20 flex flex-col ${
                      selectedSticker === sticker.id ? 'bg-fan-purple/30 border-fan-purple' : ''
                    }`}
                    onClick={() => setSelectedSticker(sticker.id)}
                  >
                    <div className="w-10 h-10 bg-fan-purple/20 rounded-md mb-1 flex items-center justify-center">
                      <img src={sticker.image} alt={sticker.name} className="h-8 w-8" />
                    </div>
                    <span className="text-xs">{sticker.name}</span>
                  </Button>
                ))}
              </div>
              <div className="flex items-center justify-end space-x-2">
                <Switch 
                  id="public-sticker" 
                  checked={isPublic}
                  onCheckedChange={setIsPublic}
                  className="data-[state=checked]:bg-fan-purple"
                />
                <Label htmlFor="public-sticker" className="text-sm text-white/70">Show on Mutual Respect Wall</Label>
              </div>
              <p className="text-xs text-white/60 italic">NFT stickers will be stored in the recipient's wallet and can be displayed in their Room.</p>
            </div>
          )}
          
          <Button 
            className="w-full bg-fan-purple hover:bg-fan-dark-purple mt-4"
            onClick={getActiveOptionAction()}
            disabled={isProcessing}
          >
            {isProcessing ? (
              "Processing..."
            ) : (
              <>
                {connectionOptions[activeOptionIndex].icon && 
                  <span className="mr-2">{connectionOptions[activeOptionIndex].icon}</span>
                }
                {connectionOptions[activeOptionIndex].name}
              </>
            )}
          </Button>
        </div>
        
        {isCreator && hasEarnings && (
          <CardFooter>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="outline" 
                  className="w-full bg-fan-purple/10 border-fan-purple/30 hover:bg-fan-purple/20 text-white justify-between"
                >
                  <div className="flex items-center">
                    <CreditCard className="mr-2 h-4 w-4 text-fan-purple" />
                    Cash Out Earnings
                  </div>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-fan-background border-fan-purple/30">
                <DropdownMenuItem onClick={handleCashOutToWallet} className="cursor-pointer text-white hover:bg-fan-purple/20">
                  <Wallet className="mr-2 h-4 w-4" />
                  Cash Out to Wallet
                </DropdownMenuItem>
                <DropdownMenuItem onClick={handleCashOutToBank} className="cursor-pointer text-white hover:bg-fan-purple/20">
                  <CreditCard className="mr-2 h-4 w-4" />
                  Cash Out to Bank
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </CardFooter>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default PaymentOptions;
