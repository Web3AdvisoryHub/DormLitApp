
import React from 'react';
import { Link as LinkIcon, Instagram, Twitter, Youtube, Globe, Facebook, Linkedin } from 'lucide-react';

interface SocialLink {
  platform: string;
  url: string;
  username: string;
  icon?: string;
}

interface VerticalSocialLinksProps {
  socialLinks: SocialLink[];
}

const VerticalSocialLinks: React.FC<VerticalSocialLinksProps> = ({ socialLinks }) => {
  // Function to get the appropriate icon based on platform
  const getIconForPlatform = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'instagram':
        return <Instagram className="h-5 w-5" />;
      case 'twitter':
        return <Twitter className="h-5 w-5" />;
      case 'youtube':
        return <Youtube className="h-5 w-5" />;
      case 'facebook':
        return <Facebook className="h-5 w-5" />;
      case 'linkedin':
        return <Linkedin className="h-5 w-5" />;
      case 'website':
        return <Globe className="h-5 w-5" />;
      default:
        return <LinkIcon className="h-5 w-5" />;
    }
  };

  return (
    <div className="w-full flex flex-col gap-2">
      {socialLinks.map((link, index) => (
        <a
          key={index}
          href={link.url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-3 px-4 py-3 bg-white/10 hover:bg-white/20 rounded-md transition-colors"
        >
          <span className="text-fan-purple">
            {link.icon ? (
              <img src={link.icon} alt="" className="h-5 w-5" />
            ) : (
              getIconForPlatform(link.platform)
            )}
          </span>
          <span className="text-white text-sm">{link.username}</span>
        </a>
      ))}
    </div>
  );
};

export default VerticalSocialLinks;
