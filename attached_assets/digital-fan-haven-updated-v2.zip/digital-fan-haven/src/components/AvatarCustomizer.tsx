
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Check } from "lucide-react";

type AvatarFeature = {
  id: string;
  name: string;
  previewUrl: string;
};

type FeatureCategory = {
  id: string;
  name: string;
  features: AvatarFeature[];
};

interface AvatarCustomizerProps {
  onSave: (avatarConfig: AvatarConfig) => void;
  initialConfig?: AvatarConfig;
}

export interface AvatarConfig {
  baseAvatar: string;
  skinTone: string;
  hairStyle: string;
  facialFeature: string;
  accessory: string;
}

const AvatarCustomizer: React.FC<AvatarCustomizerProps> = ({ onSave, initialConfig }) => {
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig>(initialConfig || {
    baseAvatar: 'default',
    skinTone: 'medium',
    hairStyle: 'short',
    facialFeature: 'none',
    accessory: 'none'
  });

  // Sample data - in a real app, these would be actual images
  const baseAvatars: AvatarFeature[] = [
    { id: 'default', name: 'Default', previewUrl: '/placeholder.svg' },
    { id: 'round', name: 'Round', previewUrl: '/placeholder.svg' },
    { id: 'square', name: 'Square', previewUrl: '/placeholder.svg' },
  ];

  const skinTones: AvatarFeature[] = [
    { id: 'light', name: 'Light', previewUrl: '/placeholder.svg' },
    { id: 'medium', name: 'Medium', previewUrl: '/placeholder.svg' },
    { id: 'dark', name: 'Dark', previewUrl: '/placeholder.svg' },
  ];

  const hairStyles: AvatarFeature[] = [
    { id: 'short', name: 'Short', previewUrl: '/placeholder.svg' },
    { id: 'long', name: 'Long', previewUrl: '/placeholder.svg' },
    { id: 'curly', name: 'Curly', previewUrl: '/placeholder.svg' },
    { id: 'bald', name: 'Bald', previewUrl: '/placeholder.svg' },
  ];

  const facialFeatures: AvatarFeature[] = [
    { id: 'none', name: 'None', previewUrl: '/placeholder.svg' },
    { id: 'beard', name: 'Beard', previewUrl: '/placeholder.svg' },
    { id: 'mustache', name: 'Mustache', previewUrl: '/placeholder.svg' },
  ];

  const accessories: AvatarFeature[] = [
    { id: 'none', name: 'None', previewUrl: '/placeholder.svg' },
    { id: 'glasses', name: 'Glasses', previewUrl: '/placeholder.svg' },
    { id: 'hat', name: 'Hat', previewUrl: '/placeholder.svg' },
    { id: 'earrings', name: 'Earrings', previewUrl: '/placeholder.svg' },
  ];

  const featureCategories: FeatureCategory[] = [
    { id: 'baseAvatar', name: 'Base Avatar', features: baseAvatars },
    { id: 'skinTone', name: 'Skin Tone', features: skinTones },
    { id: 'hairStyle', name: 'Hair Style', features: hairStyles },
    { id: 'facialFeature', name: 'Facial Features', features: facialFeatures },
    { id: 'accessory', name: 'Accessories', features: accessories },
  ];

  const handleFeatureSelect = (category: string, featureId: string) => {
    setAvatarConfig({
      ...avatarConfig,
      [category]: featureId
    });
  };

  const handleSave = () => {
    onSave(avatarConfig);
  };

  // Simple avatar preview function - in a real app, this would composite the avatar parts
  const getAvatarPreview = () => {
    // This is a simplified version - a real implementation would combine all selected features
    return '/placeholder.svg';
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="bg-fan-purple/10 border-fan-purple/30 hover:bg-fan-purple/20 text-white">
          Customize Avatar
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[800px] bg-fan-background border-fan-purple/30">
        <DialogHeader>
          <DialogTitle className="text-white">Customize Your Avatar</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-4">
          {/* Avatar Preview */}
          <div className="flex flex-col items-center justify-center p-4 bg-secondary/40 rounded-lg">
            <div className="w-48 h-48 bg-secondary/80 rounded-full overflow-hidden mb-4 border-2 border-fan-purple/30">
              <img 
                src={getAvatarPreview()} 
                alt="Avatar Preview" 
                className="w-full h-full object-cover"
              />
            </div>
            <Button 
              className="w-full bg-fan-purple hover:bg-fan-dark-purple"
              onClick={handleSave}
            >
              Save Avatar
            </Button>
          </div>
          
          {/* Customization Options */}
          <Tabs defaultValue="baseAvatar" className="w-full">
            <TabsList className="grid grid-cols-5 bg-secondary/40">
              {featureCategories.map(category => (
                <TabsTrigger 
                  key={category.id} 
                  value={category.id}
                  className="text-white data-[state=active]:bg-fan-purple data-[state=active]:text-white"
                >
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {featureCategories.map(category => (
              <TabsContent key={category.id} value={category.id} className="mt-4">
                <RadioGroup 
                  value={avatarConfig[category.id as keyof AvatarConfig]} 
                  className="grid grid-cols-2 sm:grid-cols-3 gap-4"
                  onValueChange={(value) => handleFeatureSelect(category.id, value)}
                >
                  {category.features.map(feature => (
                    <div key={feature.id} className="relative">
                      <RadioGroupItem 
                        id={`${category.id}-${feature.id}`} 
                        value={feature.id} 
                        className="sr-only"
                      />
                      <Label
                        htmlFor={`${category.id}-${feature.id}`}
                        className={`
                          flex flex-col items-center p-2 rounded-lg cursor-pointer border-2
                          ${avatarConfig[category.id as keyof AvatarConfig] === feature.id 
                            ? 'border-fan-purple bg-fan-purple/20' 
                            : 'border-transparent bg-secondary/40'}
                        `}
                      >
                        <div className="w-16 h-16 mb-2 rounded overflow-hidden bg-secondary/80">
                          <img 
                            src={feature.previewUrl} 
                            alt={feature.name} 
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <span className="text-sm text-white">{feature.name}</span>
                        {avatarConfig[category.id as keyof AvatarConfig] === feature.id && (
                          <div className="absolute top-1 right-1 bg-fan-purple rounded-full p-1">
                            <Check className="h-3 w-3 text-white" />
                          </div>
                        )}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </TabsContent>
            ))}
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AvatarCustomizer;
